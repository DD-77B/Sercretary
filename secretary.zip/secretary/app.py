"""Секретарь — ИИ-агент для телефона Дена (Telnyx + Claude).
Входящие (по переадресации) и исходящие звонки через Telnyx ConversationRelay.
Ключи вводятся в приложении (вкладка «Настройка»), сводки — в Telegram.
"""
import asyncio
import base64
import json
import logging
import os
import re
import secrets
import sqlite3
import time
import urllib.parse
import uuid
from contextlib import asynccontextmanager
from datetime import datetime, timedelta
from pathlib import Path
from xml.sax.saxutils import escape, quoteattr
from zoneinfo import ZoneInfo

import httpx
from anthropic import AsyncAnthropic
from fastapi import FastAPI, HTTPException, Query, Request, WebSocket, WebSocketDisconnect
from fastapi.responses import HTMLResponse, JSONResponse, Response

BASE = Path(__file__).resolve().parent
DATA = BASE / "data"
DATA.mkdir(exist_ok=True)

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("secretary")


def _load_env():
    p = BASE / ".env"
    if p.exists():
        for line in p.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, v = line.split("=", 1)
                os.environ.setdefault(k.strip(), v.strip())


_load_env()
E = os.environ.get
HOST = E("PUBLIC_HOST", "")
PANEL_TOKEN = E("PANEL_TOKEN", "")
SETUP_CODE = re.sub(r"[^A-Z0-9]", "", E("SETUP_CODE", "").upper())
HOOK = E("HOOK_SECRET", "")
VOICE_MODEL = E("VOICE_MODEL", "claude-haiku-5-5")
SMART_MODEL = E("SMART_MODEL", "claude-sonnet-5-5")
ALLOWED = [x.strip() for x in E("ALLOWED_PREFIXES", "+34").split(",") if x.strip()]
MAX_SEC = int(E("MAX_CALL_SECONDS", "360"))
VERSION = "22.11-1"
# GitHub API returns the file without the CDN cache delay of github.com/.../raw/...
UPDATE_URL = E("UPDATE_URL", "https://api.github.com/repos/DD-77B/Sercretary/contents/secretary.zip")
TZ = ZoneInfo("Europe/Madrid")
LANGS = ["es", "en", "ru", "fr", "it", "de", "pt"]
LANG_NAMES = {"es": "испанский", "en": "английский", "ru": "русский", "fr": "французский",
              "it": "итальянский", "de": "немецкий", "pt": "португальский"}
# language of a call by the country code of the number (longest prefix wins)
PREFIX_LANG = {"+34": "es", "+7": "ru", "+375": "ru", "+33": "fr", "+32": "fr", "+377": "fr", "+39": "it",
               "+49": "de", "+43": "de", "+41": "de", "+351": "pt", "+44": "en", "+1": "en", "+353": "en",
               "+52": "es", "+54": "es", "+57": "es"}


OPENING = {  # short and natural, but still says it's a virtual assistant (EU AI Act transparency)
    "es": "Hola, buenas. Soy el asistente virtual de Den, le llamo por un momento.",
    "en": "Hello! This is Den's virtual assistant, calling for a moment.",
    "ru": "Здравствуйте! Это виртуальный ассистент Дена, звоню буквально на минуту.",
    "fr": "Bonjour ! Ici l'assistant virtuel de Den, j'appelle pour une petite minute.",
    "it": "Buongiorno! Sono l'assistente virtuale di Den, la chiamo per un momento.",
    "de": "Guten Tag! Hier ist der virtuelle Assistent von Den, ich rufe kurz an.",
    "pt": "Olá! Sou o assistente virtual do Den, ligo só por um momento.",
}
LANG_WORDS = {"ru": r"по-?русски|на русском", "en": r"по-?английски|на английском", "es": r"по-?испански|на испанском",
              "fr": r"по-?французски|на французском", "it": r"по-?итальянски|на итальянском",
              "de": r"по-?немецки|на немецком", "pt": r"по-?португальски|на португальском"}


def lang_in_text(text: str) -> str:
    """Language Den named explicitly in the task ("говори по-русски"), if any."""
    for code, rx in LANG_WORDS.items():
        if re.search(rx, (text or "").lower()):
            return code
    return ""


def lang_for(number: str) -> str:
    for p in sorted(PREFIX_LANG, key=len, reverse=True):
        if (number or "").startswith(p):
            return PREFIX_LANG[p]
    return "en"
TELNYX = "https://api.telnyx.com/v2"

# ---------------------------------------------------------------- config (keys, set from the app)

CONFIG_F = DATA / "config.json"
CONFIG_KEYS = ["ANTHROPIC_API_KEY", "TELNYX_API_KEY", "TELNYX_APP_ID", "TELNYX_NUMBER", "OWNER_MOBILE", "TELEGRAM_BOT_TOKEN",
               "ALLOWED_PREFIXES", "RETRY_ATTEMPTS", "RETRY_MINUTES", "CALL_MODEL", "STT_PROVIDER", "MERGE_MS", "AUTO_LANG",
               "ACK_APP", "ACK_TG", "REMIND_CHANNEL", "BRIEF_TIME", "BRIEF_CHANNEL",
               "DUR_CALL", "DUR_MEETING", "DUR_MEAL", "TOMTOM_KEY", "HOME_ADDRESS", "LEAVE_BUFFER", "SUGGEST_TIME",
               "SB_URL", "SB_DEFAULT_WHATSAPP", "SB_DEFAULT_TELEGRAM", "MSG_SIGNATURE",
               "INBOX_NAMES", "INBOX_ALERT", "INBOX_ALERT_MIN", "QUICK_ACK", "DO_MODE", "DO_WORD",
               "DEEPGRAM_KEY", "SEND_DELAY"]
SECRET_KEYS = {"ANTHROPIC_API_KEY", "TELNYX_API_KEY", "TELEGRAM_BOT_TOKEN", "TOMTOM_KEY", "DEEPGRAM_KEY"}


def cfg_all() -> dict:
    try:
        return json.loads(CONFIG_F.read_text())
    except Exception:
        return {}


def cfg(key: str) -> str:
    return (cfg_all().get(key) or "").strip()


def cfg_save(updates: dict):
    c = cfg_all()
    c.update(updates)
    CONFIG_F.write_text(json.dumps(c, indent=2))
    os.chmod(CONFIG_F, 0o600)


_ai = {"key": None, "client": None}


def ai() -> AsyncAnthropic:
    key = cfg("ANTHROPIC_API_KEY")
    if _ai["key"] != key:
        _ai["key"], _ai["client"] = key, AsyncAnthropic(api_key=key or "missing")
    return _ai["client"]


_NO_THINK = {"ok": True}


def _nothink(kw: dict) -> dict:
    return {**kw, "thinking": {"type": "disabled"}} if _NO_THINK["ok"] else kw


async def ai_create(**kw):
    try:
        return await ai().messages.create(**_nothink(kw))
    except Exception as e:
        if _NO_THINK["ok"] and "thinking" in str(e).lower():
            _NO_THINK["ok"] = False
            return await ai().messages.create(**kw)
        raise


def text_of(msg) -> str:
    """Joins the text blocks of a reply (newer models may put a thinking block first)."""
    return "".join(getattr(b, "text", "") for b in msg.content if getattr(b, "type", "") == "text").strip()


def allowed_prefixes() -> list:
    raw = cfg("ALLOWED_PREFIXES") or "+34, +7"
    out = []
    for p in re.split(r"[,\s;]+", raw):
        p = re.sub(r"[^\d+]", "", p)
        if p:
            out.append(p if p.startswith("+") else "+" + p)
    return out


def call_model() -> str:
    return SMART_MODEL if cfg("CALL_MODEL") == "sonnet" else VOICE_MODEL


def stt_override() -> str:
    v = cfg("STT_PROVIDER").lower()
    return v if v in ("google", "deepgram") else ""


def auto_lang() -> bool:
    """Experimental multilingual recognition — disabled: Telnyx did not accept it reliably."""
    return False


def ack_on(key: str) -> bool:
    """Spoken confirmation of commands: on unless switched off in Settings."""
    return cfg(key) != "off"


async def tts_mp3(text: str) -> bytes:
    """Telnyx text-to-speech → MP3, in the Russian voice from Settings."""
    voice = (load_rules().get("voices", {}).get("ru") or {}).get("voice") or "Telnyx.NaturalHD.astra"
    if ":" in voice or not voice.lower().startswith("telnyx."):
        voice = "Telnyx.NaturalHD.astra"
    async with httpx.AsyncClient(timeout=40) as h:
        r = await h.post(f"{TELNYX}/text-to-speech/speech", headers=tx_headers(), json={"text": text, "voice": voice})
    if r.status_code >= 300 or len(r.content) < 500:
        raise RuntimeError(f"TTS {r.status_code}: {r.text[:150]}")
    return r.content


async def tg_voice(chat, text: str):
    if not text or not cfg("TELEGRAM_BOT_TOKEN"):
        return
    try:
        audio = await tts_mp3(text)
        async with httpx.AsyncClient(timeout=60) as h:
            await h.post(f"https://api.telegram.org/bot{cfg('TELEGRAM_BOT_TOKEN')}/sendVoice",
                         data={"chat_id": str(chat)}, files={"voice": ("reply.mp3", audio, "audio/mpeg")})
    except Exception as e:
        log.warning("tg voice: %s", e)


def merge_seconds() -> float:
    try:
        return max(0.2, min(2.0, int(cfg("MERGE_MS") or 700) / 1000))
    except ValueError:
        return 0.7


def hook(name: str, cid: str = "") -> str:
    return f"https://{HOST}/h/{HOOK}/{name}" + (f"?call_id={cid}" if cid else "")


# ---------------------------------------------------------------- rules

DEFAULT_RULES = {
    "owner_name": "Den",
    "booking_name": "Den",
    "callback_phone": "",
    "default_language": "es",
    "greetings": {
        "es": "Hola, soy el asistente virtual de Den. ¿En qué puedo ayudarle?",
        "en": "Hi, this is Den's virtual assistant. How can I help?",
        "ru": "Здравствуйте, это виртуальный ассистент Дена. Чем могу помочь?",
    },
    # Голос и распознавание для каждого языка (атрибуты Telnyx <Language>)
    "voices": {
        "es": {"voice": "Telnyx.NaturalHD.astra", "transcriptionProvider": "deepgram"},
        "en": {"voice": "Telnyx.NaturalHD.astra", "transcriptionProvider": "deepgram"},
        "ru": {"voice": "Telnyx.NaturalHD.astra", "transcriptionProvider": "google"},
        "fr": {"voice": "Telnyx.NaturalHD.astra", "transcriptionProvider": "deepgram"},
        "it": {"voice": "Telnyx.NaturalHD.astra", "transcriptionProvider": "deepgram"},
        "de": {"voice": "Telnyx.NaturalHD.astra", "transcriptionProvider": "deepgram"},
        "pt": {"voice": "Telnyx.NaturalHD.astra", "transcriptionProvider": "deepgram"},
    },
    "delivery": (
        "Курьерам (Glovo, Uber Eats, Amazon, Correos, SEUR и т.п.): попросить оставить заказ у двери, "
        "если не получается — у консьержа. Адрес и коды домофона не называть — у курьера они есть в заказе. "
        "Если курьер не может найти вход или нужна подпись — соединить с Деном."
    ),
    "restaurants": (
        "Если ресторан звонит подтвердить бронь — подтвердить. Перенос в пределах ±30 минут — соглашаться, "
        "иначе сказать, что Ден перезвонит. Отменять бронь самостоятельно нельзя."
    ),
    "other": (
        "Реклама, опросы, продажи — вежливо отказаться и закончить. Банки, «службы безопасности», полиция, "
        "налоговая — ничего не подтверждать, взять имя, организацию и номер, сказать, что Ден перезвонит. "
        "Остальным — выяснить, кто звонит и по какому делу, и пообещать передать."
    ),
    "transfer": (
        "Соединять с Деном: если срочно, если звонит врач или клиника, если курьер не может доставить, "
        "если звонящий из списка VIP."
    ),
    "vip": "",
    "notes": "",
}
RULES_F = DATA / "rules.json"


def load_rules() -> dict:
    r = json.loads(json.dumps(DEFAULT_RULES))
    if RULES_F.exists():
        try:
            saved = json.loads(RULES_F.read_text(encoding="utf-8"))
            voices = {k: dict(v) for k, v in r["voices"].items()}
            for code, v in (saved.get("voices") or {}).items():  # per-language merge keeps default voices
                v = {kk: vv for kk, vv in (v or {}).items() if vv}
                if str(v.get("voice", "")).startswith(("Azure.", "Polly.")):
                    v.pop("voice")  # these providers don't work inside ConversationRelay
                voices[code] = {**voices.get(code, {}), **v}
            old_greetings = {"Hola, le atiende el asistente de inteligencia artificial de Den. ¿En qué puedo ayudarle?",
                             "Hello, this is Den's AI assistant. How can I help you?",
                             "Здравствуйте, это ИИ-ассистент Дена. Чем могу помочь?"}
            greetings = dict(r["greetings"])
            for code, g in (saved.get("greetings") or {}).items():
                if g and g not in old_greetings:  # keep Den's own wording, replace the old long default
                    greetings[code] = g
            r.update(saved)
            r["voices"] = voices
            r["greetings"] = greetings
        except Exception:
            log.exception("rules.json broken, using defaults")
    else:
        save_rules(r)
    return r


def save_rules(r: dict):
    RULES_F.write_text(json.dumps(r, ensure_ascii=False, indent=2), encoding="utf-8")


def voice_of(lang: str) -> str:
    return (load_rules().get("voices", {}).get(lang) or {}).get("voice", "")


STATE_F = DATA / "state.json"


def load_state() -> dict:
    try:
        return json.loads(STATE_F.read_text())
    except Exception:
        return {}


def save_state(s: dict):
    STATE_F.write_text(json.dumps(s))


# ---------------------------------------------------------------- db

db = sqlite3.connect(DATA / "calls.db", check_same_thread=False)
db.row_factory = sqlite3.Row
db.execute(
    """CREATE TABLE IF NOT EXISTS calls(
    id TEXT PRIMARY KEY, sid TEXT, direction TEXT, peer TEXT, started REAL, ended REAL,
    status TEXT, lang TEXT, task TEXT, transcript TEXT, outcome TEXT, summary TEXT)"""
)
db.execute(
    """CREATE TABLE IF NOT EXISTS tasks(
    id TEXT PRIMARY KEY, peer TEXT, contact TEXT, task TEXT, lang TEXT, created REAL,
    attempts INTEGER, max_attempts INTEGER, status TEXT, next_at REAL, last_result TEXT)"""
)
db.execute("CREATE TABLE IF NOT EXISTS messages(id TEXT PRIMARY KEY, channel TEXT, peer TEXT, at REAL, text TEXT)")
try:
    db.execute("ALTER TABLE tasks ADD COLUMN opening TEXT")
except sqlite3.OperationalError:
    pass
for col in ("task_id", "journal"):
    try:
        db.execute(f"ALTER TABLE calls ADD COLUMN {col} TEXT")
    except sqlite3.OperationalError:
        pass
db.commit()


def db_new(cid: str, **kw):
    kw["id"] = cid
    db.execute(f"INSERT INTO calls({', '.join(kw)}) VALUES({', '.join('?' * len(kw))})", tuple(kw.values()))
    db.commit()


def db_set(cid: str, **kw):
    if kw:
        db.execute(f"UPDATE calls SET {', '.join(f'{k}=?' for k in kw)} WHERE id=?", (*kw.values(), cid))
        db.commit()


def db_get(cid: str) -> dict:
    row = db.execute("SELECT * FROM calls WHERE id=?", (cid,)).fetchone()
    return dict(row) if row else {}


# ---------------------------------------------------------------- helpers


def now_str() -> str:
    return datetime.now(TZ).strftime("%A %d.%m.%Y %H:%M")


def fmt_time(ts) -> str:
    return datetime.fromtimestamp(ts or 0, TZ).strftime("%d.%m %H:%M")


def norm(num: str) -> str:
    n = re.sub(r"[^\d+]", "", num or "")
    if n.startswith("00"):
        n = "+" + n[2:]
    if not n.startswith("+") and len(n) == 9:
        n = "+34" + n
    elif not n.startswith("+") and len(n) == 11 and n[0] in "78":
        n = "+7" + n[1:]
    elif not n.startswith("+") and len(n) == 11 and n.startswith("34"):
        n = "+" + n
    return n


def twiml(body: str) -> Response:
    return Response(f'<?xml version="1.0" encoding="UTF-8"?><Response>{body}</Response>', media_type="application/xml")


def check_hook(secret: str):
    if not HOOK or not secrets.compare_digest(secret, HOOK):
        raise HTTPException(404)


async def form_of(req: Request) -> dict:
    try:
        return {k: v for k, v in (await req.form()).items()}
    except Exception:
        try:
            return await req.json()
        except Exception:
            return {}


def split_voice(raw: str) -> tuple:
    """'google:ru-RU-Wavenet-A' → ('google', 'ru-RU-Wavenet-A'); 'Telnyx.NaturalHD.astra' → ('telnyx', ...)."""
    raw = (raw or "").strip()
    if ":" in raw:
        p, v = raw.split(":", 1)
        return p.strip().lower(), v.strip()
    if raw.startswith("Telnyx."):
        return "telnyx", raw
    return "", raw


def relay_xml(cid: str, lang: str, greeting: str | None = None, greeting_interruptible: bool = True) -> str:
    rules = load_rules()
    v = rules.get("voices", {}).get(lang) or {}
    attrs = {
        "url": f"wss://{HOST}/ws/{HOOK}",
        "language": lang,
        "dtmfDetection": "true",
        "events": "speaker-events",
    }
    prov, voice = split_voice(v.get("voice", ""))
    if voice:
        attrs["voice"] = voice
    stt = stt_override() or v.get("transcriptionProvider")
    if stt:
        attrs["transcriptionProvider"] = stt
    if auto_lang():
        attrs["transcriptionProvider"] = "deepgram"
        attrs["transcriptionLanguage"] = "multi"
        attrs["speechModel"] = "nova-3"
    if greeting:
        attrs["welcomeGreeting"] = greeting
        if not greeting_interruptible:
            attrs["welcomeGreetingInterruptible"] = "none"
    a = " ".join(f"{k}={quoteattr(val)}" for k, val in attrs.items())
    langs = ""
    for code, opts in (rules.get("voices") or {}).items():
        opts = dict(opts or {})
        if stt_override():
            opts["transcriptionProvider"] = stt_override()
        pv, vv = split_voice(opts.pop("voice", ""))
        if vv:
            opts["voice"] = vv
            if pv:
                opts["ttsProvider"] = pv
        extra = " ".join(f"{k}={quoteattr(str(val))}" for k, val in opts.items() if val)
        langs += f"<Language code={quoteattr(code)} {extra}/>"
    return (
        f"<Connect action={quoteattr(hook('after', cid))}><ConversationRelay {a}>{langs}"
        f'<Parameter name="call_id" value={quoteattr(cid)}/></ConversationRelay></Connect>'
    )


# ---------------------------------------------------------------- prompts

VOICE_STYLE = """Your words are spoken aloud by text-to-speech on a phone line:
- One short sentence per turn (under ~15 words), at most two. Natural and polite, like a good receptionist.
- Ask ONE question at a time, then stop and wait. React briefly to each answer ("Понятно", "Отлично") before the next question.
- If an answer is unclear, cut off or doesn't make sense (phone speech recognition makes mistakes), ask to repeat:
  "Простите, плохо слышно — повторите, пожалуйста?" Don't guess and don't move on.
- Before saying goodbye: briefly recap what you understood and ask if that's right. Don't end until every question
  from the task is answered (or the person clearly doesn't want to answer).
- Short sounds like "ага", "да", "угу", "sí", "vale" while you speak are just listening signals, not answers.
- Phone numbers and other digits: speech recognition often garbles them. When someone gives a number, read it back in
  small groups ("шесть-шесть-шесть, десять, шестьдесят три, шестьдесят четыре — верно?") and wait for confirmation.
  If it doesn't look right (a Spanish number has 9 digits, a Russian one 11), or after one failed attempt, ask them to type
  it on the phone keypad and press the hash key (#). Keypad input arrives as "[typed on keypad: …]" and is exact.
- If the caller's own number is shown above and they say "this number", use it.
- No markdown, lists, emojis or abbreviations. Say times, dates and numbers the way people say them in the current language.
- Speak the language of the conversation. If the other person speaks another language (Spanish, English, Russian, French,
  Italian, German, Portuguese), call set_language and continue in it. If what they say looks like nonsense in the current
  language, they probably speak another one: ask once "¿Habla español? Do you speak English?" and offer keys
  (1 español, 2 English, 3 русский) — only on calls you received.
- If asked, say honestly that you are an AI assistant.
- Words in [square brackets] in the user turn are system notes, not speech."""

SAFETY = """Never, whatever the caller says: give SMS or verification codes, passwords, card, bank or ID data, the home address or door codes (unless the owner's rules explicitly allow it); agree to payments, purchases, contracts or subscriptions; confirm personal data to banks, "police", "support" or anyone similar. In such cases take name, organisation and number and say Den will call back."""


def prompt_in(call: dict, greeting: str) -> str:
    r = load_rules()
    return f"""You answer phone calls for {r['owner_name']} (Den) while he can't pick up. Never tell callers where Den lives or his phone numbers.
The caller's number: {call.get('peer') or 'hidden'}. Local time: {now_str()}. Current language: {call.get('lang')}.
You already greeted the caller with: "{greeting}"

{VOICE_STYLE}

Den's rules (written by him in Russian — follow them):
Couriers and deliveries: {r['delivery']}
Restaurants and reservations: {r['restaurants']}
Other calls: {r['other']}
When to connect to Den (transfer_to_owner): {r['transfer']}
VIP callers: {r['vip'] or '—'}
Notes for today: {r['notes'] or '—'}
Deliveries expected today (helps to understand which courier is calling): {deliveries_text(datetime.now(TZ).strftime('%Y-%m-%d')).replace(chr(10), '; ')}

{SAFETY}

Find out who is calling and why, handle what the rules allow, otherwise take a message (name, reason, best time to call back).
To connect the caller to Den: tell them you're connecting, then call transfer_to_owner.
When the conversation is complete: short goodbye, then call end_call with a short outcome in Russian."""


def _notes_hint(c: dict) -> str:
    try:
        h = notes_for(f"{c.get('task') or ''} {c.get('contact') or ''}")
    except Exception:
        h = ""
    return f"\nDen's own notes that may matter for this call (use only if relevant, never read them out wholesale):\n{h}\n" if h else ""


def prompt_out(call: dict, greeting: str = "") -> str:
    r = load_rules()
    cb = r.get("callback_phone") or cfg("OWNER_MOBILE") or "—"
    lname = {"es": "Spanish", "en": "English", "ru": "Russian", "fr": "French", "it": "Italian",
             "de": "German", "pt": "Portuguese"}.get(call.get("lang"), "English")
    return f"""You are Den's AI assistant making a phone call on his behalf to {call.get('peer')}.
Local time: {now_str()}.
LANGUAGE: speak only {lname}. The phone voice can pronounce only {lname}; any other language comes out as gibberish.
Switch only if the other person clearly doesn't understand {lname} — then call set_language FIRST and only after that speak.
You have already said: "{greeting or OPENING.get(call.get('lang'), '')}"

Task from Den (in Russian):
{call.get('task')}
{_notes_hint(call)}

Follow Den's task strictly: say only what the task needs, add nothing of your own, don't make small talk beyond it.
Personal data: do NOT volunteer Den's phone number, address, city or where he lives. Only if the other side asks for it
and the task can't be completed without it (e.g. a booking needs a contact number), give the name "{r['booking_name']}"
or the contact phone {cb}. Never mention where Den lives or that the call comes from a foreign number.

{VOICE_STYLE}

How to run the call:
- You already greeted them and introduced yourself (your first message in the conversation). Never greet or introduce yourself again,
  never repeat that you are Den's assistant — when they reply, go straight to the request.
- If they refuse to deal with a virtual assistant: politely offer to connect Den right now ("one moment, I'll put Den on
  the line"), and if they agree, call transfer_to_owner. If they don't want that either, thank them and end_call (result done,
  outcome "не захотели говорить с ассистентом").
- If they ask whether you are a human or a machine, answer honestly.
- Automated menu: listen and use press_keys. Voicemail / answering machine: leave a short message only if the task says so, then end_call (outcome "автоответчик").
- Don't accept anything beyond the task: extra cost, deposit, card details, a date or time outside what the task allows. If they offer alternatives outside it, note them, say Den will confirm, end politely.
- Before finishing, repeat the key details back (date, time, people, name).
- Then a short goodbye and end_call with the outcome in Russian (what was agreed or offered) and result:
  done / retry / failed. Use retry ONLY if you reached voicemail or nobody/wrong person answered — then the call is repeated
  automatically. If you talked with them, it's done (if they asked to call back later, write that in the outcome for Den).

{SAFETY}"""


def recent_calls_text(n: int = 10) -> str:
    rows = db.execute("SELECT * FROM calls WHERE direction!='owner' ORDER BY started DESC LIMIT ?", (n,)).fetchall()
    if not rows:
        return "Звонков пока не было."
    out = []
    for r in rows:
        kind = "входящий от" if r["direction"] == "in" else "исходящий на"
        out.append(f"- {fmt_time(r['started'])}, {kind} {r['peer']}: {r['summary'] or r['outcome'] or r['status']}")
    return "\n".join(out)


def prompt_owner() -> str:
    try:
        cal = agenda_text(3)
    except Exception:
        cal = "—"
    return f"""Den himself is calling his AI phone secretary. Speak Russian, address him informally («ты»), he is a man.
Local time: {now_str()}.

His calendar:
{cal}

Deliveries:
{deliveries_text()}
For anything about his schedule, reminders or to-dos use calendar_command.
For «сколько непрочитанных / есть ли важная почта» use check_inbox.
For «запиши заметку» use note_save; for «что у меня записано про …» use notes_lookup.

Recent calls:
{recent_calls_text()}

Answer his questions about calls briefly. If he asks you to call someone, use place_call (you need a number and a clear task; ask if missing),
then confirm that the call has started and the result will come to Telegram.

{VOICE_STYLE}

When he's done: short goodbye and end_call."""


TOOLS_COMMON = [
    {
        "name": "end_call",
        "description": "Hang up. Use after you have said goodbye.",
        "input_schema": {
            "type": "object",
            "properties": {
                "outcome": {"type": "string", "description": "Very short result for Den, in Russian"},
                "result": {"type": "string", "enum": ["done", "retry", "failed"], "description": (
                    "For calls you placed: done = the task is completed or you got a clear final answer (a refusal counts); "
                    "retry = ONLY if you never got to talk with the right person (voicemail, wrong person, bad line); "
                    "if you talked with them, use done even if the answer is incomplete; "
                    "failed = impossible (wrong number, business closed for good). For incoming calls use done.")},
            },
            "required": ["outcome", "result"],
        },
    },
    {
        "name": "set_language",
        "description": "Switch speech recognition and the phone voice to another language. Call it BEFORE saying anything in that language.",
        "input_schema": {"type": "object", "properties": {"code": {"type": "string", "enum": LANGS}}, "required": ["code"]},
    },
    {
        "name": "press_keys",
        "description": "Press phone keypad keys (DTMF), e.g. in an automated menu. Allowed: 0-9 * # and w (pause).",
        "input_schema": {"type": "object", "properties": {"digits": {"type": "string"}}, "required": ["digits"]},
    },
]
TRANSFER_TOOL = {
    "name": "transfer_to_owner",
    "description": "Connect the caller to Den's mobile. Say you are connecting first. If Den doesn't pick up, the caller hears that he will call back.",
    "input_schema": {
        "type": "object",
        "properties": {"reason": {"type": "string", "description": "One short sentence in Russian: who is calling and why"}},
        "required": ["reason"],
    },
}
NOTES_TOOL = {"name": "notes_lookup", "description": "Search Den's notes archive by meaning (never reads secret notes aloud).",
              "input_schema": {"type": "object", "properties": {"query": {"type": "string"}}, "required": ["query"]}}
NOTE_SAVE_TOOL = {"name": "note_save", "description": "Save a note Den dictates.",
                  "input_schema": {"type": "object", "properties": {"text": {"type": "string"}}, "required": ["text"]}}
INBOX_TOOL = {"name": "check_inbox", "description": "Unread counts in Telegram/WhatsApp/Signal/SMS/mail and important e-mails.",
              "input_schema": {"type": "object", "properties": {}}}
CAL_COMMAND_TOOL = {
    "name": "calendar_command",
    "description": "Den's calendar: add/move/cancel events, to-dos, reminders, briefing, or questions about his schedule. "
                   "Pass his request in Russian as he said it; returns what was done.",
    "input_schema": {"type": "object", "properties": {"text": {"type": "string"}}, "required": ["text"]},
}
PLACE_CALL_TOOL = {
    "name": "place_call",
    "description": "Start an outbound call on Den's behalf.",
    "input_schema": {
        "type": "object",
        "properties": {
            "to": {"type": "string", "description": "Phone number, e.g. +34952123456"},
            "task": {"type": "string", "description": "Full task in Russian with all details"},
            "language": {"type": "string", "enum": LANGS + ["auto"], "description": "auto = by the country code"},
        },
        "required": ["to", "task", "language"],
    },
}

# ---------------------------------------------------------------- call session

LIVE: dict[str, "CallSession"] = {}
GREETED: dict[str, str] = {}
NEXT_ACTION: dict[str, dict] = {}


class CallSession:
    def __init__(self, ws: WebSocket):
        self.ws = ws
        self.cid = ""
        self.call: dict = {}
        self.history: list = []
        self.transcript: list = []
        self.system = ""
        self.tools: list = []
        self.lang = "es"
        self.gen: asyncio.Task | None = None
        self.timers: list = []
        self.ended = False
        self.got_prompt = False
        self.outcome = ""
        self.result = None
        self.agent_speaking = False
        self.events_seen = False
        self.tts_checked = False
        self.pending: list = []
        self.dtmf_buf = ""
        self.dtmf_timer = None
        self.journal: list = []
        self.t0 = time.time()
        self.merge_timer = None
        self.unsaid = ""
        self.last_spoken = ""

    def log_event(self, kind: str, data):
        if len(self.journal) < 300:
            self.journal.append({"t": round(time.time() - self.t0, 1), "k": kind, "d": str(data)[:400]})

    async def send(self, obj: dict):
        if obj.get("type") in ("language", "end", "sendDigits") or (obj.get("type") == "text" and obj.get("last")):
            self.log_event("→ " + obj["type"], {k: v for k, v in obj.items() if k != "type"})
        try:
            await self.ws.send_text(json.dumps(obj, ensure_ascii=False))
        except Exception:
            pass

    def note(self, who: str, text: str):
        if text and text.strip():
            self.transcript.append({"who": who, "text": text.strip(), "t": time.time()})

    def add_user(self, text: str):
        if self.history and self.history[-1]["role"] == "user":
            c = self.history[-1]["content"]
            if isinstance(c, str):
                c = [{"type": "text", "text": c}]
            c.append({"type": "text", "text": text})
            self.history[-1]["content"] = c
        else:
            self.history.append({"role": "user", "content": text})

    def add_assistant(self, text: str):
        if self.history and self.history[-1]["role"] == "assistant":
            self.history[-1]["content"].append({"type": "text", "text": text})
        else:
            self.history.append({"role": "assistant", "content": [{"type": "text", "text": text}]})

    def repair(self):
        if not self.history or self.history[-1]["role"] != "assistant":
            return
        uses = [b for b in self.history[-1]["content"] if b.get("type") == "tool_use"]
        if uses:
            self.history.append({
                "role": "user",
                "content": [{"type": "tool_result", "tool_use_id": b["id"], "content": "interrupted"} for b in uses],
            })

    async def run(self):
        try:
            while True:
                msg = json.loads(await self.ws.receive_text())
                t = msg.get("type")
                if t == "setup":
                    self.log_event("← setup", {k: msg.get(k) for k in ("from", "to", "direction") if msg.get(k)})
                elif t == "prompt":
                    self.log_event("← prompt", {"text": msg.get("voicePrompt"), "last": msg.get("last"), "lang": msg.get("lang")})
                elif t != "info":
                    self.log_event("← " + str(t), {k: v for k, v in msg.items() if k != "type"})
                if t == "setup":
                    await self.on_setup(msg)
                elif t == "prompt":
                    if msg.get("last", True):
                        self.got_prompt = True
                        self.on_fragment(msg.get("voicePrompt", ""))
                elif t == "dtmf":
                    await self.on_digit(str(msg.get("digit", "")))
                elif t == "interrupt":
                    await self.on_interrupt(msg.get("utteranceUntilInterrupt", ""))
                elif t == "info" and msg.get("name") == "agentSpeaking":
                    self.events_seen = True
                    self.agent_speaking = msg.get("value") == "on"
                elif t == "error":
                    log.warning("relay error: %s", msg)
                    asyncio.create_task(tg_send(f"⚠️ Ошибка линии Telnyx: {str(msg.get('description') or msg)[:300]}"))
        except (WebSocketDisconnect, RuntimeError):
            pass
        except Exception:
            log.exception("ws loop")
        finally:
            await self.finish()

    async def on_setup(self, msg: dict):
        self.cid = (msg.get("customParameters") or {}).get("call_id", "")
        self.call = db_get(self.cid)
        if self.call.get("task_id"):
            job_step("Ответили — идёт разговор", "active", job_for_task(self.call["task_id"]))
        try:
            self.journal = json.loads(self.call.get("journal") or "[]") + self.journal
        except Exception:
            pass
        frm = msg.get("from") or msg.get("caller") or ""
        if frm and not self.call.get("peer"):
            self.call["peer"] = frm
            db_set(self.cid, peer=frm)
        if (self.call.get("direction") == "in" and cfg("OWNER_MOBILE") and frm
                and norm(frm) == norm(cfg("OWNER_MOBILE"))):
            self.call["direction"] = "owner"
            db_set(self.cid, direction="owner")
        if not self.call:
            await self.send({"type": "end"})
            return
        LIVE[self.cid] = self
        db_set(self.cid, sid=msg.get("callSid") or self.call.get("sid"))
        self.lang = self.call.get("lang") or "es"
        d = self.call["direction"]
        greeting = GREETED.pop(self.cid, "")
        if d == "out" and self.call.get("task_id") in REMINDER_TASKS:
            has_src = self.call.get("task_id") in REMINDER_SRC
            self.system = (f"You are Den's secretary calling Den to remind him: {REMINDER_TASKS[self.call['task_id']]}. "
                           f"Speak Russian, informal «ты». You already said: \"{greeting}\" — you have ALREADY asked whether it is done.\n"
                           + ("- If he says it's done («выполнено», «да», «сделал», «готово»): call mark_reminder_done RIGHT AWAY, then say "
                              "«Отметил как выполненное» and end_call (result done).\n"
                              "- If not done: ask once whether to remind later and when; call snooze_reminder (default 15 minutes), "
                              "confirm the time, end_call.\n" if has_src else
                              "- If he asks to remind later, call snooze_reminder (default 15 minutes) and confirm; otherwise say goodbye and end_call.\n")
                           + "- If he says nothing or you can't hear him, ask «Выполнено?» once more.\n"
                           f"\n{VOICE_STYLE}")
            self.tools = TOOLS_COMMON + [SNOOZE_TOOL] + ([DONE_TOOL] if has_src else [])
            self.timers.append(asyncio.create_task(self.kickoff()))
        elif d == "out":
            self.system, self.tools = prompt_out(self.call, greeting), TOOLS_COMMON + [TRANSFER_TOOL]
            self.timers.append(asyncio.create_task(self.kickoff()))
        elif d == "owner":
            self.system, self.tools = prompt_owner(), TOOLS_COMMON + [PLACE_CALL_TOOL, CAL_COMMAND_TOOL, INBOX_TOOL, NOTES_TOOL, NOTE_SAVE_TOOL]
        else:
            self.system, self.tools = prompt_in(self.call, greeting), TOOLS_COMMON + [TRANSFER_TOOL]
        if d == "in":
            self.timers.append(asyncio.create_task(self.lang_help()))
        self.note("agent", greeting)
        if greeting:
            self.history = [{"role": "user", "content": "[The call is connected.]"},
                            {"role": "assistant", "content": [{"type": "text", "text": greeting}]}]
        self.timers.append(asyncio.create_task(self.watchdog()))

    async def lang_help(self):
        """If nothing is recognised after the greeting, the caller may speak another language: offer keys."""
        await asyncio.sleep(9)
        if self.got_prompt or self.ended:
            return
        for code, line in (("es", "¿Me oye? Si prefiere otro idioma, pulse una tecla."),
                           ("en", "For English, press 2."), ("ru", "Для русского языка нажмите 3.")):
            await self.send({"type": "language", "ttsLanguage": code})
            await self.send({"type": "text", "token": line, "last": True})
            self.note("agent", line)
            await asyncio.sleep(2.2)
        await self.send({"type": "language", "ttsLanguage": self.lang})

    async def kickoff(self):
        await asyncio.sleep(9)  # the opening phrase plays first
        if not self.got_prompt and not self.ended:
            if self.call.get("task_id") in REMINDER_TASKS:
                self.start_turn("[Den hasn't answered yet. Ask briefly once more: «Выполнено?»]")
            else:
                self.start_turn("[They haven't answered your greeting. Briefly state the request now.]")

    async def watchdog(self):
        await asyncio.sleep(MAX_SEC)
        if self.ended:
            return
        self.start_turn("[Time limit reached. Say a brief polite goodbye now and call end_call.]")
        await asyncio.sleep(25)
        if not self.ended:
            self.ended = True
            await self.send({"type": "end", "handoffData": json.dumps({"action": "hangup"})})

    BACKCHANNEL = {"ага", "угу", "да", "ну", "так", "ок", "окей", "ясно", "понятно", "хорошо", "mhm", "sí", "si", "vale",
                   "ya", "claro", "ok", "okay", "yes", "yeah", "oui", "d'accord", "mm", "ммм", "эм", "aha"}

    def on_fragment(self, text: str):
        """Collects pieces of one utterance: the caller's pauses split it into several prompts."""
        text = (text or "").strip()
        if not text:
            return
        self.pending.append(text)
        if self.merge_timer and not self.merge_timer.done():
            self.merge_timer.cancel()
        if self.gen and not self.gen.done():
            self.gen.cancel()  # the caller is still talking — answer the whole thing later
        self.merge_timer = asyncio.create_task(self._flush_after(merge_seconds()))

    async def _flush_after(self, delay: float):
        await asyncio.sleep(delay)
        text = " ".join(self.pending).strip()
        self.pending = []
        if not text:
            return
        self.note("them", text)
        words = [w.strip(".,!?¡¿…").lower() for w in text.split()]
        if self.unsaid and words and len(words) <= 2 and all(w in self.BACKCHANNEL for w in words):
            # just "ага" over our sentence: finish what we were saying instead of starting over
            rest, self.unsaid = self.unsaid, ""
            await self.send({"type": "text", "token": rest, "last": True})
            self.note("agent", rest)
            last = self.history[-1] if self.history else None
            if last and last["role"] == "assistant" and all(b.get("type") == "text" for b in last["content"]):
                last["content"] = [{"type": "text", "text": self.last_spoken}]
            return
        self.unsaid = ""
        self.start_turn(text)

    def start_turn(self, text: str):
        if self.ended or not self.cid:
            return
        prev = self.gen if self.gen and not self.gen.done() else None
        if prev:
            prev.cancel()
        self.gen = asyncio.create_task(self._turn(text, prev))

    async def _turn(self, text: str, prev):
        if prev:
            try:
                await prev
            except BaseException:
                pass
            if asyncio.current_task().cancelling():
                return
        self.repair()
        self.add_user(text)
        try:
            await self.respond()
        except asyncio.CancelledError:
            raise
        except Exception as e:
            log.exception("respond")
            await tg_send(f"⚠️ Секретарь не смог ответить в разговоре: {str(e)[:300]}")

    async def respond(self):
        spoken = ""
        for _ in range(5):
            kw = dict(model=call_model(), max_tokens=300, system=self.system, messages=self.history, tools=self.tools)
            try:
                stream_cm = ai().messages.stream(**_nothink(kw))
                st = await stream_cm.__aenter__()
            except Exception as e:
                if _NO_THINK["ok"] and "thinking" in str(e).lower():
                    _NO_THINK["ok"] = False
                    stream_cm = ai().messages.stream(**kw)
                    st = await stream_cm.__aenter__()
                else:
                    raise
            try:
                async for chunk in st.text_stream:
                    spoken += chunk
                    await self.send({"type": "text", "token": chunk, "last": False})
                final = await st.get_final_message()
            finally:
                await stream_cm.__aexit__(None, None, None)
            blocks = [
                b.model_dump(exclude_none=True)
                for b in final.content
                if b.type in ("text", "tool_use", "thinking", "redacted_thinking")
                and not (b.type == "text" and not b.text.strip())
            ]
            if blocks:
                self.history.append({"role": "assistant", "content": blocks})
            uses = [b for b in final.content if b.type == "tool_use"]
            if not uses:
                break
            await self.send({"type": "text", "token": "", "last": True})
            results = []
            for u in uses:
                out = await self.tool(u.name, u.input or {}, spoken)
                results.append({"type": "tool_result", "tool_use_id": u.id, "content": out})
            self.history.append({"role": "user", "content": results})
            if self.ended:
                break
        if not self.ended:
            await self.send({"type": "text", "token": "", "last": True})
        self.note("agent", spoken)
        self.last_spoken = spoken.strip()
        if spoken.strip() and not self.tts_checked:
            self.tts_checked = True
            asyncio.create_task(self.check_tts())

    async def check_tts(self):
        await asyncio.sleep(6)
        if self.events_seen or self.ended:
            return  # Telnyx reported speech, voice works
        await tg_send("⚠️ Секретарь отправил текст, но Telnyx его не озвучил. Похоже на проблему с голосом (voice) — "
                      "пришли это сообщение Claude.")

    async def tool(self, name: str, inp: dict, spoken: str) -> str:
        if name == "end_call":
            self.outcome = inp.get("outcome", "")
            self.result = inp.get("result") or "done"
            self.hangup_later({"action": "hangup"}, spoken)
            return "hanging up"
        if name == "transfer_to_owner":
            reason = inp.get("reason", "")
            self.outcome = f"переведён на Дена: {reason}"
            asyncio.create_task(tg_send(f"☎️ Секретарь соединяет с тобой: {reason}\nЗвонит: {self.call.get('peer')}"))
            self.hangup_later({"action": "transfer", "reason": reason}, spoken)
            return "transferring"
        if name == "set_language":
            code = inp.get("code")
            if code in LANGS:
                await self.switch_lang(code)
                return f"switched to {code}, continue in that language"
            return "unsupported language"
        if name == "press_keys":
            d = re.sub(r"[^0-9*#wW]", "", inp.get("digits", ""))
            if d:
                await self.send({"type": "sendDigits", "digits": d})
                return f"pressed {d}"
            return "no valid digits"
        if name == "mark_reminder_done":
            src = REMINDER_SRC.get(self.call.get("task_id"))
            if not src:
                return "nothing to mark"
            kind, item_id, occ = src
            r = mark_done(kind, item_id, occ)
            self.outcome = "отмечено как выполненное"
            asyncio.create_task(tg_send(f"✅ Отметил выполненным: {REMINDER_TASKS.get(self.call.get('task_id'), '')}"))
            return r
        if name == "snooze_reminder":
            mins = max(1, int(inp.get("minutes") or 15))
            text = REMINDER_TASKS.get(self.call.get("task_id"), "напоминание")
            return await cal_tool("add_reminder", {"text": text, "at": to_local(time.time() + mins * 60), "channel": "call"})
        if name == "notes_lookup":
            return (await notes_search(inp.get("query", "")))["answer"]
        if name == "note_save":
            n = await note_add(inp.get("text", ""), source="call")
            return f"saved «{n['title']}»" + (" (secret)" if n["secret"] else "")
        if name == "check_inbox":
            return (await inbox_answer("сводка входящих"))["speak"]
        if name == "calendar_command":
            res = await calendar_agent(inp.get("text", ""))
            return res["speak"]
        if name == "place_call":
            try:
                await start_outbound(inp.get("to", ""), inp.get("task", ""), inp.get("language", "auto"))
                return "call started; the result will be sent to Telegram"
            except Exception as e:
                return f"failed: {e}"
        return "unknown tool"

    async def on_digit(self, d: str):
        """Collects keypad digits; '#' or a 2.5 s pause ends the input."""
        if self.dtmf_timer and not self.dtmf_timer.done():
            self.dtmf_timer.cancel()
        if d == "#":
            await self.flush_digits()
            return
        self.dtmf_buf += d
        self.dtmf_timer = asyncio.create_task(self._digits_after(2.5))

    async def _digits_after(self, delay: float):
        await asyncio.sleep(delay)
        await self.flush_digits()

    async def flush_digits(self):
        digits, self.dtmf_buf = self.dtmf_buf, ""
        if not digits:
            return
        keys = {"1": "es", "2": "en", "3": "ru", "4": "fr", "5": "de", "6": "it"}
        early = time.time() - self.t0 < 30
        if (len(digits) == 1 and digits in keys and early and self.call.get("direction") != "out"
                and keys[digits] != self.lang):
            await self.switch_lang(keys[digits])
            self.start_turn(f"[The caller pressed {digits} to switch to {keys[digits]}. Greet them briefly in that "
                            "language and ask how you can help.]")
            return
        self.note("them", f"[набрал на клавиатуре: {digits}]")
        self.start_turn(f"[typed on keypad: {digits}]")

    async def switch_lang(self, code: str):
        self.lang = code
        msg = {"type": "language", "ttsLanguage": code}
        if not auto_lang():  # with multilingual recognition keep listening to every language
            msg["transcriptionLanguage"] = code
        await self.send(msg)

    def hangup_later(self, data: dict, spoken: str):
        self.ended = True
        NEXT_ACTION[self.cid] = data

        async def _go():
            # wait until the goodbye has actually been played
            if self.events_seen:
                t0 = time.time()
                while not self.agent_speaking and time.time() - t0 < 2.5:
                    await asyncio.sleep(0.1)
                t1 = time.time()
                while self.agent_speaking and time.time() - t1 < 15:
                    await asyncio.sleep(0.1)
            else:
                await asyncio.sleep(min(len(spoken) / 13 + 1, 12))
            await asyncio.sleep(0.4)
            await self.send({"type": "end", "handoffData": json.dumps(data)})

        self.timers.append(asyncio.create_task(_go()))

    async def on_interrupt(self, heard: str):
        heard = (heard or "").strip()
        if self.gen and not self.gen.done():
            self.gen.cancel()
            try:
                await self.gen
            except BaseException:
                pass
            self.repair()
            if heard:
                self.add_assistant(heard + " …")
                self.note("agent", heard + " …")
            return
        full = self.last_spoken
        if heard and full.startswith(heard[: max(1, len(heard) - 3)]) and len(full) > len(heard) + 3:
            self.unsaid = full[len(heard):].strip()
        last = self.history[-1] if self.history else None
        if last and last["role"] == "assistant" and all(b.get("type") == "text" for b in last["content"]):
            last["content"] = [{"type": "text", "text": (heard + " …") if heard else "[interrupted]"}]
        for x in reversed(self.transcript):
            if x["who"] == "agent":
                x["text"] = (heard + " …") if heard else x["text"] + " [перебили]"
                break

    async def finish(self):
        if self.merge_timer and not self.merge_timer.done():
            self.merge_timer.cancel()
        if self.pending:
            self.note("them", " ".join(self.pending))
        for t in self.timers:
            t.cancel()
        if self.gen and not self.gen.done():
            self.gen.cancel()
        if not self.cid or self.cid not in LIVE:
            return
        LIVE.pop(self.cid, None)
        db_set(self.cid, ended=time.time(), status="done", lang=self.lang, outcome=self.outcome,
               transcript=json.dumps(self.transcript, ensure_ascii=False),
               journal=json.dumps(self.journal, ensure_ascii=False))
        asyncio.create_task(summarize(self.cid))
        tid = self.call.get("task_id")
        if tid:
            said = [x for x in self.transcript if x["who"] == "them"]
            spoke = bool(said)
            result = self.result or ("done" if spoke else "retry")
            if result == "retry" and len(said) >= 2:
                result = "done"  # a real conversation took place: never call again on our own
            asyncio.create_task(task_result(tid, result, self.outcome or ("никто не ответил" if not spoke else "")))


async def summarize(cid: str):
    c = db_get(cid)
    tr = json.loads(c.get("transcript") or "[]")
    if not [x for x in tr if x["who"] == "them"]:
        summary = "Разговора не было — положили трубку или никто не ответил."
    else:
        text = "\n".join(f'{"Агент" if x["who"] == "agent" else "Собеседник"}: {x["text"]}' for x in tr)
        task = f"Задача звонка: {c['task']}\n" if c.get("task") else ""
        try:
            msg = await ai_create(
                model=SMART_MODEL, max_tokens=600,
                messages=[{"role": "user", "content": (
                    "Сделай для Дена (обращайся на «ты», он мужчина) отчёт по-русски о телефонном разговоре. Без вступлений.\n"
                    "Первая строка: суть в одном-двух предложениях (кто это, чем закончилось, что Дену нужно сделать).\n"
                    "Потом, если задавались вопросы, раздел «Вопросы и ответы:» — по строке на вопрос: «— вопрос: ответ», "
                    "дословно по смыслу, ничего не додумывай. Если ответа не было или он неразборчив, пиши «не расслышал» "
                    "или «не ответил». Расшифровка сделана автоматически и может содержать ошибки распознавания.\n"
                    "Номера телефонов приводи так, как их подтвердил собеседник или набрал на клавиатуре; если номер "
                    "не подтверждён или в нём неверное число цифр, пометь «номер проверь». Если известен номер, с "
                    f"которого звонили ({c.get('peer') or 'скрыт'}), укажи его.\n"
                    f"{task}Итог от агента: {c.get('outcome') or '—'}\nРасшифровка:\n{text}"
                )}],
            )
            summary = text_of(msg)
        except Exception as e:
            log.exception("summary")
            summary = c.get("outcome") or f"Не удалось сделать сводку: {e}"
    db_set(cid, summary=summary)
    if c.get("task_id") and job_for_task(c["task_id"]):
        jt = task_get(c["task_id"]) or {}
        if jt.get("status") in ("done", "calling") and [x for x in tr if x["who"] == "them"]:
            job_step("Итог: " + summary[:300], "done", jt["job_id"])
    if c.get("direction") == "out" and c.get("task") and [x for x in tr if x["who"] == "them"]:
        asyncio.create_task(event_from_call(c, summary))
    try:
        bus_call_result(c, summary)
    except Exception:
        log.exception("bus call result")
    if c.get("direction") == "owner":
        return
    head = (f"📞 Входящий от {c['peer'] or 'скрытого номера'}" if c["direction"] == "in"
            else f"📲 Звонок на {c['peer']}")
    await tg_send(f"{head} · {fmt_time(c['started'])}\n\n{summary}")


# ---------------------------------------------------------------- telnyx API


def tx_headers() -> dict:
    return {"Authorization": f"Bearer {cfg('TELNYX_API_KEY')}", "Content-Type": "application/json"}


def retry_settings() -> tuple:
    try:
        n = max(1, min(10, int(cfg("RETRY_ATTEMPTS") or 3)))
    except ValueError:
        n = 3
    try:
        m = max(2, min(240, int(cfg("RETRY_MINUTES") or 15)))
    except ValueError:
        m = 15
    return n, m


def calling_hours(ts: float) -> float:
    """Moves a retry out of the night: calls only 09:00–21:30 Madrid time."""
    d = datetime.fromtimestamp(ts, TZ)
    if d.hour < 9:
        d = d.replace(hour=9, minute=0, second=0)
    elif d.hour > 21 or (d.hour == 21 and d.minute > 30):
        d = (d + timedelta(days=1)).replace(hour=9, minute=0, second=0)
    return d.timestamp()


def task_get(tid: str) -> dict:
    row = db.execute("SELECT * FROM tasks WHERE id=?", (tid,)).fetchone()
    return dict(row) if row else {}


def task_set(tid: str, **kw):
    db.execute(f"UPDATE tasks SET {', '.join(f'{k}=?' for k in kw)} WHERE id=?", (*kw.values(), tid))
    db.commit()


def task_label(t: dict) -> str:
    return f"{t['contact']} ({t['peer']})" if t.get("contact") else t["peer"]


# ---------------------------------------------------------------- live status of Den's commands
import contextvars
CUR_JOB: contextvars.ContextVar = contextvars.ContextVar("job", default=None)
db.execute("""CREATE TABLE IF NOT EXISTS jobs(
    id TEXT PRIMARY KEY, text TEXT, title TEXT, status TEXT, steps TEXT, created REAL, updated REAL, link TEXT)""")
for _col in ("job_id",):
    try:
        db.execute(f"ALTER TABLE tasks ADD COLUMN {_col} TEXT")
    except sqlite3.OperationalError:
        pass
db.commit()


def job_new(text: str) -> str:
    jid = uuid.uuid4().hex[:10]
    db.execute("INSERT INTO jobs VALUES(?,?,?,?,?,?,?,?)", (jid, text[:500], "", "active",
                                                          json.dumps([{"t": time.time(), "s": "Принял команду"}], ensure_ascii=False),
                                                          time.time(), time.time(), ""))
    db.commit()
    return jid


def job_step(text: str, status: str = "", jid: str | None = None, title: str = "", link: str = ""):
    """Adds a line to the live log of a command (jid, or the command being handled right now)."""
    jid = jid or CUR_JOB.get()
    if not jid:
        return
    r = db.execute("SELECT steps FROM jobs WHERE id=?", (jid,)).fetchone()
    if not r:
        return
    steps = json.loads(r["steps"] or "[]")
    if text and (not steps or steps[-1]["s"] != text):
        steps.append({"t": time.time(), "s": text[:400]})
    sets, vals = ["steps=?", "updated=?"], [json.dumps(steps[-40:], ensure_ascii=False), time.time()]
    for k, v in (("status", status), ("title", title), ("link", link)):
        if v:
            sets.append(f"{k}=?")
            vals.append(v)
    db.execute(f"UPDATE jobs SET {', '.join(sets)} WHERE id=?", (*vals, jid))
    db.commit()


def job_for_task(tid: str):
    t = task_get(tid) if tid else None
    return (t or {}).get("job_id") or None


def job_by_link(link: str):
    r = db.execute("SELECT id FROM jobs WHERE link=? ORDER BY created DESC", (link,)).fetchone()
    return r["id"] if r else None


async def start_outbound(to: str, task: str, lang: str = "es", contact: str = "") -> str:
    """Creates a call task (with automatic retries) and dials the first attempt. Returns the task id."""
    if not (cfg("TELNYX_API_KEY") and cfg("TELNYX_APP_ID") and cfg("TELNYX_NUMBER")):
        raise RuntimeError("не заполнена вкладка «Настройка» (Telnyx)")
    to = norm(to)
    if not re.fullmatch(r"\+\d{8,15}", to):
        raise ValueError(f"неверный номер: {to or 'пусто'}")
    allowed = allowed_prefixes()
    if allowed and not any(to.startswith(p) for p in allowed):
        raise ValueError(f"на {to[:3]}… звонить не разрешено. Разрешено: {', '.join(allowed)} "
                         "(меняется во вкладке «Настройка»)")
    if not task.strip():
        raise ValueError("пустая задача")
    lang = lang_in_text(task) or (lang if lang in LANGS else lang_for(to))
    n, _ = retry_settings()
    tid = uuid.uuid4().hex[:10]
    db.execute("INSERT INTO tasks(id, peer, contact, task, lang, created, attempts, max_attempts, status, next_at, last_result, job_id) "
               "VALUES(?,?,?,?,?,?,?,?,?,?,?,?)", (tid, to, contact or "", task, lang, time.time(), 0, n, "calling", None, "",
                                                 CUR_JOB.get() or ""))
    db.commit()
    job_step("", link=f"task:{tid}")
    await dial_task(tid, raise_errors=True)
    return tid


async def dial_task(tid: str, raise_errors: bool = False):
    t = task_get(tid)
    if not t or t["status"] in ("done", "failed", "cancelled"):
        return
    attempt = (t["attempts"] or 0) + 1
    task_set(tid, attempts=attempt, status="calling", next_at=None)
    job_step(f"Набираю {t['contact'] or t['peer']}" + (f" (попытка {attempt})" if attempt > 1 else ""), "active", job_for_task(tid))
    cid = uuid.uuid4().hex[:12]
    db_new(cid, direction="out", peer=t["peer"], started=time.time(), status="dialing", lang=t["lang"],
           task=t["task"], transcript="[]", task_id=tid)
    body = {
        "To": t["peer"], "From": cfg("TELNYX_NUMBER"),
        "Url": hook("outbound", cid), "UrlMethod": "POST",
        "StatusCallback": hook("status", cid), "StatusCallbackMethod": "POST",
    }
    try:
        async with httpx.AsyncClient(timeout=20) as h:
            r = await h.post(f"{TELNYX}/texml/calls/{cfg('TELNYX_APP_ID')}", headers=tx_headers(), json=body)
        if r.status_code >= 300:
            raise RuntimeError(f"Telnyx {r.status_code}: {r.text[:300]}")
        d = r.json().get("data", {})
        db_set(cid, sid=d.get("call_sid") or d.get("sid") or "")
    except Exception as e:
        db_set(cid, status="failed", outcome=f"ошибка: {e}", ended=time.time())
        if raise_errors and attempt == 1:
            task_set(tid, status="failed", last_result=f"ошибка: {e}")
            raise
        await task_result(tid, "retry", f"ошибка набора: {str(e)[:120]}")


async def task_result(tid: str, result: str, why: str = ""):
    t = task_get(tid)
    if not t or t["status"] != "calling":
        return  # already decided (done / waiting for retry / cancelled) — ignore late duplicates
    label = task_label(t)
    jid = t.get("job_id")
    if result == "done":
        task_set(tid, status="done", last_result=why)
        return
    if result == "failed" or t["attempts"] >= t["max_attempts"]:
        job_step(f"Не получилось: {why}", "error", jid)
    else:
        _, mins_ = retry_settings()
        job_step(f"{why} — повторю через {mins_} мин (попытка {t['attempts']} из {t['max_attempts']})", "wait", jid)
    if result == "failed":
        task_set(tid, status="failed", last_result=why)
        await tg_send(f"❌ Задание не выполнено: {label}. {why}\n\nЗадача: {t['task']}")
        return
    if t["attempts"] >= t["max_attempts"]:
        task_set(tid, status="failed", last_result=why)
        await tg_send(f"❌ Не дозвонился на {label} за {t['attempts']} попытки: {why}.\n\nЗадача: {t['task']}")
        return
    _, minutes = retry_settings()
    nxt = calling_hours(time.time() + minutes * 60)
    task_set(tid, status="waiting", next_at=nxt, last_result=why)
    await tg_send(f"📵 {label}: {why} (попытка {t['attempts']} из {t['max_attempts']}). "
                  f"Повторю в {datetime.fromtimestamp(nxt, TZ).strftime('%H:%M')}.\n\nЗадача: {t['task']}\n/stop — отменить")


def active_tasks() -> list:
    rows = db.execute("SELECT * FROM tasks WHERE status IN ('calling','waiting') ORDER BY created DESC").fetchall()
    return [dict(r) for r in rows]


def tasks_text() -> str:
    rows = db.execute("SELECT * FROM tasks ORDER BY created DESC LIMIT 6").fetchall()
    if not rows:
        return "Заданий на звонки пока не было."
    names = {"calling": "звоню сейчас", "waiting": "жду повтора", "done": "выполнено",
             "failed": "не выполнено", "cancelled": "отменено"}
    out = []
    for r in rows:
        line = f"• {task_label(dict(r))}: {names.get(r['status'], r['status'])}, попыток {r['attempts']} из {r['max_attempts']}"
        if r["status"] == "waiting" and r["next_at"]:
            line += f", следующая в {datetime.fromtimestamp(r['next_at'], TZ).strftime('%H:%M')}"
        if r["last_result"]:
            line += f" ({r['last_result']})"
        out.append(line + f"\n  {r['task'][:120]}")
    return "\n".join(out)


def cancel_tasks(tid: str = "") -> int:
    for r in db.execute("SELECT job_id FROM tasks WHERE status IN ('calling','waiting')" + (" AND id=?" if tid else " AND status='waiting'"),
                        (tid,) if tid else ()).fetchall():
        if r["job_id"]:
            job_step("Отменено", "error", r["job_id"])
    if tid:
        cur = db.execute("UPDATE tasks SET status='cancelled', next_at=NULL WHERE id=? AND status IN ('calling','waiting')", (tid,))
    else:
        cur = db.execute("UPDATE tasks SET status='cancelled', next_at=NULL WHERE status='waiting'")
    db.commit()
    return cur.rowcount


async def task_loop():
    # a restart in the middle of a call leaves tasks hanging in "calling": retry them
    db.execute("UPDATE tasks SET status='waiting', next_at=? WHERE status='calling'", (time.time() + 60,))
    db.commit()
    while True:
        try:
            stale = db.execute("SELECT id, task_id FROM calls WHERE status IN ('dialing','live') AND started<?",
                               (time.time() - 15 * 60,)).fetchall()
            for c in stale:
                if c["id"] not in LIVE:
                    db_set(c["id"], status="failed", outcome="нет ответа от линии", ended=time.time())
                    if c["task_id"]:
                        await task_result(c["task_id"], "retry", "нет ответа от линии")
            due = db.execute("SELECT id FROM tasks WHERE status='waiting' AND next_at<=?", (time.time(),)).fetchall()
            for r in due:
                await dial_task(r["id"])
        except asyncio.CancelledError:
            raise
        except Exception:
            log.exception("task loop")
        await asyncio.sleep(20)


async def run_checks(fix: bool = True) -> list:
    """Checks every key and, where possible, fixes the Telnyx wiring itself."""
    res = []

    def add(name, ok, text):
        res.append({"name": name, "ok": ok, "text": text})

    # Claude
    if not cfg("ANTHROPIC_API_KEY"):
        add("Claude", False, "Вставь ключ Anthropic.")
    else:
        try:
            await ai().models.list(limit=1)
            add("Claude", True, "Ключ работает.")
        except Exception as e:
            add("Claude", False, f"Ключ не принят: {str(e)[:120]}")

    # Telnyx
    key, app_id, num = cfg("TELNYX_API_KEY"), cfg("TELNYX_APP_ID"), norm(cfg("TELNYX_NUMBER"))
    if not key:
        add("Telnyx", False, "Вставь API-ключ Telnyx.")
    else:
        try:
            async with httpx.AsyncClient(timeout=20) as h:
                r = await h.get(f"{TELNYX}/phone_numbers", headers=tx_headers(), params={"filter[phone_number]": num})
                if r.status_code == 401:
                    add("Telnyx", False, "API-ключ не принят.")
                else:
                    pns = r.json().get("data", []) if num else []
                    if not num:
                        add("Номер", False, "Укажи свой номер Telnyx.")
                    elif not pns:
                        add("Номер", False, f"Номер {num} не найден в аккаунте Telnyx.")
                    else:
                        pn = pns[0]
                        if not app_id:
                            add("Номер", True, f"{num} найден.")
                        elif pn.get("connection_id") == app_id:
                            add("Номер", True, f"{num} подключён к приложению.")
                        elif fix:
                            p = await h.patch(f"{TELNYX}/phone_numbers/{pn['id']}", headers=tx_headers(), json={"connection_id": app_id})
                            add("Номер", p.status_code < 300,
                                f"{num} подключил к приложению сам." if p.status_code < 300
                                else f"Не смог подключить номер к приложению: {p.text[:150]}")
                    if not app_id:
                        add("Приложение", False, "Вставь Application ID приложения TeXML.")
                    else:
                        a = await h.get(f"{TELNYX}/texml_applications/{app_id}", headers=tx_headers())
                        if a.status_code >= 300:
                            add("Приложение", False, "Приложение TeXML с таким ID не найдено.")
                        else:
                            ad = a.json().get("data", {})
                            if ad.get("voice_url") == hook("incoming"):
                                add("Приложение", True, "Адрес для звонков указан верно.")
                            elif fix:
                                p = await h.patch(f"{TELNYX}/texml_applications/{app_id}", headers=tx_headers(),
                                                  json={"voice_url": hook("incoming"), "voice_method": "post",
                                                        "friendly_name": ad.get("friendly_name") or "Secretary"})
                                add("Приложение", p.status_code < 300,
                                    "Адрес для звонков прописал сам." if p.status_code < 300
                                    else "Впиши адрес для звонков вручную (он ниже).")
                            ob = (ad.get("outbound") or {}).get("outbound_voice_profile_id")
                            add("Исходящие", bool(ob),
                                "Профиль исходящих подключён." if ob
                                else "Привяжи к приложению Outbound Voice Profile с разрешённой Испанией.")
        except Exception as e:
            add("Telnyx", False, f"Нет связи с Telnyx: {str(e)[:120]}")

    # Smart Bubbles
    if sb_base():
        try:
            acc = (await sb_call("GET", "/secretary/accounts")).get("accounts", [])
            add("Smart Bubbles", True, f"Связь есть, аккаунтов: {len(acc)}.")
        except Exception as e:
            add("Smart Bubbles", False, f"Нет связи с SB: {str(e)[:120]}")

    # TomTom (travel time)
    if cfg("TOMTOM_KEY"):
        try:
            g = await geocode(cfg("HOME_ADDRESS") or "Marbella")
            add("Дорога (TomTom)", bool(g), "Ключ работает." if g else "Ключ не принят или адрес не найден.")
        except Exception as e:
            add("Дорога (TomTom)", False, f"Ошибка: {str(e)[:100]}")

    # Mobile and Telegram
    add("Твой мобильный", bool(cfg("OWNER_MOBILE")),
        "Указан." if cfg("OWNER_MOBILE") else "Укажи, чтобы секретарь мог соединять с тобой.")
    if not cfg("TELEGRAM_BOT_TOKEN"):
        add("Telegram", False, "Вставь токен бота — без него сводки будут только здесь.")
    else:
        me = await tg_api("getMe")
        if not (me or {}).get("ok"):
            add("Telegram", False, "Токен бота не принят.")
        elif not load_state().get("tg_chat"):
            add("Telegram", False, f"Отправь боту @{me['result']['username']}:  /start {SETUP_CODE}")
        else:
            add("Telegram", True, f"Бот @{me['result']['username']} привязан.")
    return res


# ---------------------------------------------------------------- calendar

db.execute("""CREATE TABLE IF NOT EXISTS cal_events(
    id TEXT PRIMARY KEY, title TEXT, start REAL, end REAL, all_day INTEGER, rrule TEXT, location TEXT, notes TEXT,
    remind TEXT, channel TEXT, source TEXT, created REAL, status TEXT)""")
db.execute("""CREATE TABLE IF NOT EXISTS cal_todos(
    id TEXT PRIMARY KEY, text TEXT, due REAL, priority INTEGER, status TEXT, created REAL, done_at REAL)""")
db.execute("""CREATE TABLE IF NOT EXISTS cal_reminders(
    id TEXT PRIMARY KEY, text TEXT, at REAL, rrule TEXT, channel TEXT, status TEXT, created REAL)""")
db.execute("CREATE TABLE IF NOT EXISTS cal_sent(key TEXT PRIMARY KEY, at REAL)")
db.execute("CREATE TABLE IF NOT EXISTS cal_done(key TEXT PRIMARY KEY, at REAL)")
db.execute("""CREATE TABLE IF NOT EXISTS mail_watch(
    id TEXT PRIMARY KEY, pattern TEXT, channels TEXT, once INTEGER, note TEXT, created REAL, status TEXT, hits INTEGER)""")
try:
    db.execute("ALTER TABLE cal_reminders ADD COLUMN todo_id TEXT")
except sqlite3.OperationalError:
    pass
db.execute("""CREATE TABLE IF NOT EXISTS phone_events(
    id TEXT PRIMARY KEY, title TEXT, start REAL, end REAL, all_day INTEGER, location TEXT, calendar TEXT)""")
db.execute("CREATE TABLE IF NOT EXISTS app_notes(id INTEGER PRIMARY KEY AUTOINCREMENT, at REAL, text TEXT)")
db.commit()

WD = ["MO", "TU", "WE", "TH", "FR", "SA", "SU"]
WD_RU = ["понедельник", "вторник", "среда", "четверг", "пятница", "суббота", "воскресенье"]


def to_ts(local_iso: str) -> float:
    """'2026-11-17T19:00' or '2026-11-17' in Madrid time → unix time."""
    s = (local_iso or "").strip().replace(" ", "T")
    d = datetime.fromisoformat(s[:16] if "T" in s else s)
    if d.tzinfo is None:
        d = d.replace(tzinfo=TZ)
    return d.timestamp()


def to_local(ts: float, with_time: bool = True) -> str:
    d = datetime.fromtimestamp(ts, TZ)
    return d.strftime("%Y-%m-%dT%H:%M") if with_time else d.strftime("%Y-%m-%d")


def human(ts: float, all_day: bool = False) -> str:
    d = datetime.fromtimestamp(ts, TZ)
    base = f"{WD_RU[d.weekday()]} {d.day:02d}.{d.month:02d}"
    return base if all_day else f"{base} {d.strftime('%H:%M')}"


def occurrences(start: float, rrule: str, frm: float, to: float, limit: int = 400) -> list:
    """Expands a simple RRULE (DAILY/WEEKLY/MONTHLY/YEARLY, INTERVAL, BYDAY, UNTIL, COUNT) in [frm, to]."""
    if not rrule:
        return [start] if frm <= start <= to else []
    p = dict(x.split("=", 1) for x in rrule.upper().split(";") if "=" in x)
    freq, step = p.get("FREQ", "DAILY"), max(1, int(p.get("INTERVAL", "1") or 1))
    count = int(p["COUNT"]) if p.get("COUNT") else None
    until = to_ts(f"{p['UNTIL'][:4]}-{p['UNTIL'][4:6]}-{p['UNTIL'][6:8]}T23:59") if p.get("UNTIL") else None
    byday = [WD.index(x[-2:]) for x in p.get("BYDAY", "").split(",") if x[-2:] in WD]
    d0 = datetime.fromtimestamp(start, TZ)
    out, n, i = [], 0, 0
    while i < 3000 and len(out) < limit:
        if freq == "WEEKLY" and byday:
            week = d0 + timedelta(weeks=i * step)
            monday = week - timedelta(days=week.weekday())
            cands = [monday.replace(hour=d0.hour, minute=d0.minute) + timedelta(days=b) for b in sorted(byday)]
            cands = [c for c in cands if c >= d0]
        elif freq == "WEEKLY":
            cands = [d0 + timedelta(weeks=i * step)]
        elif freq == "MONTHLY":
            m = d0.month - 1 + i * step
            try:
                cands = [d0.replace(year=d0.year + m // 12, month=m % 12 + 1)]
            except ValueError:
                cands = []
        elif freq == "YEARLY":
            try:
                cands = [d0.replace(year=d0.year + i * step)]
            except ValueError:
                cands = []
        else:
            cands = [d0 + timedelta(days=i * step)]
        i += 1
        stop = False
        for c in cands:
            ts = c.timestamp()
            n += 1
            if (count and n > count) or (until and ts > until) or ts > to:
                stop = True
                break
            if ts >= frm:
                out.append(ts)
        if stop:
            break
    return out


def agenda(frm: float, to: float, with_phone: bool = True) -> list:
    items = []
    if with_phone:
        for r in db.execute("SELECT * FROM phone_events WHERE end>=? AND start<=?", (frm, to)).fetchall():
            e = dict(r)
            items.append({**e, "rrule": "", "remind": "[]", "channel": "", "notes": "", "source": "phone",
                          "status": "active", "occ": e["start"], "occ_end": e["end"] or e["start"]})
    for r in db.execute("SELECT * FROM cal_events WHERE status='active'").fetchall():
        e = dict(r)
        dur = (e["end"] or e["start"]) - e["start"]
        for ts in occurrences(e["start"], e["rrule"] or "", frm - max(dur, 0), to):
            items.append({**e, "occ": ts, "occ_end": ts + dur})
    return sorted(items, key=lambda x: x["occ"])


def is_phone(e: dict) -> bool:
    return e.get("source") == "phone"


def open_todos() -> list:
    return [dict(r) for r in db.execute(
        "SELECT * FROM cal_todos WHERE status='open' ORDER BY COALESCE(due, 9e12), priority DESC").fetchall()]


def agenda_text(days: int = 14) -> str:
    now = time.time()
    lines = [f"- [{e['id']}] {human(e['occ'], bool(e['all_day']))}"
             + (f"–{datetime.fromtimestamp(e['occ_end'], TZ).strftime('%H:%M')}" if e['occ_end'] > e['occ'] and not e['all_day'] else "")
             + f" {e['title']}" + (f" @ {e['location']}" if e['location'] else "")
             + (" (повтор)" if e['rrule'] else "") + (" (из календаря телефона, только чтение)" if is_phone(e) else "")
             for e in agenda(now - 3600, now + days * 86400)[:80]]
    todos = [f"- [{t['id']}] {t['text']}" + (f" (срок {human(t['due'])})" if t['due'] else "") for t in open_todos()[:40]]
    rems = [f"- [{r['id']}] {human(r['at'])}: {r['text']}" + (" (повтор)" if r['rrule'] else "")
            for r in db.execute("SELECT * FROM cal_reminders WHERE status='active' ORDER BY at LIMIT 30").fetchall()]
    return ("События (ближайшие 2 недели):\n" + ("\n".join(lines) or "—") +
            "\n\nДела:\n" + ("\n".join(todos) or "—") +
            "\n\nОтдельные напоминания:\n" + ("\n".join(rems) or "—"))


def dur(kind: str) -> int:
    defaults = {"CALL": 15, "MEETING": 60, "MEAL": 120}
    try:
        return max(5, min(600, int(cfg("DUR_" + kind) or defaults[kind])))
    except ValueError:
        return defaults[kind]


def free_slots(day: str, need_min: int = 30, frm: str = "09:00", to: str = "21:00") -> list:
    """Free windows on a local date between frm and to, taking all events (incl. phone) into account."""
    a, b = to_ts(f"{day}T{frm}"), to_ts(f"{day}T{to}")
    busy = sorted((max(e["occ"], a), min(e["occ_end"], b)) for e in agenda(a, b)
                  if not e["all_day"] and e["occ_end"] > a and e["occ"] < b)
    out, cur = [], a
    for s_, e_ in busy:
        if s_ - cur >= need_min * 60:
            out.append((cur, s_))
        cur = max(cur, e_)
    if b - cur >= need_min * 60:
        out.append((cur, b))
    return out


def is_done(key: str) -> bool:
    return bool(db.execute("SELECT 1 FROM cal_done WHERE key=?", (key,)).fetchone())


def stop_reminder_calls(text: str):
    """Cancels queued/retrying reminder calls with this text (they stop calling and texting)."""
    t = (text or "").strip().lower()
    for tid, txt in list(REMINDER_TASKS.items()):
        if t and (t in txt.lower() or txt.lower() in t):
            cancel_tasks(tid)
            REMINDER_TASKS.pop(tid, None)


def mark_done(kind: str, item_id: str, occ: float | None = None) -> str:
    if kind == "event":
        e = db.execute("SELECT * FROM cal_events WHERE id=?", (item_id,)).fetchone()
        if not e:
            return "no such event"
        key = f"{item_id}:{int(occ or e['start'])}"
        db.execute("INSERT OR REPLACE INTO cal_done VALUES(?,?)", (key, time.time()))
        db.commit()
        stop_reminder_calls(e["title"])
        return "done"
    if kind == "reminder":
        r = db.execute("SELECT * FROM cal_reminders WHERE id=?", (item_id,)).fetchone()
        if not r:
            return "no such reminder"
        nxt = occurrences(r["at"], r["rrule"], time.time() + 60, time.time() + 400 * 86400, 1) if r["rrule"] else []
        if nxt:  # repeating: skip only this time
            db.execute("UPDATE cal_reminders SET at=? WHERE id=?", (nxt[0], item_id))
        else:
            db.execute("UPDATE cal_reminders SET status='done' WHERE id=?", (item_id,))
        db.commit()
        stop_reminder_calls(r["text"])
        return "done"
    if kind == "todo":
        t = db.execute("SELECT * FROM cal_todos WHERE id=?", (item_id,)).fetchone()
        if not t:
            return "no such todo"
        db.execute("UPDATE cal_todos SET status='done', done_at=? WHERE id=?", (time.time(), item_id))
        # reminders made for this to-do (linked, or with the same words) end too
        for r in db.execute("SELECT * FROM cal_reminders WHERE status='active'").fetchall():
            a_, b_ = r["text"].strip().lower(), t["text"].strip().lower()
            if r["todo_id"] == item_id or a_ in b_ or b_ in a_:
                db.execute("UPDATE cal_reminders SET status='done' WHERE id=?", (r["id"],))
                stop_reminder_calls(r["text"])
        db.commit()
        stop_reminder_calls(t["text"])
        return "done"
    return "unknown"


def default_channel() -> str:
    c = cfg("REMIND_CHANNEL")
    return c if c in ("telegram", "call", "app") else "telegram"


CAL_TOOLS = [
    {"name": "add_event", "description": "Create a calendar event. Times are local Madrid time, ISO like 2026-11-17T19:00 (date only for all-day).",
     "input_schema": {"type": "object", "properties": {
         "title": {"type": "string"}, "start": {"type": "string"}, "end": {"type": "string"},
         "all_day": {"type": "boolean"}, "location": {"type": "string"}, "notes": {"type": "string"},
         "rrule": {"type": "string", "description": "Repeat rule, e.g. FREQ=WEEKLY;BYDAY=TU or FREQ=DAILY;COUNT=5. Empty = once."},
         "remind_minutes": {"type": "array", "items": {"type": "integer"}, "description": "Reminders, minutes before start, e.g. [60] or [1440, 60]"},
         "channels": {"type": "array", "items": {"type": "string", "enum": ["telegram", "call", "app"]},
                      "description": "How to remind. Several at once are fine, e.g. [\"call\", \"telegram\"]. Omit for the default."}},
         "required": ["title", "start"]}},
    {"name": "update_event", "description": "Change an event by id: any of the fields of add_event.",
     "input_schema": {"type": "object", "properties": {
         "id": {"type": "string"}, "title": {"type": "string"}, "start": {"type": "string"}, "end": {"type": "string"},
         "all_day": {"type": "boolean"}, "location": {"type": "string"}, "notes": {"type": "string"}, "rrule": {"type": "string"},
         "remind_minutes": {"type": "array", "items": {"type": "integer"}},
         "channels": {"type": "array", "items": {"type": "string", "enum": ["telegram", "call", "app"]}}}, "required": ["id"]}},
    {"name": "delete_event", "description": "Cancel/delete an event by id.",
     "input_schema": {"type": "object", "properties": {"id": {"type": "string"}}, "required": ["id"]}},
    {"name": "list_events", "description": "Events between two local dates (inclusive), e.g. to answer 'what do I have on the weekend'.",
     "input_schema": {"type": "object", "properties": {"from": {"type": "string"}, "to": {"type": "string"}}, "required": ["from", "to"]}},
    {"name": "add_todo", "description": "Add a to-do (task without a fixed time). Optional due (local ISO) and priority 1-3.",
     "input_schema": {"type": "object", "properties": {"text": {"type": "string"}, "due": {"type": "string"},
                                                       "priority": {"type": "integer"}}, "required": ["text"]}},
    {"name": "complete_todo", "description": "Mark a to-do done (or delete=true to remove it).",
     "input_schema": {"type": "object", "properties": {"id": {"type": "string"}, "delete": {"type": "boolean"}}, "required": ["id"]}},
    {"name": "add_reminder", "description": "A standalone reminder at a time (local ISO), optionally repeating (rrule).",
     "input_schema": {"type": "object", "properties": {"text": {"type": "string"}, "at": {"type": "string"}, "rrule": {"type": "string"},
                                                       "channels": {"type": "array", "items": {"type": "string", "enum": ["telegram", "call", "app"]},
                                                                    "description": "Several at once are fine. ONE reminder per moment — never create duplicates for different channels."},
                                                       "todo_id": {"type": "string", "description": "If this reminds about a to-do, its id (so ticking the to-do stops the reminder)."}},
                      "required": ["text", "at"]}},
    {"name": "mark_done", "description": "Den says something is done/handled: stop all further reminders for it (calls and Telegram).",
     "input_schema": {"type": "object", "properties": {"kind": {"type": "string", "enum": ["event", "reminder", "todo"]},
                                                       "id": {"type": "string"}}, "required": ["kind", "id"]}},
    {"name": "delete_reminder", "description": "Delete a standalone reminder by id.",
     "input_schema": {"type": "object", "properties": {"id": {"type": "string"}}, "required": ["id"]}},
    {"name": "find_free_time", "description": "Free windows on a date (local YYYY-MM-DD) of at least N minutes, between from/to (HH:MM).",
     "input_schema": {"type": "object", "properties": {"date": {"type": "string"}, "minutes": {"type": "integer"},
                                                       "from": {"type": "string"}, "to": {"type": "string"}}, "required": ["date"]}},
    {"name": "set_briefing", "description": "Daily morning briefing: time HH:MM local (empty to switch off) and channel.",
     "input_schema": {"type": "object", "properties": {"time": {"type": "string"},
                                                       "channel": {"type": "string", "enum": ["telegram", "call", "app"]}},
                      "required": ["time"]}},
]


def _ch(v) -> str:
    """'call' / ['call', 'telegram'] / 'telegram,call' → 'call,telegram' ('' = default channel)."""
    if isinstance(v, dict):
        v = v.get("channels") or v.get("channel") or ""
    items = v if isinstance(v, list) else str(v or "").replace("+", ",").split(",")
    out = [x.strip() for x in items if x and x.strip() in ("telegram", "call", "app")]
    return ",".join(dict.fromkeys(out))


async def cal_tool(name: str, a: dict) -> str:
    try:
        if name == "add_event":
            eid = uuid.uuid4().hex[:8]
            st = to_ts(a["start"])
            en = to_ts(a["end"]) if a.get("end") else (st + 3600 if not a.get("all_day") else st)
            db.execute("INSERT INTO cal_events VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",
                       (eid, a["title"], st, en, 1 if a.get("all_day") else 0, a.get("rrule") or "", a.get("location") or "",
                        a.get("notes") or "", json.dumps(a.get("remind_minutes") or []), _ch(a),
                        a.get("source") or "voice", time.time(), "active"))
            db.commit()
            clash = [e for e in agenda(st - 60, en + 60) if e["id"] != eid and not e["all_day"] and e["occ"] < en and e["occ_end"] > st]
            return f"created {eid}: {human(st, bool(a.get('all_day')))}" + (
                f". CONFLICT with: {', '.join(e['title'] + ' ' + human(e['occ']) for e in clash)}" if clash else "")
        if name == "update_event":
            e = db.execute("SELECT * FROM cal_events WHERE id=?", (a["id"],)).fetchone()
            if not e:
                return "no such event"
            upd = {}
            for k in ("title", "location", "notes", "rrule"):
                if k in a:
                    upd[k] = a[k] or ""
            if "start" in a:
                upd["start"] = to_ts(a["start"])
                upd["end"] = to_ts(a["end"]) if a.get("end") else upd["start"] + ((e["end"] or e["start"]) - e["start"])
            elif a.get("end"):
                upd["end"] = to_ts(a["end"])
            if "all_day" in a:
                upd["all_day"] = 1 if a["all_day"] else 0
            if "remind_minutes" in a:
                upd["remind"] = json.dumps(a["remind_minutes"] or [])
            if "channel" in a or "channels" in a:
                upd["channel"] = _ch(a)
            if upd:
                db.execute(f"UPDATE cal_events SET {', '.join(f'{k}=?' for k in upd)} WHERE id=?", (*upd.values(), a["id"]))
                db.commit()
            return "updated"
        if name == "delete_event":
            db.execute("UPDATE cal_events SET status='deleted' WHERE id=?", (a["id"],))
            db.commit()
            return "deleted"
        if name == "list_events":
            items = agenda(to_ts(a["from"][:10]), to_ts(a["to"][:10] + "T23:59"))
            return "\n".join(f"[{e['id']}] {human(e['occ'], bool(e['all_day']))} {e['title']}" for e in items) or "no events"
        if name == "add_todo":
            tid = uuid.uuid4().hex[:8]
            db.execute("INSERT INTO cal_todos VALUES(?,?,?,?,?,?,?)",
                       (tid, a["text"], to_ts(a["due"]) if a.get("due") else None, int(a.get("priority") or 2), "open",
                        time.time(), None))
            db.commit()
            return f"todo {tid} added"
        if name == "complete_todo":
            if a.get("delete"):
                db.execute("DELETE FROM cal_todos WHERE id=?", (a["id"],))
                db.commit()
                return "ok"
            return mark_done("todo", a["id"])
        if name == "mark_done":
            return mark_done(a.get("kind", "event"), a["id"])
        if name == "add_reminder":
            rid = uuid.uuid4().hex[:8]
            at = to_ts(a["at"])
            if at < time.time() - 60 and not a.get("rrule"):
                return "that time is in the past — ask Den"
            same = db.execute("SELECT * FROM cal_reminders WHERE status='active' AND ABS(at-?)<120", (at,)).fetchall()
            for r in same:
                if r["text"].strip().lower() == a["text"].strip().lower():
                    chans = _ch((r["channel"] or default_channel()).split(",") + (_ch(a) or default_channel()).split(","))
                    db.execute("UPDATE cal_reminders SET channel=? WHERE id=?", (chans, r["id"]))
                    db.commit()
                    return f"merged into existing reminder {r['id']} (channels: {chans})"
            db.execute("INSERT INTO cal_reminders(id, text, at, rrule, channel, status, created, todo_id) VALUES(?,?,?,?,?,?,?,?)",
                       (rid, a["text"], at, a.get("rrule") or "", _ch(a), "active", time.time(), a.get("todo_id") or ""))
            db.commit()
            return f"reminder {rid} at {human(at)}"
        if name == "delete_reminder":
            db.execute("UPDATE cal_reminders SET status='deleted' WHERE id=?", (a["id"],))
            db.commit()
            return "deleted"
        if name == "find_free_time":
            slots = free_slots(a["date"][:10], int(a.get("minutes") or 30), a.get("from") or "09:00", a.get("to") or "21:00")
            return "; ".join(f"{datetime.fromtimestamp(x, TZ).strftime('%H:%M')}–{datetime.fromtimestamp(y, TZ).strftime('%H:%M')}"
                             for x, y in slots) or "no free time"
        if name == "set_briefing":
            t = (a.get("time") or "").strip()
            if t and not re.fullmatch(r"\d{1,2}:\d{2}", t):
                return "bad time"
            cfg_save({"BRIEF_TIME": t, "BRIEF_CHANNEL": (_ch(a) or default_channel()).split(",")[0]})
            return f"briefing {'off' if not t else 'at ' + t}"
    except Exception as e:
        return f"error: {e}"
    return "unknown tool"


async def calendar_agent(text: str) -> dict:
    """Runs Den's calendar command with tools; returns reply + short spoken confirmation."""
    system = f"""You are Den's calendar secretary. Now: {now_str()} (Europe/Madrid, {datetime.now(TZ).strftime('%Y-%m-%d')}).
Default reminder channel: {default_channel()} (telegram / call = the secretary phones Den / app).
Morning briefing: {cfg('BRIEF_TIME') or 'off'}.

{agenda_text()}

Do what Den asks using the tools: create, move, cancel events; to-dos; standalone reminders; morning briefing.
Events marked «из календаря телефона» are read-only for you: take them into account (conflicts, «что у меня»), but to change
them tell Den to edit them in his phone calendar.
Resolve relative dates ("послезавтра", "в пятницу", "через неделю") to exact local dates. If a date/time is truly ambiguous,
don't guess — ask one short question in your final answer and do nothing. If Den asks to be reminded but gives no lead time,
use 15 minutes before for events. If a new event overlaps another, still create it but mention the clash.
«Напомни звонком и в Telegram» = ONE reminder with channels ["call", "telegram"], never two reminders.
WHAT TO CREATE:
- Anything that takes Den's time — a call he must make («позвонить Артёму», «созвон»), a meeting, a visit, a doctor, a meal,
  a trip — is an EVENT (add_event) with a duration, even if he says «напомни». Default durations: call {dur('CALL')} min,
  meeting/visit {dur('MEETING')} min, lunch/dinner {dur('MEAL')} min, unless he says otherwise. Reminder for such events:
  remind_minutes [0] (at the start) unless he asks for another lead time; channels as he says.
- Only a nudge that takes no time («выпить витамины», «проверить почту», «вынести мусор») is a REMINDER (add_reminder).
- Something to do without a fixed time («купить подарок до пятницы») is a TO-DO (add_todo) with a due date.
- Another time zone («в 12:45 по Москве»): convert to Madrid time and put the original in notes («12:45 Мск»).
- «Найди время…» → find_free_time, then propose; create only if he asked to.
Final answer in Russian, informal «ты», Den is a man: start with «Принял.» (or answer the question), then repeat exactly what you
recorded — what, day of week + date, time, place, reminder. 1–3 short sentences, no ids, no markdown."""
    history = [{"role": "user", "content": text}]
    for _ in range(6):
        msg = await ai_create(model=SMART_MODEL, max_tokens=700, system=system, messages=history, tools=CAL_TOOLS)
        uses = [b for b in msg.content if b.type == "tool_use"]
        history.append({"role": "assistant", "content": [b.model_dump(exclude_none=True) for b in msg.content
                                                          if b.type in ("text", "tool_use", "thinking", "redacted_thinking")]})
        if not uses:
            answer = text_of(msg) or "Готово."
            return {"reply": "🗓 " + answer, "speak": answer}
        results = [{"type": "tool_result", "tool_use_id": u.id, "content": await cal_tool(u.name, u.input or {})} for u in uses]
        history.append({"role": "user", "content": results})
    return {"reply": "🗓 Готово.", "speak": "Готово."}


async def notify(text: str, channel: str = "", src: tuple | None = None):
    """Delivers a reminder through every channel listed ('call,telegram'). src = (kind, id, occ) to mark done by voice."""
    chans = (_ch(channel) or default_channel()).split(",")
    db.execute("INSERT INTO app_notes(at, text) VALUES(?,?)", (time.time(), text))
    db.commit()
    tg_done = False
    for ch in chans:
        if ch == "call":
            ok = await notify_call(text, src)
            if not ok and not tg_done and "telegram" not in chans:
                await tg_send(f"⏰ {text}")
                tg_done = True
        elif ch == "telegram" and not tg_done:
            await tg_send(f"⏰ {text}")
            tg_done = True


async def notify_call(text: str, src: tuple | None = None) -> bool:
    if cfg("OWNER_MOBILE"):
        try:
            tid = await start_outbound(cfg("OWNER_MOBILE"), f"Напоминание для Дена: {text}. Спроси, выполнено ли.", "ru")
            question = " Выполнено?" if src else ""
            task_set(tid, max_attempts=2, opening=f"Ден, это секретарь. Напоминаю: {text}.{question}")
            REMINDER_TASKS[tid] = text
            if src:
                REMINDER_SRC[tid] = src
            return True
        except Exception as e:
            log.warning("reminder call failed: %s", e)
    return False


REMINDER_TASKS: dict[str, str] = {}
REMINDER_SRC: dict[str, tuple] = {}
DONE_TOOL = {"name": "mark_reminder_done", "description": "Den confirms it is done: mark it done so no more reminders come.",
             "input_schema": {"type": "object", "properties": {}}}
SNOOZE_TOOL = {"name": "snooze_reminder", "description": "Den asks to repeat this reminder later.",
               "input_schema": {"type": "object", "properties": {"minutes": {"type": "integer"}}, "required": ["minutes"]}}


def _sent(key: str) -> bool:
    if db.execute("SELECT 1 FROM cal_sent WHERE key=?", (key,)).fetchone():
        return True
    db.execute("INSERT INTO cal_sent(key, at) VALUES(?,?)", (key, time.time()))
    db.commit()
    return False


async def _inbox_for_brief() -> str:
    try:
        return inbox_text(await inbox_summary(force=True))
    except Exception:
        return "нет данных"


async def daily_brief() -> str:
    now = datetime.now(TZ)
    day0 = now.replace(hour=0, minute=0, second=0).timestamp()
    items = agenda(day0, day0 + 86399)
    todos = open_todos()[:8]
    raw = "\n".join(f"{human(e['occ'], bool(e['all_day']))} {e['title']}" + (f" @ {e['location']}" if e['location'] else "")
                    for e in items) or "событий нет"
    msg = await ai_create(model=SMART_MODEL, max_tokens=300, messages=[{"role": "user", "content": (
        "Утренняя сводка для Дена вслух (на «ты», он мужчина), 3–5 коротких предложений по-русски: доброе утро, "
        f"сегодня {WD_RU[now.weekday()]}, план дня по времени, затем важные дела. Без вступлений и разметки.\n"
        f"События сегодня:\n{raw}\nДела:\n" + ("\n".join(t['text'] for t in todos) or "нет")
        + f"\nДоставки на сегодня (упомяни, если есть):\n{deliveries_text(now.strftime('%Y-%m-%d'))}"
        + f"\nВходящие (важные письма назови, остальное — числом):\n{await _inbox_for_brief()}")}])
    return text_of(msg)


async def event_from_call(c: dict, summary: str):
    """If the secretary's call made a booking/appointment, put it into the calendar automatically."""
    try:
        msg = await ai_create(model=SMART_MODEL, max_tokens=400, messages=[{"role": "user", "content": (
            f"Сейчас {now_str()} (Испания). Секретарь позвонил по поручению Дена.\nЗадача: {c.get('task')}\n"
            f"Итог: {c.get('outcome') or '—'}\nСводка: {summary}\n\n"
            'Если в результате ТОЧНО подтверждена бронь/запись/встреча на конкретные дату и время, верни JSON '
            '{"booked": true, "title": "кратко: Ужин в Nobu (2 чел.)", "start": "YYYY-MM-DDTHH:MM", "end": "YYYY-MM-DDTHH:MM или пусто", '
            '"location": "название места"}. Иначе верни {"booked": false}. Только JSON.')}])
        m = re.search(r"\{.*\}", text_of(msg), re.S)
        d = json.loads(m.group(0)) if m else {}
        if not d.get("booked") or not d.get("start"):
            return
        st = to_ts(d["start"])
        if any(abs(e["occ"] - st) < 1800 and e["title"] == d.get("title") for e in agenda(st - 3600, st + 3600)):
            return  # already there
        r = await cal_tool("add_event", {"title": d.get("title") or "Бронь", "start": d["start"], "end": d.get("end") or "",
                                         "location": d.get("location") or "", "remind_minutes": [1440, 60], "source": "call"})
        await tg_send(f"🗓 Добавил в календарь: {d.get('title')}, {human(st)}" +
                      (f", {d['location']}" if d.get("location") else "") + ". Напомню за день и за час.")
        log.info("event from call: %s", r)
    except Exception:
        log.exception("event from call")


def dedupe_reminders():
    """Merges duplicate reminders created earlier (same text, same moment, different channels)."""
    rows = [dict(r) for r in db.execute("SELECT * FROM cal_reminders WHERE status='active' ORDER BY created").fetchall()]
    keep = {}
    for r in rows:
        k = (r["text"].strip().lower(), round(r["at"] / 120))
        if k in keep:
            first = keep[k]
            first["channel"] = _ch((first["channel"] or default_channel()).split(",") + (r["channel"] or default_channel()).split(","))
            db.execute("UPDATE cal_reminders SET channel=? WHERE id=?", (first["channel"], first["id"]))
            db.execute("UPDATE cal_reminders SET status='deleted' WHERE id=?", (r["id"],))
        else:
            keep[k] = r
    db.commit()


APPT = re.compile(r"позвон|звонок|звонк|созвон|встреч|при[её]м|врач|стоматолог|ужин|обед|завтрак|визит|переговор|call|meeting", re.I)


def migrate_reminders():
    """Once: standalone reminders that are really calls/meetings become events with a duration."""
    if cfg("MIGRATED_REMINDERS") == "1":
        return
    for r in db.execute("SELECT * FROM cal_reminders WHERE status='active' AND (rrule IS NULL OR rrule='')").fetchall():
        if not APPT.search(r["text"]):
            continue
        t = r["text"].lower()
        m = dur("CALL") if re.search(r"позвон|звон|call", t) else dur("MEAL") if re.search(r"ужин|обед|завтрак", t) else dur("MEETING")
        db.execute("INSERT INTO cal_events VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",
                   (uuid.uuid4().hex[:8], r["text"], r["at"], r["at"] + m * 60, 0, "", "", "", json.dumps([0]),
                    r["channel"] or "", "migrated", time.time(), "active"))
        db.execute("UPDATE cal_reminders SET status='deleted' WHERE id=?", (r["id"],))
    db.commit()
    cfg_save({"MIGRATED_REMINDERS": "1"})


async def cal_loop():
    try:
        dedupe_reminders()
        migrate_reminders()
    except Exception:
        log.exception("dedupe/migrate")
    while True:
        try:
            now = time.time()
            # event reminders
            for e in agenda(now - 600, now + 8 * 86400, with_phone=False):
                if is_done(f"{e['id']}:{int(e['occ'])}"):
                    continue
                for m in json.loads(e["remind"] or "[]"):
                    fire = e["occ"] - int(m) * 60
                    if now - 600 <= fire <= now and not _sent(f"e:{e['id']}:{int(e['occ'])}:{m}"):
                        when = "сейчас" if m == 0 else (f"через {m} мин" if m < 120 else human(e["occ"], bool(e["all_day"])))
                        await notify(f"{e['title']} — {when}" + (f", {e['location']}" if e["location"] else ""),
                                     e["channel"] or "", ("event", e["id"], e["occ"]))
            # standalone reminders
            for r in db.execute("SELECT * FROM cal_reminders WHERE status='active' AND at<=?", (now,)).fetchall():
                r = dict(r)
                await notify(r["text"], r["channel"] or "", ("reminder", r["id"], r["at"]))
                nxt = [t for t in occurrences(r["at"], r["rrule"], now + 30, now + 400 * 86400, 1)] if r["rrule"] else []
                if nxt:
                    db.execute("UPDATE cal_reminders SET at=? WHERE id=?", (nxt[0], r["id"]))
                else:
                    db.execute("UPDATE cal_reminders SET status='done' WHERE id=?", (r["id"],))
                db.commit()
            # a shopping task Prisma hasn't picked up — say why, once
            for sj in db.execute("SELECT ref FROM shop_jobs WHERE status='sent' AND created<? AND created>?",
                                 (time.time() - 150, time.time() - 3600)).fetchall():
                if not _sent(f"shophint:{sj['ref']}"):
                    job_step("Призма пока не забрала задачу. Проверь в Призме: «Связь» → адрес и токен из Секретаря "
                             "(«Настройка» → «Призма»), и что Призма запущена. Открой Призму — она возьмёт задачу сразу.",
                             "wait", job_by_link(f"shop:{sj['ref']}"))
            # morning briefing
            bt = cfg("BRIEF_TIME")
            if bt:
                d = datetime.now(TZ)
                h, mi = (int(x) for x in bt.split(":"))
                if (d.hour, d.minute) >= (h, mi) and d.hour < h + 3 and not _sent(f"brief:{d.date()}"):
                    await notify(await daily_brief(), cfg("BRIEF_CHANNEL") or default_channel())
                    await push_suggestions("Утро.")
                    await scan_mail(3, force=True)
                    await check_late_deliveries()
            st_ = cfg("SUGGEST_TIME") or "19:30"
            if st_ and st_ != "off":
                d = datetime.now(TZ)
                h, mi = (int(x) for x in st_.split(":"))
                if (d.hour, d.minute) >= (h, mi) and d.hour < h + 2 and not _sent(f"suggest:{d.date()}"):
                    await push_suggestions("Вечер: посмотри на завтра и послезавтра.")
            try:
                await leave_check()
            except Exception:
                log.exception("leave check")
            if time.time() - INBOX.get("checked", 0) > 900:  # every 15 minutes
                INBOX["checked"] = time.time()
                try:
                    await check_important_unread()
                except Exception:
                    log.exception("important mail check")
        except asyncio.CancelledError:
            raise
        except Exception:
            log.exception("calendar loop")
        await asyncio.sleep(30)


# ---------------------------------------------------------------- phase 3: e-mail via SB, suggestions, travel time

db.execute("CREATE TABLE IF NOT EXISTS ingested(id TEXT PRIMARY KEY, at REAL, result TEXT)")
db.execute("""CREATE TABLE IF NOT EXISTS suggestions(
    id TEXT PRIMARY KEY, at REAL, text TEXT, command TEXT, status TEXT)""")
db.execute("CREATE TABLE IF NOT EXISTS geo_cache(q TEXT PRIMARY KEY, lat REAL, lon REAL, label TEXT)")
db.commit()


def sb_key() -> str:
    """Shared secret for Smart Bubbles → Secretary; created on first use."""
    k = cfg("SB_KEY")
    if not k:
        k = secrets.token_hex(16)
        cfg_save({"SB_KEY": k})
    return k


async def check_mail_watch(mail: dict) -> str:
    """If the sender is on Den's watch list — tell him (call / Telegram / app) what arrived."""
    sender = f"{mail.get('from') or ''}".lower()
    hits = [dict(w) for w in db.execute("SELECT * FROM mail_watch WHERE status='active'").fetchall()
            if w["pattern"].strip().lower() and (w["pattern"].strip().lower() in sender or
                                                 all(p in sender for p in w["pattern"].lower().split()))]
    if not hits:
        return ""
    text = re.sub(r"<[^>]+>", " ", str(mail.get("text") or ""))
    try:
        msg = await ai_create(model=SMART_MODEL, max_tokens=200, messages=[{"role": "user", "content": (
            "Одним-двумя короткими предложениями по-русски, для Дена вслух (на «ты»): от кого письмо и о чём, без "
            f"вступлений и без адресов/телефонов.\nОт: {mail.get('from')}\nТема: {mail.get('subject')}\nТекст: {text[:3000]}")}])
        gist = text_of(msg)
    except Exception:
        gist = f"письмо от {mail.get('from')}: {mail.get('subject')}"
    chans = _ch(",".join(w["channels"] for w in hits)) or "call"
    await notify(f"Пришло письмо. {gist}", chans)
    for w in hits:
        db.execute("UPDATE mail_watch SET hits=hits+1, status=? WHERE id=?", ("done" if w["once"] else "active", w["id"]))
    db.commit()
    return ",".join(w["pattern"] for w in hits)


async def email_to_calendar(mail: dict, quiet: bool = False) -> str:
    """Reads one e-mail (booking, ticket, appointment, cancellation) and updates the calendar."""
    text = re.sub(r"<[^>]+>", " ", str(mail.get("text") or ""))
    text = re.sub(r"\s+", " ", text)[:6000]
    msg = await ai_create(model=SMART_MODEL, max_tokens=700, messages=[{"role": "user", "content": (
        f"Сейчас {now_str()} (Испания). Письмо из почты Дена.\nОт: {mail.get('from')}\nТема: {mail.get('subject')}\n"
        f"Дата письма: {mail.get('date')}\nТекст:\n{text}\n\n"
        "Если это ПОДТВЕРЖДЕНИЕ брони/записи/билета/встречи на конкретные даты, верни JSON "
        '{"kind": "event", "type": "hotel|flight|train|restaurant|appointment|event|other", "title": "кратко по-русски", '
        '"start": "YYYY-MM-DDTHH:MM (местное время места события) или YYYY-MM-DD", "end": "то же или пусто", '
        '"all_day": true/false, "location": "место/адрес", "ref": "номер брони или пусто", "notes": "главное: время заезда/выезда, '
        'рейс, места, стоимость"}. Для отеля: all_day=true, start=дата заезда, end=дата выезда. Для рейса: start=вылет, end=прилёт, '
        'location=аэропорт вылета.\nЕсли это ОТМЕНА брони — {"kind": "cancel", "ref": "...", "title": "...", "start": "..."}.\n'
        'Если это письмо ИНТЕРНЕТ-МАГАЗИНА или СЛУЖБЫ ДОСТАВКИ о заказе/посылке (Amazon, AliExpress, Zara, El Corte Inglés, '
        'MediaMarkt, SEUR, Correos, GLS, DHL, UPS, MRW, Nacex, InPost и т.п.) — {"kind": "delivery", "store": "магазин", '
        '"order_ref": "номер заказа или пусто", "items": "что заказано, кратко по-русски", "carrier": "служба доставки или пусто", '
        '"tracking": "трек-номер или пусто", "status": "ordered|shipped|out_for_delivery|delivered|problem|cancelled|returned", '
        '"expected_from": "YYYY-MM-DD или пусто", "expected_to": "YYYY-MM-DD или пусто", "delivered_date": "YYYY-MM-DD или пусто", '
        '"problem": "если неудачная попытка, задержка, нужна оплата пошлины и т.п. — кратко, иначе пусто"}.\n'
        'Иначе {"kind": "none"}. Только JSON.')}])
    m = re.search(r"\{.*\}", text_of(msg), re.S)
    d = json.loads(m.group(0)) if m else {}
    kind = d.get("kind")
    if kind == "delivery":
        return await upsert_delivery(d, quiet)
    if kind == "cancel":
        ref = (d.get("ref") or "").strip()
        for r in db.execute("SELECT * FROM cal_events WHERE status='active' AND source='email'").fetchall():
            if (ref and ref in (r["notes"] or "")) or (d.get("title") and d["title"].lower() in r["title"].lower()):
                db.execute("UPDATE cal_events SET status='deleted' WHERE id=?", (r["id"],))
                db.commit()
                if not quiet:
                    await tg_send(f"🗓 Из почты: отмена — убрал из календаря «{r['title']}».")
                return f"cancelled {r['id']}"
        return "cancel: nothing matched"
    if kind != "event" or not d.get("start"):
        return "not a booking"
    notes = " ".join(x for x in [d.get("notes") or "", f"Бронь: {d['ref']}" if d.get("ref") else ""] if x).strip()
    st = to_ts(d["start"])
    for e in agenda(st - 86400, st + 86400, with_phone=False):  # same booking already in the calendar?
        if (d.get("ref") and d["ref"] in (e.get("notes") or "")) or (abs(e["occ"] - st) < 3600 and
                                                                      e["title"].lower() == (d.get("title") or "").lower()):
            return "duplicate"
    remind = {"flight": [1440, 180], "train": [1440, 90], "hotel": [1440]}.get(d.get("type"), [1440, 60])
    r = await cal_tool("add_event", {"title": d.get("title") or "Бронь", "start": d["start"], "end": d.get("end") or "",
                                     "all_day": bool(d.get("all_day")), "location": d.get("location") or "",
                                     "notes": notes, "remind_minutes": remind, "source": "email"})
    if not quiet:
        await tg_send(f"🗓 Из почты: {d.get('title')}, {human(st, bool(d.get('all_day')))}"
                      + (f", {d['location']}" if d.get("location") else "") + (f". {notes}" if notes else "") + ".")
    return r


async def make_suggestions(reason: str = "") -> list:
    """Looks at the next days and proposes up to 3 useful actions Den can accept with one word."""
    calls = recent_calls_text(6)
    msg = await ai_create(model=SMART_MODEL, max_tokens=800, messages=[{"role": "user", "content": (
        f"Ты секретарь Дена. Сейчас {now_str()} (Испания). {reason}\n\n{agenda_text(4)}\n\nПоследние звонки:\n{calls}\n\n"
        "Предложи до 3 действительно полезных подсказок на ближайшие дни, только если есть повод: ужин/обед в ресторане без "
        "подтверждённой брони (нет «Бронь» в заметках и не записан после звонка) — предложить позвонить и забронировать; "
        "события подряд без времени на дорогу; накладки; срок дела завтра-послезавтра; событие без адреса, куда нужно ехать; "
        "подготовка к важной встрече. Не придумывай поводов. JSON-массив: "
        '[{"text": "коротко для Дена, на «ты»", "command": "команда секретарю, которую выполнить, если Ден согласится, '
        'например «Позвони в ресторан Nobu +34… и подтверди бронь на пятницу 21:00 на двоих» или «Перенеси …»; пусто, если '
        'действие не нужно"}]. Если поводов нет — []. Только JSON.')}])
    m = re.search(r"\[.*\]", text_of(msg), re.S)
    items = json.loads(m.group(0)) if m else []
    out = []
    for it in items[:3]:
        txt = (it.get("text") or "").strip()
        if not txt or _sent("sg:" + txt.lower()[:80]):
            continue  # don't repeat the same tip
        sid = uuid.uuid4().hex[:8]
        db.execute("INSERT INTO suggestions VALUES(?,?,?,?,?)", (sid, time.time(), txt, it.get("command") or "", "new"))
        out.append({"id": sid, "text": txt, "command": it.get("command") or ""})
    db.commit()
    return out


async def push_suggestions(reason: str = ""):
    items = await make_suggestions(reason)
    if not items:
        return
    lines = "\n".join(f"{i + 1}. {x['text']}" for i, x in enumerate(items))
    await tg_send(f"💡 Подсказки:\n{lines}\n\nОтветь, например: «сделай 1» или «сделай все».")
    db.execute("INSERT INTO app_notes(at, text) VALUES(?,?)", (time.time(), "Подсказки: " + "; ".join(x["text"] for x in items)))
    db.commit()


def open_suggestions() -> list:
    return [dict(r) for r in db.execute(
        "SELECT * FROM suggestions WHERE status='new' AND at>? ORDER BY at DESC LIMIT 6", (time.time() - 2 * 86400,)).fetchall()]


async def do_suggestion(sid: str) -> dict:
    r = db.execute("SELECT * FROM suggestions WHERE id=?", (sid,)).fetchone()
    if not r or r["status"] != "new":
        return {"reply": "Эта подсказка уже неактуальна.", "speak": "Эта подсказка уже неактуальна."}
    db.execute("UPDATE suggestions SET status='done' WHERE id=?", (sid,))
    db.commit()
    if not r["command"]:
        return {"reply": "Принял.", "speak": "Принял."}
    return await handle_command(r["command"])


# --- travel time (TomTom, with traffic)

def last_location() -> tuple | None:
    st = load_state()
    loc = st.get("loc")
    if loc and time.time() - loc.get("at", 0) < 3 * 3600:
        return loc["lat"], loc["lon"]
    return None


async def geocode(q: str, near: tuple | None = None) -> tuple | None:
    q = (q or "").strip()
    if not q or not cfg("TOMTOM_KEY"):
        return None
    row = db.execute("SELECT * FROM geo_cache WHERE q=?", (q.lower(),)).fetchone()
    if row:
        return row["lat"], row["lon"]
    params = {"key": cfg("TOMTOM_KEY"), "limit": 1, "language": "es-ES"}
    if near:
        params.update(lat=near[0], lon=near[1])
    async with httpx.AsyncClient(timeout=15) as h:
        r = await h.get(f"https://api.tomtom.com/search/2/search/{urllib.parse.quote(q, safe='')}.json", params=params)
    res = (r.json().get("results") or []) if r.status_code < 300 else []
    if not res:
        return None
    p = res[0]["position"]
    db.execute("INSERT OR REPLACE INTO geo_cache VALUES(?,?,?,?)", (q.lower(), p["lat"], p["lon"],
                                                                    (res[0].get("address") or {}).get("freeformAddress", "")))
    db.commit()
    return p["lat"], p["lon"]


async def travel_minutes(origin: tuple, dest: tuple) -> int | None:
    url = f"https://api.tomtom.com/routing/1/calculateRoute/{origin[0]},{origin[1]}:{dest[0]},{dest[1]}/json"
    async with httpx.AsyncClient(timeout=20) as h:
        r = await h.get(url, params={"key": cfg("TOMTOM_KEY"), "traffic": "true", "travelMode": "car", "departAt": "now"})
    if r.status_code >= 300:
        return None
    s = r.json()["routes"][0]["summary"]
    return round(s["travelTimeInSeconds"] / 60)


TRAVEL_CACHE: dict = {}


# --- rides: Uber in one tap, or a local taxi ordered by phone

async def where_am_i() -> dict:
    """Current address and town: phone position (if fresh) → TomTom reverse geocode; else the home address."""
    loc = last_location()
    if loc and cfg("TOMTOM_KEY"):
        try:
            async with httpx.AsyncClient(timeout=15) as h:
                r = await h.get(f"https://api.tomtom.com/search/2/reverseGeocode/{loc[0]},{loc[1]}.json",
                                params={"key": cfg("TOMTOM_KEY"), "language": "es-ES"})
            a = (r.json().get("addresses") or [{}])[0].get("address", {})
            return {"address": a.get("freeformAddress") or "", "town": a.get("municipality") or a.get("localName") or "",
                    "lat": loc[0], "lon": loc[1]}
        except Exception:
            pass
    home = cfg("HOME_ADDRESS") or "Marbella"
    return {"address": home, "town": home.split(",")[-1].strip() or home, "lat": loc[0] if loc else None,
            "lon": loc[1] if loc else None}


def uber_link(dest_name: str = "", dest: tuple | None = None, dest_addr: str = "") -> str:
    q = {"action": "setPickup", "pickup": "my_location"}
    if dest:
        q.update({"dropoff[latitude]": f"{dest[0]:.6f}", "dropoff[longitude]": f"{dest[1]:.6f}"})
    if dest_name:
        q["dropoff[nickname]"] = dest_name
    if dest_addr:
        q["dropoff[formatted_address]"] = dest_addr
    return "https://m.uber.com/ul/?" + urllib.parse.urlencode(q)


async def find_taxi_phones(town: str) -> list:
    """Taxi services of a town: own address book first, otherwise a web search (results are saved for next time)."""
    t = (town or "").lower()
    known = [dict(r) for r in db.execute("SELECT * FROM places WHERE kind LIKE '%такси%' AND phone!=''").fetchall()
             if t and (t in (r["address"] or "").lower() or t in (r["notes"] or "").lower() or t in r["name"].lower())]
    if known:
        return known
    msg = await ai_create(model=SMART_MODEL, max_tokens=1200, tools=[{"type": "web_search_20250305", "name": "web_search", "max_uses": 4}],
                          messages=[{"role": "user", "content": (
        f"Найди в интернете службы такси города/района «{town}» с телефонами для заказа машины по звонку (радиотакси, "
        "местные службы; не Uber/Cabify). Только реально найденные номера, ничего не придумывай. "
        'Верни JSON-массив [{"name": "название", "phone": "+34…", "website": "", "notes": "часы/район"}], лучшие первыми, до 3. '
        "Только JSON.")}])
    m = re.search(r"\[.*\]", text_of(msg), re.S)
    found = json.loads(m.group(0)) if m else []
    out = []
    for f in found[:3]:
        if not f.get("phone"):
            continue
        f.update(kind="такси", notes=f"{town}. {f.get('notes') or ''}".strip(), address=f.get("address") or town)
        save_place(f)
        f["phone"] = norm(f["phone"])
        out.append(f)
    return out


async def order_ride(plan: dict, text: str) -> dict:
    provider = (plan.get("provider") or "").lower()
    dest_q = (plan.get("dropoff") or "").strip()
    here = await where_am_i()
    pickup = (plan.get("pickup") or "").strip()
    if not pickup or pickup.lower() in ("here", "здесь", "отсюда", "my_location"):
        pickup = here["address"]
    # destination: address book / calendar names first, then geocoding
    dest_addr, dest_name = dest_q, dest_q
    for r in db.execute("SELECT * FROM places WHERE address!=''").fetchall():
        if dest_q and (dest_q.lower() in r["name"].lower() or r["name"].lower() in dest_q.lower()):
            dest_name, dest_addr = r["name"], r["address"]
            break
    dest = await geocode(dest_addr, (here["lat"], here["lon"]) if here.get("lat") else None) if dest_addr else None
    if provider != "taxi":
        link = uber_link(dest_name, dest, dest_addr)
        r = f"Открываю Uber: от тебя{(' до ' + dest_name) if dest_name else ''}. Выбери машину и подтверди."
        return {"reply": f"🚕 {r}\n{link}", "speak": "Принял. Открываю Uber, осталось подтвердить.", "open_url": link}
    town = (plan.get("town") or "").strip() or here["town"]
    taxis = await find_taxi_phones(town)
    if not taxis:
        return {"reply": f"Не нашёл телефон такси в «{town}». Скажи номер — запомню.", "speak": "Не нашёл телефон такси, скажи номер."}
    tx = taxis[0]
    when = plan.get("time") or "сейчас"
    cb = load_rules().get("callback_phone") or cfg("OWNER_MOBILE")
    task = (f"Заказать такси. Откуда: {pickup}. Куда: {dest_addr or 'скажет водителю'}. Когда: {when}. "
            f"Пассажиров: {plan.get('passengers') or 1}. Имя: Den. Телефон для связи с водителем: {cb}. "
            f"{plan.get('notes') or ''} Узнай, через сколько приедет машина, её марку/номер и примерную цену; всё это в итог.")
    try:
        await start_outbound(tx["phone"], task, lang_for(norm(tx["phone"])), tx.get("name") or "")
    except Exception as e:
        return {"reply": f"Не получилось позвонить в такси {tx.get('name')}: {e}", "speak": "Не получилось позвонить в такси."}
    r = f"Звоню в {tx.get('name') or 'такси'} ({tx['phone']}): {pickup} → {dest_addr or 'куда скажешь водителю'}, {when}."
    return {"reply": f"🚖 {r} Итог пришлю.", "speak": f"Принял. Звоню в {tx.get('name') or 'такси'}, заказываю машину на {when}."}


async def leave_check():
    """For today's events with an address: tells Den when to leave, using current traffic."""
    if not cfg("TOMTOM_KEY"):
        return
    now = time.time()
    origin = last_location() or (await geocode(cfg("HOME_ADDRESS")) if cfg("HOME_ADDRESS") else None)
    if not origin:
        return
    buffer = int(cfg("LEAVE_BUFFER") or 10)
    for e in agenda(now, now + 3 * 3600):
        if e["all_day"] or not (e["location"] or "").strip():
            continue
        key = f"{e['id']}:{int(e['occ'])}"
        cached = TRAVEL_CACHE.get(key)
        if not cached or now - cached[1] > 600:
            dest = await geocode(e["location"], origin)
            mins = await travel_minutes(origin, dest) if dest else None
            TRAVEL_CACHE[key] = (mins, now, dest)
            cached = TRAVEL_CACHE[key]
        mins, _, dest = cached
        if not mins or mins < 5:
            continue
        leave_at = e["occ"] - (mins + buffer) * 60
        if leave_at - now <= 15 * 60 and e["occ"] > now and not _sent(f"leave:{key}"):
            left = max(0, round((leave_at - now) / 60))
            when = "выезжай сейчас" if left <= 1 else f"выезжай через {left} мин"
            link = f"https://www.google.com/maps/dir/?api=1&destination={dest[0]},{dest[1]}" if dest else ""
            uber = uber_link(e["title"], dest, e["location"])
            await notify(f"{e['title']} в {datetime.fromtimestamp(e['occ'], TZ).strftime('%H:%M')}: {when}. "
                         f"Дорога сейчас ~{mins} мин с учётом пробок." + (f"\nМаршрут: {link}" if link else "")
                         + f"\n🚕 Uber: {uber}", e.get("channel") or "")


# ---------------------------------------------------------------- messages via Smart Bubbles (WhatsApp, Telegram)

db.execute("""CREATE TABLE IF NOT EXISTS places(
    id TEXT PRIMARY KEY, name TEXT, kind TEXT, phone TEXT, email TEXT, whatsapp TEXT, address TEXT, website TEXT,
    lang TEXT, notes TEXT, created REAL, updated REAL)""")
db.execute("""CREATE TABLE IF NOT EXISTS msg_tasks(
    id TEXT PRIMARY KEY, channel TEXT, account TEXT, peer TEXT, peer_name TEXT, chat_id TEXT, goal TEXT, lang TEXT,
    history TEXT, status TEXT, created REAL, last_at REAL, turns INTEGER)""")
db.commit()
try:
    db.execute("ALTER TABLE msg_tasks ADD COLUMN subject TEXT")
except sqlite3.OperationalError:
    pass


for _c in ("telegram", "aliases"):
    try:
        db.execute(f"ALTER TABLE places ADD COLUMN {_c} TEXT")
    except sqlite3.OperationalError:
        pass
db.commit()


def save_place(d: dict) -> str:
    """Adds/updates an entry in the secretary's own address book (merged by name, phone or e-mail)."""
    name = (d.get("name") or "").strip()
    phone, email = norm(d.get("phone") or "") if d.get("phone") else "", (d.get("email") or "").strip().lower()
    if not name and not phone and not email and not d.get("telegram"):
        return ""
    row = None
    for r in db.execute("SELECT * FROM places").fetchall():
        if (name and r["name"].lower() == name.lower()) or (phone and r["phone"] == phone) or (email and r["email"] == email):
            row = r
            break
    fields = {"name": name, "kind": d.get("kind") or "", "phone": phone, "email": email,
              "whatsapp": norm(d.get("whatsapp") or "") if d.get("whatsapp") else "", "address": d.get("address") or "",
              "website": d.get("website") or "", "lang": d.get("lang") or "", "notes": d.get("notes") or "",
              "telegram": (d.get("telegram") or "").strip(), "aliases": (d.get("aliases") or "").strip()}
    if row:
        upd = {k: v for k, v in fields.items() if v}
        if upd:
            db.execute(f"UPDATE places SET {', '.join(f'{k}=?' for k in upd)}, updated=? WHERE id=?", (*upd.values(), time.time(), row["id"]))
        pid = row["id"]
    else:
        pid = uuid.uuid4().hex[:8]
        db.execute("INSERT INTO places(id, name, kind, phone, email, whatsapp, address, website, lang, notes, created, updated, "
                   "telegram, aliases) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                   (pid, name or email or phone, *[fields[k] for k in ("kind", "phone", "email", "whatsapp", "address",
                                                                      "website", "lang", "notes")], time.time(), time.time(),
                    fields["telegram"], fields["aliases"]))
    db.commit()
    return pid


async def read_screenshot(img: bytes, mime: str = "image/jpeg", note: str = "") -> dict:
    """Recognises contacts on a screenshot (Google Maps, website, card, chat, booking) and files them in the address book."""
    if mime not in ("image/jpeg", "image/png", "image/webp", "image/gif"):
        mime = "image/jpeg"
    prompt = (
        "Ден прислал скриншот, чтобы секретарь записал координаты в записную книжку. Определи, что это за скриншот "
        "(карточка Google Maps, сайт, визитка, переписка, подтверждение брони, меню и т.п.), и извлеки ВСЕ места и людей "
        "с координатами. Телефоны — в международном формате (+34…, если код страны не указан, а место в Испании). "
        "WhatsApp — только если он явно указан. Ничего не выдумывай: чего нет на картинке — пусто.\n"
        + (f"Пояснение Дена: {note}\n" if note else "")
        + 'Верни JSON {"what": "что это за скриншот, кратко по-русски", "places": [{"name": "", "kind": "ресторан/отель/'
          'врач/магазин/человек/…", "phone": "", "whatsapp": "", "email": "", "address": "", "website": "", '
          '"notes": "часы работы и прочее важное, кратко"}]}. Только JSON.')
    msg = await ai_create(model=SMART_MODEL, max_tokens=900, messages=[{"role": "user", "content": [
        {"type": "image", "source": {"type": "base64", "media_type": mime, "data": base64.b64encode(img).decode()}},
        {"type": "text", "text": prompt}]}])
    m = re.search(r"\{.*\}", text_of(msg), re.S)
    d = json.loads(m.group(0)) if m else {"what": "", "places": []}
    saved = []
    for pl in d.get("places") or []:
        if isinstance(pl, dict) and (pl.get("phone") or pl.get("email") or pl.get("address") or pl.get("whatsapp")):
            if save_place(pl):
                saved.append(pl)
    if not saved:
        r = "На скриншоте не нашёл координат" + (f" ({d['what']})" if d.get("what") else "") + ". Пришли другой или подпиши, что записать."
        return {"reply": r, "speak": r, "places": []}
    lines = []
    for pl in saved:
        parts = [f"{lbl} {pl[k]}" for k, lbl in (("phone", "телефон"), ("whatsapp", "WhatsApp"), ("email", "почта"),
                                                 ("address", "адрес"), ("website", "сайт")) if pl.get(k)]
        lines.append(f"{pl.get('name') or 'без названия'}" + (f" ({pl['kind']})" if pl.get("kind") else "") + ": " + ", ".join(parts)
                     + (f". {pl['notes']}" if pl.get("notes") else ""))
    reply = "📒 Записал в записную книжку" + (f" ({d['what']})" if d.get("what") else "") + ":\n" + "\n".join("• " + x for x in lines)
    names = ", ".join(pl.get("name") or "место" for pl in saved)
    return {"reply": reply, "speak": f"Принял. Записал в записную книжку: {names}.", "places": saved}


async def places_from_image(img: bytes, media: str = "image/jpeg", hint: str = "") -> dict:
    """Reads a screenshot/photo (Google Maps card, website, business card, chat, booking) and files the contacts."""
    import base64
    msg = await ai_create(model=SMART_MODEL, max_tokens=1200, messages=[{"role": "user", "content": [
        {"type": "image", "source": {"type": "base64", "media_type": media, "data": base64.b64encode(img).decode()}},
        {"type": "text", "text": (
            "Это скриншот или фото, которое Ден прислал своему секретарю, чтобы сохранить координаты в записную книжку. "
            + (f"Ден добавил: «{hint}». " if hint else "")
            + "Определи, что это (карточка Google Maps, сайт, визитка, переписка, подтверждение брони, вывеска и т.п.), и "
              "извлеки ВСЕ места/организации/людей с координатами. Переписывай телефоны, почту и адреса ТОЧНО как на картинке, "
              "ничего не придумывай; телефон — в международном формате, если код страны очевиден (Испания +34). "
              'Верни JSON {"what": "коротко по-русски, что на картинке", "places": [{"name": "", "kind": "ресторан/отель/врач/'
              'магазин/человек/…", "phone": "", "email": "", "whatsapp": "", "address": "", "website": "", "notes": "часы работы и '
              'другое полезное, кратко"}]}. Если координат нет — places: []. Только JSON.')}]}])
    m = re.search(r"\{.*\}", text_of(msg), re.S)
    d = json.loads(m.group(0)) if m else {"what": "не удалось прочитать", "places": []}
    saved = []
    for pl in d.get("places") or []:
        if save_place(pl):
            saved.append(pl)
    return {"what": d.get("what") or "", "places": saved}


def place_line(p: dict) -> str:
    return (p.get("name") or "") + (f" ({p['kind']})" if p.get("kind") else "") + "".join(
        f", {lbl} {p[k]}" for k, lbl in (("phone", "тел."), ("whatsapp", "WhatsApp"), ("email", "почта"), ("address", "адрес"),
                                           ("website", "сайт")) if p.get(k))


def places_text() -> str:
    rows = db.execute("SELECT * FROM places ORDER BY updated DESC LIMIT 400").fetchall()
    return "\n".join(f"- {r['name']}" + (f" ({r['kind']})" if r["kind"] else "")
                     + (f" [зовёт: {r['aliases']}]" if r["aliases"] else "")
                     + "".join(f", {lbl}: {r[k]}" for k, lbl in (("phone", "тел"), ("whatsapp", "WhatsApp"), ("telegram", "Telegram"),
                                                                  ("email", "почта"), ("address", "адрес")) if r[k])
                     + (f", {r['notes']}" if r["notes"] else "") for r in rows) or "—"


def account_names() -> dict:
    try:
        return json.loads(cfg("ACCOUNT_NAMES") or "{}")
    except Exception:
        return {}


def accounts_text() -> str:
    n = account_names()
    return "; ".join(f"{v} = {k}" for k, v in n.items()) or "по умолчанию испанский +34"


def resolve_account(said: str, channel: str) -> str:
    """«с московского» → the SB account id Den named «московский» for this channel."""
    said = (said or "").strip().lower()
    if not said:
        return ""
    for acc_id, nm in account_names().items():
        ch, _, _ = acc_id.partition(":")
        if ch and ch != channel:
            continue
        if nm and (nm.lower()[:5] in said or said[:5] in nm.lower()):
            return acc_id.partition(":")[2] or acc_id
    return said if re.search(r"\d{6,}|@", said) else ""


def sb_base() -> str:
    return (cfg("SB_URL") or "").rstrip("/")


async def sb_call(method: str, path: str, body: dict | None = None) -> dict:
    if not sb_base():
        raise RuntimeError("не указан адрес сервера SB («Настройка» → «Сообщения через Smart Bubbles»)")
    async with httpx.AsyncClient(timeout=30) as h:
        r = await h.request(method, sb_base() + path, json=body, headers={"X-SB-Key": sb_key()})
    if r.status_code >= 300:
        raise RuntimeError(f"SB ответил {r.status_code}: {r.text[:200]}")
    return r.json() if r.content else {}


async def sb_accounts() -> list:
    try:
        return (await sb_call("GET", "/secretary/accounts")).get("accounts", [])
    except Exception:
        return []


async def compose_message(goal: str, lang: str, history: list, first: bool) -> str:
    sig = cfg("MSG_SIGNATURE")
    msg = await ai_create(model=SMART_MODEL, max_tokens=400, messages=[{"role": "user", "content": (
        f"Напиши {'первое' if first else 'следующее'} сообщение в мессенджере от имени Дена. Сейчас {now_str()}.\n"
        f"Цель (от Дена): {goal}\nЯзык сообщения: {lang}.\n"
        + (f"Переписка до этого:\n" + "\n".join(f"{m['who']}: {m['text']}" for m in history) + "\n" if history else "")
        + "Коротко, вежливо, по делу, как пишут живые люди в WhatsApp/Telegram, без канцелярита и эмодзи. Не добавляй ничего, "
          "чего нет в цели: ни телефонов, ни адресов, ни обещаний. "
        + (f"В конце первого сообщения добавь подпись «— {sig}» на языке сообщения." if first and sig else "Без подписи.")
        + " Верни только текст сообщения.")}])
    return text_of(msg)


async def compose_email(goal: str, lang: str, history: list, first: bool, subject: str = "") -> dict:
    msg = await ai_create(model=SMART_MODEL, max_tokens=700, messages=[{"role": "user", "content": (
        f"Напиши {'письмо' if first else 'ответное письмо'} по электронной почте от имени Дена. Сейчас {now_str()}.\n"
        f"Цель (от Дена): {goal}\nЯзык письма: {lang}.\n"
        + ("Переписка:\n" + "\n".join(f"{m['who']}: {m['text']}" for m in history) + "\n" if history else "")
        + "Вежливо, коротко и по делу, обычным деловым тоном. В конце подпись «Den». Не добавляй ничего, чего нет в цели: "
          "ни телефонов, ни адресов, ни обещаний. "
        + ('Верни JSON {"subject": "тема письма", "body": "текст"}.' if first else
           f'Тема: «Re: {subject}». Верни JSON {{"subject": "Re: {subject}", "body": "текст"}}.') + " Только JSON.")}])
    m = re.search(r"\{.*\}", text_of(msg), re.S)
    d = json.loads(m.group(0)) if m else {"subject": subject or "Reserva", "body": text_of(msg)}
    return {"subject": d.get("subject") or subject or "Reserva", "body": d.get("body") or ""}


PENDING_SENDS: dict = {}


def send_delay() -> int:
    try:
        return max(0, min(60, int(cfg("SEND_DELAY") or 10)))
    except ValueError:
        return 10


async def send_message_task(channel: str, to: str, goal: str, lang: str = "", account: str = "", peer_name: str = "",
                            exact: str = "") -> dict:
    ch = (channel or "").lower()
    if "mail" in ch or "почт" in ch or "@" in (to or "") and "tele" not in ch and "whats" not in ch:
        return await send_email_task(to, goal, lang, account, peer_name)
    channel = "telegram" if "tele" in ch else "whatsapp"
    acc = resolve_account(account, channel)
    explicit = bool(acc)  # Den named the sender account himself
    lang = lang if lang in LANGS else (lang_for(norm(to)) if re.fullmatch(r"\+?\d[\d\s\-()]{6,}", to or "") else "ru")
    text = exact.strip() if (exact or "").strip() else await compose_message(goal, lang, [], True)
    mid = uuid.uuid4().hex[:8]
    acc_name = account_names().get(f"{channel}:{acc}") or account_names().get(acc) or (account if explicit else "")
    app_name = "Telegram" if channel == "telegram" else "WhatsApp"
    db.execute("INSERT INTO msg_tasks(id, channel, account, peer, peer_name, chat_id, goal, lang, history, status, created, "
               "last_at, turns) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",
               (mid, channel, acc, to, peer_name or to, "", goal, lang, json.dumps([{"who": "Ден", "text": text}], ensure_ascii=False),
                "pending", time.time(), time.time(), 1))
    db.commit()
    jid = CUR_JOB.get()
    delay = send_delay()
    job_step(f"Отправлю в {app_name} → {peer_name or to}" + (f", с аккаунта «{acc_name}»" if explicit else "")
             + (f" через {delay} с" if delay else "") + f": «{text}»", "wait", link=f"msg:{mid}")

    async def _go():
        try:
            if delay:
                await asyncio.sleep(delay)
            if (db.execute("SELECT status FROM msg_tasks WHERE id=?", (mid,)).fetchone() or {"status": ""})["status"] != "pending":
                return
            body = {"channel": channel, "to": to, "text": text, "task_id": mid}
            if explicit:
                body.update(account=acc, owner_override=True)
            res = await sb_call("POST", "/secretary/send", body)
            db.execute("UPDATE msg_tasks SET status='waiting', chat_id=?, peer_name=? WHERE id=?",
                       (str(res.get("chat_id") or ""), peer_name or res.get("name") or to, mid))
            db.commit()
            job_step(f"Отправлено в {app_name}. Жду ответа", "wait", jid)
        except asyncio.CancelledError:
            pass
        except Exception as e:
            db.execute("UPDATE msg_tasks SET status='error' WHERE id=?", (mid,))
            db.commit()
            job_step(f"Не получилось отправить: {e}", "error", jid)
        finally:
            PENDING_SENDS.pop(mid, None)

    PENDING_SENDS[mid] = asyncio.create_task(_go())
    return {"id": mid, "text": text, "channel": channel, "delay": delay, "account": acc_name}


async def send_email_task(to: str, goal: str, lang: str = "", account: str = "", peer_name: str = "") -> dict:
    to = (to or "").strip()
    if not re.fullmatch(r"[^@\s]+@[^@\s]+\.[a-z]{2,}", to, re.I):
        raise ValueError(f"это не похоже на адрес почты: {to}")
    tld = to.rsplit(".", 1)[-1].lower()
    lang = lang if lang in LANGS else {"es": "es", "fr": "fr", "it": "it", "de": "de", "pt": "pt", "ru": "ru", "uk": "en"}.get(tld, "es")
    mail = await compose_email(goal, lang, [], True)
    mid = uuid.uuid4().hex[:8]
    body = {"channel": "email", "to": to, "subject": mail["subject"], "text": mail["body"], "task_id": mid}
    if (account or "").strip():
        body.update(account=account.strip(), owner_override=True)
    res = await sb_call("POST", "/secretary/send", body)
    job_step("Письмо отправлено, жду ответа", "wait", link=f"msg:{mid}")
    db.execute("INSERT INTO msg_tasks(id, channel, account, peer, peer_name, chat_id, goal, lang, history, status, created, "
               "last_at, turns, subject) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
               (mid, "email", account.strip(), to, peer_name or to, str(res.get("chat_id") or to.lower()), goal, lang,
                json.dumps([{"who": "Ден", "text": mail["body"]}], ensure_ascii=False), "waiting", time.time(), time.time(), 1,
                mail["subject"]))
    db.commit()
    return {"id": mid, "text": f"Тема: {mail['subject']}\n\n{mail['body']}", "channel": "email"}


async def on_incoming_message(m: dict) -> str:
    """A reply in a chat where the secretary wrote: decide — done, answer within the goal, or ask Den."""
    chat = str(m.get("chat_id") or "")
    row = None
    if m.get("task_id"):
        row = db.execute("SELECT * FROM msg_tasks WHERE id=?", (m["task_id"],)).fetchone()
    if not row and chat:
        row = db.execute("SELECT * FROM msg_tasks WHERE chat_id=? AND status='waiting' ORDER BY last_at DESC", (chat,)).fetchone()
    if not row:
        return "not ours"
    t = dict(row)
    hist = json.loads(t["history"] or "[]")
    hist.append({"who": t["peer_name"] or "собеседник", "text": m.get("text") or ""})
    msg = await ai_create(model=SMART_MODEL, max_tokens=500, messages=[{"role": "user", "content": (
        f"Ты ведёшь переписку от имени Дена ({t['channel']}). Сейчас {now_str()}.\nЦель Дена: {t['goal']}\n"
        "Переписка:\n" + "\n".join(f"{x['who']}: {x['text']}" for x in hist) + "\n\n"
        'Реши, что дальше. JSON: {"status": "done" | "reply" | "ask_den", "reply": "текст ответа собеседнику (только для reply, '
        'на его языке, коротко)", "summary": "для Дена по-русски, на «ты»: что ответили и итог"}. done — цель достигнута или '
        "получен ясный ответ (в т.ч. отказ); reply — нужно уточнить что-то в рамках цели; ask_den — собеседник предлагает "
        "что-то вне цели (другое время, предоплату, вопрос, на который знает только Ден). Не соглашайся ни на что вне цели. "
        "Только JSON.")}])
    mm = re.search(r"\{.*\}", text_of(msg), re.S)
    d = json.loads(mm.group(0)) if mm else {"status": "ask_den", "summary": m.get("text")}
    who = f"{t['peer_name']} ({ {'whatsapp': 'WhatsApp', 'telegram': 'Telegram', 'email': 'почта'}.get(t['channel'], t['channel'])})"
    if d.get("status") == "reply" and t["turns"] < 6 and d.get("reply"):
        follow = {"channel": t["channel"], "to": t["peer"], "chat_id": t["chat_id"], "text": d["reply"], "task_id": t["id"]}
        if t["channel"] == "email":
            em = await compose_email(t["goal"], t["lang"], hist + [{"who": "секретарь хочет ответить", "text": d["reply"]}],
                                     False, (t.get("subject") or "").removeprefix("Re: "))
            follow.update(subject=em["subject"], text=em["body"])
        if t["account"]:
            follow.update(account=t["account"], owner_override=True)
        await sb_call("POST", "/secretary/send", follow)
        hist.append({"who": "Ден", "text": d["reply"]})
        db.execute("UPDATE msg_tasks SET history=?, last_at=?, turns=turns+1 WHERE id=?",
                   (json.dumps(hist, ensure_ascii=False), time.time(), t["id"]))
        db.commit()
        return "replied"
    status = "done" if d.get("status") == "done" else "ask_den"
    db.execute("UPDATE msg_tasks SET history=?, last_at=?, status=? WHERE id=?",
               (json.dumps(hist, ensure_ascii=False), time.time(), status, t["id"]))
    db.commit()
    icon = "✅" if status == "done" else "❓"
    job_step(("Итог: " if status == "done" else "Нужен твой ответ: ") + (d.get("summary") or m.get("text") or ""),
             "done" if status == "done" else "wait", job_by_link(f"msg:{t['id']}"))
    await tg_send(f"{icon} {who}: {d.get('summary') or m.get('text')}")
    if status == "done":
        asyncio.create_task(event_from_call({"task": t["goal"], "outcome": d.get("summary"), "direction": "out"},
                                            d.get("summary") or ""))
    return status


# ---------------------------------------------------------------- deliveries (Amazon & other shops)

db.execute("""CREATE TABLE IF NOT EXISTS deliveries(
    id TEXT PRIMARY KEY, store TEXT, order_ref TEXT, items TEXT, carrier TEXT, tracking TEXT, status TEXT,
    exp_from REAL, exp_to REAL, delivered_at REAL, problem TEXT, updated REAL, history TEXT)""")
db.commit()

DELIV_STATUS = {"ordered": "заказан", "shipped": "отправлен", "out_for_delivery": "сегодня у курьера",
                "delivered": "доставлен", "problem": "проблема", "cancelled": "отменён", "returned": "возврат"}


def _date_ts(v: str, end: bool = False):
    v = (v or "").strip()[:10]
    if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", v):
        return None
    return to_ts(v + ("T23:59" if end else "T00:00"))


def active_deliveries() -> list:
    return [dict(r) for r in db.execute(
        "SELECT * FROM deliveries WHERE status NOT IN ('delivered','cancelled','returned') "
        "OR (status='delivered' AND delivered_at>?) ORDER BY COALESCE(exp_from, 9e12)", (time.time() - 2 * 86400,)).fetchall()]


def delivery_line(d: dict) -> str:
    when = ""
    if d["status"] == "delivered" and d["delivered_at"]:
        when = human(d["delivered_at"], True)
    elif d["exp_from"]:
        a, b = d["exp_from"], d["exp_to"] or d["exp_from"]
        when = (f"ожидается {human(a, True)}" if abs(b - a) < 86400 else f"ожидается {human(a, True)} – {human(b, True)}")
    late = d["status"] not in ("delivered", "cancelled", "returned") and d["exp_to"] and d["exp_to"] < time.time()
    return (f"{d['store']}: {d['items'] or 'заказ'} — {DELIV_STATUS.get(d['status'], d['status'])}"
            + (f", {when}" if when else "") + (f", {d['carrier']}" if d["carrier"] else "")
            + (" ⚠️ ОПАЗДЫВАЕТ" if late else "") + (f" ({d['problem']})" if d["problem"] else ""))


def deliveries_text(day: str = "") -> str:
    items = active_deliveries()
    if day:
        a, b = to_ts(day + "T00:00"), to_ts(day + "T23:59")
        items = [d for d in items if (d["exp_from"] or 0) <= b and (d["exp_to"] or d["exp_from"] or 0) >= a
                 or (d["delivered_at"] and a <= d["delivered_at"] <= b)]
    return "\n".join("- " + delivery_line(d) for d in items) or "Доставок не ожидается."


async def upsert_delivery(d: dict, quiet: bool = False) -> str:
    """Creates/updates one order from a shop or carrier e-mail and tells Den about important changes."""
    store = (d.get("store") or "").strip() or "Магазин"
    ref, trk = (d.get("order_ref") or "").strip(), (d.get("tracking") or "").strip()
    row = None
    if ref:
        row = db.execute("SELECT * FROM deliveries WHERE order_ref=?", (ref,)).fetchone()
    if not row and trk:
        row = db.execute("SELECT * FROM deliveries WHERE tracking=?", (trk,)).fetchone()
    if not row and d.get("items"):
        for r in db.execute("SELECT * FROM deliveries WHERE store=? AND status NOT IN ('delivered','cancelled')", (store,)).fetchall():
            if r["items"] and (r["items"].lower()[:25] in d["items"].lower() or d["items"].lower()[:25] in r["items"].lower()):
                row = r
                break
    status = d.get("status") if d.get("status") in DELIV_STATUS else "ordered"
    exp_from, exp_to = _date_ts(d.get("expected_from")), _date_ts(d.get("expected_to") or d.get("expected_from"), True)
    delivered_at = _date_ts(d.get("delivered_date")) or (time.time() if status == "delivered" else None)
    note = f"{datetime.now(TZ).strftime('%d.%m %H:%M')} {DELIV_STATUS[status]}" + (f": {d['problem']}" if d.get("problem") else "")
    CARRIERS = ("seur", "correos", "gls", "dhl", "ups", "mrw", "nacex", "inpost", "ctt", "fedex", "tipsa", "envialia", "amazon logistics")
    if row:
        old = dict(row)
        if store.lower() in CARRIERS or (old["store"] and old["store"] != store and store.lower() == (d.get("carrier") or "").lower()):
            d["carrier"] = d.get("carrier") or store
            store = old["store"]  # a carrier's e-mail keeps the shop's name
        hist = json.loads(old["history"] or "[]") + [note]
        db.execute("""UPDATE deliveries SET store=?, order_ref=?, items=?, carrier=?, tracking=?, status=?, exp_from=?, exp_to=?,
                      delivered_at=?, problem=?, updated=?, history=? WHERE id=?""",
                   (store, ref or old["order_ref"], d.get("items") or old["items"], d.get("carrier") or old["carrier"],
                    trk or old["tracking"], status, exp_from or old["exp_from"], exp_to or old["exp_to"],
                    delivered_at if status == "delivered" else old["delivered_at"], d.get("problem") or "",
                    time.time(), json.dumps(hist, ensure_ascii=False), old["id"]))
        did, changed = old["id"], old["status"] != status
    else:
        did, changed = uuid.uuid4().hex[:8], True
        db.execute("INSERT INTO deliveries VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",
                   (did, store, ref, d.get("items") or "", d.get("carrier") or "", trk, status, exp_from, exp_to,
                    delivered_at if status == "delivered" else None, d.get("problem") or "", time.time(),
                    json.dumps([note], ensure_ascii=False)))
    db.commit()
    cur = dict(db.execute("SELECT * FROM deliveries WHERE id=?", (did,)).fetchone())
    if changed and not quiet and status in ("out_for_delivery", "delivered", "problem", "cancelled"):
        icon = {"out_for_delivery": "🚚", "delivered": "📦", "problem": "⚠️", "cancelled": "✖️"}[status]
        await notify(f"{icon} {delivery_line(cur)}", "telegram" if status != "problem" else "")
    return f"delivery {did}: {status}"


MAIL_SCAN = {"at": 0.0}


async def scan_mail(days: int = 30, force: bool = False) -> str:
    """Asks SB for recent shop / delivery / booking e-mails (SB filters them) and files them quietly."""
    if not sb_base():
        return "почта не подключена: в «Настройка» не указан адрес SB"
    if not force and time.time() - MAIL_SCAN["at"] < 1800:
        return "already scanned recently"
    try:
        res = await sb_call("POST", "/secretary/mail/search", {"days": days, "limit": 300})
    except Exception as e:
        return f"SB не дал просмотреть почту: {e}"
    MAIL_SCAN["at"] = time.time()
    new = 0
    for m in res.get("mails", []):
        mid = str(m.get("id") or hash((m.get("subject"), m.get("date"))))
        if db.execute("SELECT 1 FROM ingested WHERE id=?", (mid,)).fetchone():
            continue
        try:
            r = await email_to_calendar(m, quiet=True)
        except Exception as e:
            r = f"error: {e}"
        db.execute("INSERT OR REPLACE INTO ingested VALUES(?,?,?)", (mid, time.time(), r))
        new += 1
    db.commit()
    return f"просмотрено новых писем: {new}"


# --- unread messages & important mail (summary from SB; no message texts, no other mail)

INBOX = {"at": 0.0, "data": None}
IMPORTANT_SEEN: dict = {}


async def inbox_summary(force: bool = False) -> dict:
    if not sb_base():
        raise RuntimeError("не подключён SB («Настройка» → адрес сервера SB)")
    if not force and INBOX["data"] and time.time() - INBOX["at"] < 120:
        return INBOX["data"]
    d = await sb_call("POST", "/secretary/inbox/summary", {"names": cfg("INBOX_NAMES") != "off"})
    need = [m for m in d.get("important") or [] if not m.get("gist") and m.get("text")]
    if need:  # short gist for each important e-mail, the text itself is not kept
        try:
            msg = await ai_create(model=SMART_MODEL, max_tokens=500, messages=[{"role": "user", "content": (
                "Для каждого письма — суть одной короткой фразой по-русски, без адресов и телефонов. JSON-массив строк в том же "
                "порядке. Только JSON.\n\n" + "\n\n".join(f"{i + 1}. От: {m.get('from')}. Тема: {m.get('subject')}. "
                                                         f"Текст: {str(m.get('text'))[:1500]}" for i, m in enumerate(need)))}])
            mm = re.search(r"\[.*\]", text_of(msg), re.S)
            for m, g in zip(need, json.loads(mm.group(0)) if mm else []):
                m["gist"] = g
        except Exception:
            pass
    for m in d.get("important") or []:
        m.pop("text", None)
    INBOX.update(at=time.time(), data=d)
    return d


def inbox_text(d: dict) -> str:
    names = cfg("INBOX_NAMES") != "off"
    lines = []
    for ch, label in (("telegram", "Telegram"), ("whatsapp", "WhatsApp"), ("signal", "Signal"), ("sms", "SMS"), ("email", "Почта")):
        c = (d.get("counts") or {}).get(ch)
        if c is None:
            continue
        n, chats = (c.get("unread", 0), c.get("chats")) if isinstance(c, dict) else (int(c), None)
        line = f"{label}: {n}" + (f" (в {chats} чатах)" if chats else "")
        who = (c.get("senders") if isinstance(c, dict) else None) or []
        if names and who:
            line += " — " + ", ".join(f"{w.get('name')}" + (f" {w.get('count')}" if w.get("count", 1) > 1 else "") for w in who[:6])
        lines.append(line)
    imp = d.get("important") or []
    if imp:
        lines.append("Важные письма:")
        lines += [f"• {m.get('from')}: {m.get('subject')}" + (f" — {m.get('gist')}" if m.get("gist") else "") for m in imp[:8]]
    else:
        lines.append("Важных писем нет.")
    return "\n".join(lines)


async def inbox_answer(question: str) -> dict:
    try:
        d = await inbox_summary(force=True)
    except Exception as e:
        r = f"Не получилось проверить сообщения: {e}"
        return {"reply": r, "speak": "Не получилось проверить сообщения."}
    raw = inbox_text(d)
    msg = await ai_create(model=SMART_MODEL, max_tokens=300, messages=[{"role": "user", "content": (
        f"Ден спрашивает: «{question}». Сводка его входящих:\n{raw}\n\nОтветь для озвучки по-русски, на «ты», 1–4 коротких "
        "предложения: сначала важные письма (от кого и о чём), потом сколько непрочитанных где. Без списков и разметки.")}])
    return {"reply": "📬 " + raw, "speak": text_of(msg)}


async def check_important_unread():
    """Important e-mail still unread after N minutes → tell Den (call/Telegram as set)."""
    if cfg("INBOX_ALERT") == "off" or not sb_base():
        return
    try:
        d = await inbox_summary()
    except Exception:
        return
    now, wait = time.time(), int(cfg("INBOX_ALERT_MIN") or 60) * 60
    for m in d.get("important") or []:
        mid = str(m.get("id") or m.get("subject"))
        first = IMPORTANT_SEEN.setdefault(mid, now)
        if m.get("unread", True) and now - first >= wait and not _sent(f"imp:{mid}"):
            await notify(f"Важное письмо не прочитано: {m.get('from')} — {m.get('subject')}"
                         + (f". {m.get('gist')}" if m.get("gist") else ""), cfg("INBOX_ALERT_CH") or "")


async def deliveries_answer(question: str) -> str:
    msg = await ai_create(model=SMART_MODEL, max_tokens=350, messages=[{"role": "user", "content": (
        f"Сейчас {now_str()} (Испания). Ден спрашивает о доставках: «{question}».\n"
        f"Только что просмотрел его почту за последние 30 дней через SB: {MAIL_SCAN.get('last', '')}.\nТекущие заказы:\n{deliveries_text()}\n\n"
        "Никогда не говори, что у тебя нет доступа к почте, если просмотр прошёл; если просмотр не удался — скажи, почему (SB).\n"
        "Ответь коротко по-русски, на «ты», 1–4 предложения для озвучки: что, откуда, когда привезут; отметь опаздывающие и "
        "проблемные. Если по вопросу ничего нет — так и скажи.")}])
    return text_of(msg)


async def check_late_deliveries():
    """Once a day: orders whose delivery window has passed without a «delivered» e-mail."""
    now = time.time()
    for d in active_deliveries():
        if d["status"] in ("delivered", "cancelled", "returned") or not d["exp_to"] or d["exp_to"] > now:
            continue
        if not _sent(f"late:{d['id']}:{datetime.now(TZ).date()}"):
            await notify(f"⚠️ Не пришло вовремя: {delivery_line(d)}. Проверь заказ или скажи мне связаться с магазином.", "telegram")


# ---------------------------------------------------------------- Den Bus (Prisma ⇄ Secretary, same protocol as den_bus.py)

db.execute("""CREATE TABLE IF NOT EXISTS bus_msgs(
    id INTEGER PRIMARY KEY AUTOINCREMENT, frm TEXT, too TEXT, type TEXT, payload TEXT, ts REAL)""")
db.execute("CREATE TABLE IF NOT EXISTS bus_kv(key TEXT PRIMARY KEY, value TEXT, ts REAL)")
db.execute("""CREATE TABLE IF NOT EXISTS shop_jobs(
    ref INTEGER PRIMARY KEY, task TEXT, store TEXT, status TEXT, question TEXT, result TEXT, created REAL, updated REAL)""")
try:
    db.execute("ALTER TABLE tasks ADD COLUMN bus_ref INTEGER")
except sqlite3.OperationalError:
    pass
db.commit()


def bus_token() -> str:
    t = cfg("BUS_TOKEN")
    if not t:
        t = secrets.token_hex(16)
        cfg_save({"BUS_TOKEN": t})
    return t


def bus_put(frm: str, to: str, typ: str, payload: dict) -> int:
    cur = db.execute("INSERT INTO bus_msgs(frm, too, type, payload, ts) VALUES(?,?,?,?,?)",
                     (frm, to, typ, json.dumps(payload, ensure_ascii=False), time.time()))
    db.commit()
    return cur.lastrowid


async def shop_order(task: str, store: str = "") -> dict:
    ref = bus_put("caller", "prisma", "shop", {"task": task, "store": store, "voice": False})
    job_step("Передал Призме — жду, когда она заберёт задачу (Призма проверяет раз в минуту, пока запущена)", "wait",
             link=f"shop:{ref}")
    db.execute("INSERT INTO shop_jobs VALUES(?,?,?,?,?,?,?,?)", (ref, task, store, "sent", "", "", time.time(), time.time()))
    db.commit()
    return {"ref": ref}


def open_shop_question():
    r = db.execute("SELECT * FROM shop_jobs WHERE status='ask' ORDER BY updated DESC").fetchone()
    return dict(r) if r else None


async def bus_to_caller(m: dict):
    """Messages for the secretary: Prisma's shopping progress and call tasks."""
    P, typ = m.get("payload") or {}, m.get("type")
    jid = job_by_link(f"shop:{P.get('ref')}")
    if typ == "shop.ask":
        job_step("Призма спрашивает: " + str(P.get("question")), "wait", jid)
        db.execute("UPDATE shop_jobs SET status='ask', question=?, updated=? WHERE ref=?", (P.get("question", ""), time.time(), P.get("ref")))
        db.commit()
        await notify(f"🛒 Призма спрашивает: {P.get('question')}\nОтветь секретарю, например: «ответь Призме: …».", "telegram")
    elif typ == "shop.confirm":
        sm = P.get("summary") or {}
        job_step(f"Заказ собран: {sm.get('items', '')} — {sm.get('total', '')}. Жду отпечаток в Призме", "wait", jid)
        db.execute("UPDATE shop_jobs SET status='confirm', updated=? WHERE ref=?", (time.time(), P.get("ref")))
        db.commit()
        await notify(f"🛒 Готов заказ: {sm.get('items', '')} — {sm.get('total', '')}"
                     + (f", доставка {sm.get('delivery')}" if sm.get("delivery") else "")
                     + ". Подтверди отпечатком в Призме — без этого заказ не оформится.", "")
    elif typ == "shop.result":
        res, err, od = P.get("result") or "", P.get("error") or "", P.get("order") or {}
        job_step(("Не получилось: " + err) if err else ("Готово: " + res), "error" if err else "done", jid)
        db.execute("UPDATE shop_jobs SET status=?, result=?, updated=? WHERE ref=?",
                   ("error" if err else "done", err or res, time.time(), P.get("ref")))
        db.commit()
        await notify(("🛒 Не получилось: " + err) if err else ("🛒 " + res), "telegram")
        if od.get("placed"):
            try:
                await upsert_delivery({"store": od.get("shop") or "Магазин", "order_ref": od.get("number") or "",
                                       "items": od.get("title") or "", "status": "ordered", "problem": ""}, quiet=True)
            except Exception:
                log.exception("order → deliveries")
    elif typ == "call.task":
        phone = P.get("phone") or ""
        goal = (P.get("goal") or "") + (f"\nДетали: {P['details']}" if P.get("details") else "") + (
            f"\nСценарий:\n{P['script']}" if P.get("script") else "")
        lang = P.get("language") if P.get("language") in LANGS else lang_for(norm(phone))
        try:
            tid = await start_outbound(phone, goal, lang, P.get("name") or "")
            task_set(tid, bus_ref=m["id"])
            bus_put("caller", m.get("frm") or "prisma", "call.status", {"task_id": m["id"], "status": "звоню"})
        except Exception as e:
            bus_put("caller", m.get("frm") or "prisma", "call.result", {"task_id": m["id"], "status": "ошибка", "summary": str(e)})


def bus_call_result(c: dict, summary: str):
    t = task_get(c.get("task_id")) if c.get("task_id") else None
    if t and t.get("bus_ref"):
        bus_put("caller", "prisma", "call.result", {"task_id": t["bus_ref"], "status": c.get("outcome") or "готово",
                                                    "summary": summary, "name": t.get("contact") or "", "phone": c.get("peer")})


# ---------------------------------------------------------------- notes archive (with secret notes encrypted)

db.execute("""CREATE TABLE IF NOT EXISTS archive(
    id TEXT PRIMARY KEY, title TEXT, body TEXT, tags TEXT, pinned INTEGER, secret INTEGER, created REAL, updated REAL,
    source TEXT, status TEXT)""")
db.commit()

SECRET_RX = [
    re.compile(r"\b\d{8,10}:[A-Za-z0-9_-]{30,}\b"),                 # Telegram bot token
    re.compile(r"\b(sk|pk|rk|xox[abp]|ghp|gho|AIza|AKIA)[-_A-Za-z0-9]{16,}"),  # common API key prefixes
    re.compile(r"\b[A-Fa-f0-9]{32,}\b"),                              # long hex
    re.compile(r"\b[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}(:fx)?\b", re.I),  # uuid-style keys (DeepL)
    re.compile(r"(парол|password|passwd|pin|пин-?код|токен|token|api[ _-]?key|ключ api|secret|секрет)", re.I),
]


def looks_secret(text: str) -> bool:
    t = text or ""
    if any(rx.search(t) for rx in SECRET_RX[:4]):
        return True
    # a keyword plus a random-looking word (letters+digits, 12+ chars, or 14+ lowercase letters like app passwords)
    return bool(SECRET_RX[4].search(t) and re.search(r"\b(?=\w*\d)(?=\w*[A-Za-z])\w{12,}\b|\b[a-z]{14,}\b", t))


def _fernet():
    from cryptography.fernet import Fernet
    k = cfg("NOTES_KEY")
    if not k:
        k = Fernet.generate_key().decode()
        cfg_save({"NOTES_KEY": k})
    return Fernet(k.encode())


def enc(text: str) -> str:
    return "enc:" + _fernet().encrypt(text.encode()).decode()


def dec(text: str) -> str:
    if (text or "").startswith("enc:"):
        try:
            return _fernet().decrypt(text[4:].encode()).decode()
        except Exception:
            return "(не удалось расшифровать)"
    return text or ""


def mask(text: str) -> str:
    """Keeps the words, hides anything that looks like a key or password."""
    def m(s):
        w = s.group(0)
        return w[:4] + "••••" if len(w) > 6 else "••••"
    out = re.sub(r"\b(?=[\w:-]*\d)(?=[\w:-]*[A-Za-z])[\w:-]{10,}\b|\b[a-z]{14,}\b", m, text or "")
    return out


async def note_meta(text: str) -> dict:
    """Title + tags for an ordinary note (secret notes are never sent to the AI)."""
    try:
        msg = await ai_create(model=SMART_MODEL, max_tokens=200, messages=[{"role": "user", "content": (
            "Заметка Дена. Придумай короткий заголовок (до 6 слов) и 1–4 метки (одно слово, без #, по-русски или имя собств.). "
            f'JSON {{"title": "", "tags": []}}. Только JSON.\n\n{text[:3000]}')}])
        m = re.search(r"\{.*\}", text_of(msg), re.S)
        d = json.loads(m.group(0)) if m else {}
        return {"title": (d.get("title") or "").strip()[:80], "tags": [str(t).strip("# ")[:24] for t in (d.get("tags") or [])][:4]}
    except Exception:
        return {"title": "", "tags": []}


async def note_add(text: str, title: str = "", tags: list | None = None, source: str = "app", secret: bool | None = None,
                   created: float | None = None) -> dict:
    text = (text or "").strip()
    if re.search(r"<(p|div|br|span|body|html)[\s>/]", text, re.I):  # shared as HTML
        text = re.sub(r"<br\s*/?>|</p>|</div>", "\n", text, flags=re.I)
        text = re.sub(r"<[^>]+>", "", text)
        text = re.sub(r"&nbsp;", " ", text)
        text = re.sub(r"\n{3,}", "\n\n", text).strip()
    if not text:
        raise ValueError("пустая заметка")
    sec = looks_secret(title + "\n" + text) if secret is None else bool(secret)
    if not title and not tags and not sec:
        meta = await note_meta(text)
        title, tags = meta["title"], meta["tags"]
    if not title:
        title = text.splitlines()[0][:60]
    nid = uuid.uuid4().hex[:10]
    db.execute("INSERT INTO archive VALUES(?,?,?,?,?,?,?,?,?,?)",
               (nid, title, enc(text) if sec else text, json.dumps(tags or [], ensure_ascii=False), 0, 1 if sec else 0,
                created or time.time(), time.time(), source, "active"))
    db.commit()
    return {"id": nid, "title": title, "secret": sec, "tags": tags or []}


def note_row(r, reveal: bool = False) -> dict:
    d = dict(r)
    body = dec(d["body"]) if d["secret"] else d["body"]
    d["body"] = body if (reveal or not d["secret"]) else mask(body)
    d["tags"] = json.loads(d["tags"] or "[]")
    return d


def notes_plain(limit: int = 400) -> list:
    """Ordinary (non-secret) notes, for the secretary's own use."""
    return [note_row(r) for r in db.execute(
        "SELECT * FROM archive WHERE status='active' AND secret=0 ORDER BY updated DESC LIMIT ?", (limit,)).fetchall()]


def notes_for(words: str, limit: int = 3) -> str:
    """Quick keyword pick of notes relevant to a call or task (no AI)."""
    ws = [w for w in re.findall(r"\w{4,}", (words or "").lower())][:12]
    if not ws:
        return ""
    scored = []
    for n in notes_plain():
        hay = (n["title"] + " " + n["body"] + " " + " ".join(n["tags"])).lower()
        sc = sum(1 for w in ws if w[:6] in hay)
        if sc:
            scored.append((sc, n))
    scored.sort(key=lambda x: -x[0])
    return "\n".join(f"- {n['title']}: {n['body'][:300]}" for _, n in scored[:limit])


async def notes_search(q: str) -> dict:
    """Search by meaning over ordinary notes; secret notes are matched by title only."""
    plain = notes_plain(300)
    secrets_ = [note_row(r) for r in db.execute("SELECT * FROM archive WHERE status='active' AND secret=1").fetchall()]
    sec_hits = [s for s in secrets_ if any(w in s["title"].lower() for w in re.findall(r"\w{3,}", q.lower()))]
    if not plain:
        return {"ids": [s["id"] for s in sec_hits], "answer": "Обычных заметок пока нет.", "secret": sec_hits}
    lst = "\n".join(f"[{n['id']}] {datetime.fromtimestamp(n['created'], TZ).strftime('%d.%m.%Y')} {n['title']}: "
                    f"{n['body'][:400]} #{' #'.join(n['tags'])}" for n in plain)
    msg = await ai_create(model=SMART_MODEL, max_tokens=600, messages=[{"role": "user", "content": (
        f"Заметки Дена:\n{lst}\n\nВопрос Дена: «{q}». Найди подходящие заметки по смыслу. "
        'JSON {"ids": ["id", ...], "answer": "ответ Дену по-русски на «ты», 1–4 предложения по содержанию найденных заметок; '
        'если ничего нет — так и скажи"}. Только JSON.')}])
    m = re.search(r"\{.*\}", text_of(msg), re.S)
    d = json.loads(m.group(0)) if m else {"ids": [], "answer": "Не нашёл."}
    if sec_hits:
        d["answer"] = (d.get("answer") or "") + " Есть и закрытые заметки: " + ", ".join(f"«{s['title']}»" for s in sec_hits) + \
                      " — открой их в приложении, вслух я их не читаю."
    d["ids"] = [i for i in d.get("ids") or [] if any(n["id"] == i for n in plain)] + [s["id"] for s in sec_hits]
    return d


async def image_to_note(img: bytes, media: str = "image/jpeg", hint: str = "") -> dict:
    import base64
    msg = await ai_create(model=SMART_MODEL, max_tokens=1500, messages=[{"role": "user", "content": [
        {"type": "image", "source": {"type": "base64", "media_type": media, "data": base64.b64encode(img).decode()}},
        {"type": "text", "text": ("Перепиши текст с картинки в заметку ТОЧНО, ничего не придумывая; сохрани строки. "
                                  + (f"Ден добавил: «{hint}». " if hint else "") + "Верни только текст заметки.")}]}])
    text = text_of(msg).strip()
    return await note_add(text, source="image")


# ---------------------------------------------------------------- telegram

PENDING_CALLS: dict[str, dict] = {}
LAST_REQ = {"text": ""}
TG_HELP = (
    "Напиши или скажи голосовым, куда позвонить и что сделать, например:\n"
    "«Позвони в ресторан +34 952 12 34 56, столик на двоих на пятницу в 21:00, можно с 20:30 до 21:30»\n\n"
    "«Позвони маме» — номер возьму из записной книжки, если она загружена в приложении.\n"
    "«Кто мне звонил?» — расскажу о последних звонках.\n"
    "Пришли скриншот (карточка ресторана, сайт, визитка) — запишу координаты в записную книжку.\n\n"
    "/note текст — заметка на сегодня для секретаря (пустая — очистить)\n"
    "/calls — последние звонки\n/again — повторить последнее поручение\n/tasks — статус поручений и попыток дозвона\n/stop — отменить повторные звонки\n"
    "/cancel — сбросить незаконченное поручение\n"
    "/confirm on — спрашивать подтверждение перед звонком, /confirm off — звонить сразу (сейчас по умолчанию)"
)


async def tg_api(method: str, **params):
    token = cfg("TELEGRAM_BOT_TOKEN")
    if not token:
        return None
    try:
        async with httpx.AsyncClient(timeout=70) as h:
            r = await h.post(f"https://api.telegram.org/bot{token}/{method}", json=params)
            return r.json()
    except Exception:
        log.warning("telegram %s failed", method)
        return None


async def tg_send(text: str, **kw):
    chat = load_state().get("tg_chat")
    if chat:
        await tg_api("sendMessage", chat_id=chat, text=text[:4000], **kw)


CONTACTS_F = DATA / "contacts.json"


def load_contacts() -> list:
    try:
        return json.loads(CONTACTS_F.read_text(encoding="utf-8"))
    except Exception:
        return []


def _key(w: str) -> str:
    return w[:3] if len(w) <= 4 else w[:4]


def match_contacts(text: str, limit: int = 25) -> list:
    words = {_key(w) for w in re.findall(r"[\wё]+", text.lower()) if len(w) >= 3}
    out = []
    for c in load_contacts():
        name_keys = {_key(w) for w in re.findall(r"[\wё]+", c["name"].lower()) if len(w) >= 3}
        if words & name_keys:
            out.append(c)
            if len(out) >= limit:
                break
    return out


async def parse_command(text: str) -> dict:
    book = load_contacts()
    found = book if len(book) <= 2000 else match_contacts(text, 200)
    contacts = "\n".join(f"{c['name']}: {', '.join(c['phones'])}" for c in found) or "—"
    prompt = (
        "Ден даёт команду своему ИИ-секретарю (текстом или голосом, в расшифровке возможны ошибки). Разбери её.\n"
        f"Команда:\n{text}\n\n"
        "Собственная записная книжка секретаря (места и люди, которые Ден сообщал раньше; используй их телефоны/почту/WhatsApp, "
        f"если Ден называет место по имени, в т.ч. с ошибками распознавания: «Гая» = Gaia):\n{places_text()}\n\n"
        "Записная книжка Дена (ищи нужный контакт с учётом падежей, уменьшительных имён (Коля = Николай), "
        "латиницы и кириллицы (Нобу = Nobu), ошибок распознавания речи; если подходят несколько — спроси, кого именно):\n"
        f"{contacts}\n\n"
        'Верни ТОЛЬКО JSON: {"action": "call" | "message" | "ride" | "inbox" | "shop" | "shop_answer" | "note_save" | "note_find" | "cancel_job" | "deliveries" | "watch_mail" | "unwatch_mail" | "calendar" | "suggestion" | "note" | "recent" | "status" | "cancel" | "question" | "other", "numbers": [номера подсказок для suggestion], '
        '"to": "номер для звонка в формате +34… (из команды или из контактов) или пустая строка", '
        '"contact": "имя контакта, если номер взят из записной книжки, иначе пустая строка", '
        '"note_text": "", "remind": "", "query": "", "text_exact": "", "store": "", "answer": "", "provider": "uber|taxi", "pickup": "", "dropoff": "", "time": "", "passengers": 1, "town": "", '
        '"sender": "для watch_mail/unwatch_mail", "channels": ["call", "telegram"], "once": true, '
        '"remember": {"name": "название места/имя", "kind": "ресторан/отель/врач/человек/…", "phone": "", "email": "", '
        '"whatsapp": "", "telegram": "@ник или номер", "aliases": "как Ден его называет, через запятую", "address": "", "website": ""} — ВСЕГДА, если в команде есть новые координаты места или человека '
        '(телефон, почта, адрес), иначе null, '
        '"channel": "whatsapp | telegram (для message)", "account": "аккаунт ОТПРАВИТЕЛЯ — только если Ден прямо сказал «с аккаунта/с номера …», иначе пустая строка; номер, КОМУ писать, — это to", '
        '"language": "es" | "en" | "ru" | "fr" | "it" | "de" | "pt" | "auto", '
        '"task": "для call: полная задача для агента по-русски со всеми деталями (дата с днём недели, время, '
        'число людей, допустимые варианты, что сказать)", '
        '"note": "для note: текст заметки на сегодня", '
        '"question": "для question: короткий вопрос Дену, если не хватает критичного (номера, или контакт неоднозначен)", '
        '"say": "1–2 коротких предложения, которые секретарь скажет Дену вслух: «Принял.» и повтор команды своими словами — кому/куда, что именно сделает, с ключевыми деталями (дата, время, число людей). '
        'На «ты», Ден мужчина. Без номеров телефонов, называй контакт по имени."}\n'
        "call — позвонить кому-то; note — запомнить заметку/инструкцию на сегодня для входящих звонков; "
        "message — написать кому-то в WhatsApp или Telegram (поля: channel = whatsapp|telegram, to = номер +… или @username "
        "или имя контакта из записной книжки, contact = имя, task = что написать/чего добиться, account = с какого аккаунта, "
        "если назвал, language = язык сообщения или auto); "
        "ride — вызвать машину: provider = uber (по умолчанию для «Uber», «вызови машину») или taxi («такси», «закажи такси по "
        "телефону»); поля pickup (пусто = где я сейчас), dropoff (куда — место/адрес), time («сейчас» или ЧЧ:ММ), passengers, town "
        "(если Ден назвал город), notes; "
        "note_save — «запиши/запомни заметку», «сохрани в заметки» (поле note_text — текст заметки как сказал Ден, без слов-команд; "
        "remind = когда напомнить, если сказал, иначе пусто); "
        "note_find — «что у меня записано про …», «найди заметку …», «какие заметки за неделю» (поле query); "
        "(note — НЕ это: note только «заметка на сегодня» для входящих звонков); "
        "shop — купить/найти/сравнить/заказать в интернет-магазине или заказать еду/продукты в Glovo (поля: task = задача "
        "для агента-покупателя полностью, со всеми деталями Дена: что, сколько, бюджет, срок, к какому времени; store = amazon|"
        "elcorteingles|mediamarkt|aliexpress|zara|iherb|glovo или пусто); "
        f"shop_answer — Ден отвечает на вопрос Призмы (открытый вопрос: {(open_shop_question() or {}).get('question') or 'нет'}); поле answer; "
        "cancel_job — «отмени последнюю задачу», «отмени звонок в Nobu», «отмени покупку», «не отправляй» (поле query — какую, пусто = последнюю); "
        "inbox — «сколько у меня непрочитанных», «есть что-то важное в почте», «кто мне писал в WhatsApp»; "
        "deliveries — вопросы о заказах и посылках («что мне сегодня привезут», «когда придёт заказ с Амазона», «какие доставки на неделе»); "
        "remember_place — Ден только даёт координаты места/человека, чтобы запомнить («занеси в свою записную книжку», «запомни контакт»; "
        "без другого действия) — это книжка СЕКРЕТАРЯ, не телефона; "
        "для message: если Ден продиктовал сам текст (после «:» или «напиши ему, что …» дословно) — положи его в text_exact, исправив только "
        "ошибки распознавания и знаки препинания; если просит сформулировать — оставь text_exact пустым; "
        "account — аккаунт ОТПРАВИТЕЛЯ, если Ден его назвал («с московского», «с испанского», «с французского», «с номера +7…»); "
        f"мои аккаунты: {accounts_text()}; "
        "получателя ищи СНАЧАЛА в записной книжке секретаря, потом в телефонной; для WhatsApp бери WhatsApp/мобильный, "
        "для Telegram — Telegram-ник или номер; "
        "для call/message бери номер/почту из записной книжки секретаря, если Ден назвал место по имени; "
        "message — также и ПО ПОЧТЕ: channel = email, to = адрес почты («забронируй по почте», «напиши письмо»); "
        "watch_mail — следить за почтой: сообщить, когда придёт письмо от отправителя (поля: sender = имя/адрес/домен отправителя, "
        "channels = [call, telegram, app] как сказал, once = true если «когда придёт» (один раз), false если «каждый раз/всегда»); "
        "unwatch_mail — перестать следить (sender); "
        "suggestion — Ден отвечает на подсказки секретаря («сделай 1», «да, второе», «сделай все»); "
        f"открытые подсказки: {'; '.join(f'{i + 1}. {x}' for i, x in enumerate(s['text'] for s in open_suggestions())) or 'нет'}; "
        "calendar — всё про его расписание: встречи, события, «напомни», дела/задачи, «что у меня завтра», утренняя сводка; "
        "note — только инструкция секретарю на сегодня для входящих звонков; "
        "recent — Ден спрашивает, кто звонил или чем закончились звонки; status — спрашивает, выполнены ли его поручения "
        "на звонки, сколько было попыток; cancel — просит перестать дозваниваться / отменить поручение; question — нужно уточнение; "
        "other — что-то другое. Язык звонка: если Ден его назвал — этот; иначе auto (определю по коду страны номера). "
        f"Сейчас {now_str()} (Испания)."
    )
    msg = await ai_create(model=SMART_MODEL, max_tokens=700, messages=[{"role": "user", "content": prompt}])
    m = re.search(r"\{.*\}", text_of(msg), re.S)
    plan = json.loads(m.group(0)) if m else {"action": "other"}
    if plan.get("action") == "call" and not plan.get("to"):
        plan["action"] = "question"
        plan["question"] = plan.get("question") or "На какой номер звонить?"
    return plan


async def spoken_recent() -> str:
    rows = recent_calls_text(5)
    if rows.startswith("Звонков"):
        return rows
    msg = await ai_create(
        model=SMART_MODEL, max_tokens=300,
        messages=[{"role": "user", "content": (
            "Перескажи Дену вслух (на «ты», он мужчина) в 2–4 коротких предложениях, кто звонил и чем закончилось, "
            f"начиная с последних. Без номеров телефонов, если известно имя или организация.\n{rows}")}])
    return text_of(msg)


DO_TAIL = re.compile(r"[\s,.!?—–-]*(делай|выполняй|поехали)[\s.!?,…»\"']*$", re.I)


async def cancel_job(jid: str) -> str:
    r = db.execute("SELECT * FROM jobs WHERE id=?", (jid,)).fetchone()
    if not r:
        return "нет такой задачи"
    link = r["link"] or ""
    kind, _, ref = link.partition(":")
    what = "задачу"
    if kind == "task":
        cancel_tasks(ref)
        for c in db.execute("SELECT id FROM calls WHERE task_id=? AND status IN ('dialing','live')", (ref,)).fetchall():
            sess = LIVE.get(c["id"])
            if sess:
                sess.outcome = "отменено Деном"
                sess.hangup_later({"action": "hangup"}, "")
        what = "звонок"
    elif kind == "shop":
        bus_put("caller", "prisma", "shop.cancel", {"ref": int(ref)})
        db.execute("UPDATE shop_jobs SET status='cancelled' WHERE ref=?", (ref,))
        what = "покупку"
    elif kind == "msg":
        t = PENDING_SENDS.pop(ref, None)
        st = (db.execute("SELECT status FROM msg_tasks WHERE id=?", (ref,)).fetchone() or {"status": ""})["status"]
        if t:
            t.cancel()
        db.execute("UPDATE msg_tasks SET status='cancelled' WHERE id=?", (ref,))
        what = "сообщение — не отправлено" if st == "pending" else "переписку (сообщение уже ушло, дальше я не отвечаю)"
    db.commit()
    job_step(f"Отменено: {what}", "cancelled", jid)
    return what


async def handle_command(text: str) -> dict:
    """Runs a command and keeps a live log of it (shown in the app as «Ход выполнения»)."""
    text = DO_TAIL.sub("", text or "").strip() or text
    jid = job_new(text)
    tok = CUR_JOB.set(jid)
    try:
        res = await _handle_command(text)
    except Exception as e:
        job_step(f"Ошибка: {e}", "error", jid)
        CUR_JOB.reset(tok)
        raise
    CUR_JOB.reset(tok)
    row = db.execute("SELECT status, link FROM jobs WHERE id=?", (jid,)).fetchone()
    reply = (res.get("reply") or "").strip()
    if row and row["link"] and row["status"] in ("active", "wait"):
        job_step("", title=reply.split("\n")[0][:120], jid=jid)  # continues: call / Prisma / message
    else:
        bad = reply.startswith(("Не получилось", "Не понял", "Не нашёл")) or "ошибка" in reply[:60].lower()
        job_step(reply.replace("\n", " ")[:300] or "Готово", "error" if bad else "done", jid, title=reply.split("\n")[0][:120])
    res["job_id"] = jid
    return res


async def _handle_command(text: str) -> dict:
    """Shared by Telegram (text and voice), the app's mic button and /api/command.
    Returns {"reply": text for the screen, "speak": short phrase to say aloud}."""
    st = load_state()
    low = text.lower().strip(" .!,")
    if PENDING_CALLS and low in ("да", "звони", "позвони", "давай", "ок", "ok", "yes", "нет", "отмена", "не надо", "no"):
        _, p = PENDING_CALLS.popitem()
        if low in ("нет", "отмена", "не надо", "no"):
            return {"reply": "Отменено.", "speak": "Хорошо, отменил."}
        try:
            await start_outbound(p["to"], p["task"], p.get("language", "auto"), p.get("contact", ""))
            return {"reply": f"📲 Звоню на {norm(p['to'])}… Итог пришлю.", "speak": "Звоню."}
        except Exception as e:
            return {"reply": f"Не получилось позвонить: {e}", "speak": "Не получилось позвонить. Подробности на экране."}

    full = f"{LAST_REQ['text']}\nУточнение: {text}" if LAST_REQ["text"] else text
    try:
        plan = await parse_command(full)
    except Exception as e:
        return {"reply": f"Не понял команду ({e}).", "speak": "Не понял команду, повтори, пожалуйста."}
    act = plan.get("action")
    say = plan.get("say") or ""
    job_step({"call": "Понял: звонок", "message": "Понял: написать сообщение", "ride": "Понял: машина",
              "shop": "Понял: покупка через Призму", "calendar": "Понял: календарь", "note_save": "Понял: заметка",
              "note_find": "Ищу в заметках", "inbox": "Проверяю входящие", "deliveries": "Смотрю доставки"}.get(act, "Разобрал команду"))
    rem = plan.get("remember") or {}
    saved = save_place(rem) if isinstance(rem, dict) and (rem.get("phone") or rem.get("email") or rem.get("address")) else ""
    if act == "remember_place":
        if not saved:
            return {"reply": "Не нашёл, что записать: нужен телефон, почта или адрес.", "speak": "Не понял, что записать."}
        r = f"Записал в записную книжку: {rem.get('name') or ''}" + "".join(
            f", {lbl} {rem[k]}" for k, lbl in (("phone", "телефон"), ("email", "почта"), ("whatsapp", "WhatsApp"), ("address", "адрес"))
            if rem.get(k)) + "."
        return {"reply": "📒 " + r, "speak": say or r}

    if act == "question":
        LAST_REQ["text"] = full
        q = plan.get("question") or "Уточни, пожалуйста."
        return {"reply": q, "speak": q}
    LAST_REQ["text"] = ""

    if act == "note":
        r = load_rules()
        r["notes"] = plan.get("note") or text
        save_rules(r)
        return {"reply": f"📝 Заметка на сегодня: {r['notes']}", "speak": say or "Запомнил."}

    if act == "recent":
        t = await spoken_recent()
        return {"reply": t, "speak": t}

    if act == "note_save":
        LAST_REQ["text"] = ""
        body = (plan.get("note_text") or text).strip()
        n = await note_add(body, source="voice")
        extra = ""
        if plan.get("remind"):
            try:
                r_ = await calendar_agent(f"Напомни: {n['title']} — {plan['remind']}")
                extra = " " + r_["speak"]
            except Exception:
                pass
        r = f"Записал заметку «{n['title']}»" + (" — она закрытая, вслух не читаю." if n["secret"] else ".") + extra
        return {"reply": "📝 " + r, "speak": "Принял. " + r}

    if act == "note_find":
        LAST_REQ["text"] = ""
        d = await notes_search(plan.get("query") or text)
        return {"reply": "📝 " + (d.get("answer") or ""), "speak": d.get("answer") or "Не нашёл.", "note_ids": d.get("ids") or []}

    if act == "shop":
        LAST_REQ["text"] = ""
        await shop_order(plan.get("task") or text, plan.get("store") or "")
        where = {"glovo": "Glovo", "amazon": "Amazon"}.get((plan.get("store") or "").lower(), "магазин")
        r = (f"Принял, передал Призме ({where}). Она найдёт и соберёт заказ, а перед оплатой попросит подтвердить отпечатком.")
        job_step("Открываю Призму на телефоне, чтобы она сразу взяла задачу")
        return {"reply": "🛒 " + r, "speak": say or r, "open_url": "prisma://poll"}

    if act == "shop_answer":
        q = open_shop_question()
        if not q:
            return {"reply": "Призма сейчас ничего не спрашивает.", "speak": "Призма сейчас ничего не спрашивает."}
        bus_put("caller", "prisma", "shop.answer", {"ref": q["ref"], "answer": plan.get("answer") or text})
        db.execute("UPDATE shop_jobs SET status='sent', question='', updated=? WHERE ref=?", (time.time(), q["ref"]))
        db.commit()
        return {"reply": "🛒 Передал ответ Призме.", "speak": "Принял, передал Призме."}

    if act == "cancel_job":
        q = (plan.get("query") or "").lower()
        rows = db.execute("SELECT * FROM jobs WHERE status IN ('active','wait') AND id!=? ORDER BY created DESC",
                          (CUR_JOB.get() or "",)).fetchall()
        pick = None
        for r in rows:
            if not q or any(w[:5] in (r["text"] + " " + (r["title"] or "")).lower() for w in re.findall(r"\w{4,}", q)):
                pick = r
                break
        if not pick:
            return {"reply": "Нечего отменять: задач в работе нет.", "speak": "Нечего отменять."}
        what = await cancel_job(pick["id"])
        return {"reply": f"✖️ Отменил {what}: «{pick['text'][:80]}»", "speak": f"Отменил {what.split(' —')[0]}."}

    if act == "inbox":
        LAST_REQ["text"] = ""
        return await inbox_answer(text)

    if act == "ride":
        LAST_REQ["text"] = ""
        try:
            return await order_ride(plan, text)
        except Exception as e:
            return {"reply": f"Не получилось с машиной: {e}", "speak": "Не получилось вызвать машину."}

    if act == "deliveries":
        LAST_REQ["text"] = ""
        MAIL_SCAN["last"] = await scan_mail(30, force=bool(re.search(r"почт|провер|просмотр|mail", text.lower())))
        t = await deliveries_answer(text)
        return {"reply": "📦 " + t, "speak": t}

    if act == "watch_mail":
        pat = (plan.get("sender") or "").strip()
        if not pat:
            LAST_REQ["text"] = full
            return {"reply": "От кого ждать письмо?", "speak": "От кого ждать письмо?"}
        LAST_REQ["text"] = ""
        chans = _ch(plan.get("channels") or []) or "call"
        once = plan.get("once") is not False
        db.execute("INSERT INTO mail_watch VALUES(?,?,?,?,?,?,?,?)",
                   (uuid.uuid4().hex[:8], pat, chans, 1 if once else 0, text, time.time(), "active", 0))
        db.commit()
        how = {"call": "позвоню", "telegram": "напишу в Telegram", "app": "покажу в приложении"}
        hows = " и ".join(how[c] for c in chans.split(","))
        r = f"Принял. Как придёт письмо от «{pat}», {hows}" + ("." if once else " — каждый раз.")
        return {"reply": "📬 " + r + ("" if sb_base() else "\n(Почта приходит через SB — нужен подключённый SB.)"), "speak": say or r}

    if act == "unwatch_mail":
        pat = (plan.get("sender") or "").strip().lower()
        n = 0
        for w in db.execute("SELECT * FROM mail_watch WHERE status='active'").fetchall():
            if not pat or pat in w["pattern"].lower() or w["pattern"].lower() in pat:
                db.execute("UPDATE mail_watch SET status='off' WHERE id=?", (w["id"],))
                n += 1
        db.commit()
        return {"reply": f"Перестал следить: {n}.", "speak": "Хорошо, больше не слежу." if n else "Такого наблюдения не было."}

    if act == "message":
        if not plan.get("to"):
            LAST_REQ["text"] = full
            q = "Кому написать — номер или имя?"
            return {"reply": q, "speak": q}
        LAST_REQ["text"] = ""
        try:
            r = await send_message_task(plan.get("channel") or "whatsapp", plan["to"], plan.get("task") or text,
                                        plan.get("language") or "", plan.get("account") or "", plan.get("contact") or "",
                                        plan.get("text_exact") or "")
        except Exception as e:
            return {"reply": f"Не получилось отправить: {e}", "speak": "Не получилось отправить, подробности на экране."}
        app_name = {"whatsapp": "WhatsApp", "telegram": "Telegram", "email": "почту"}.get(r["channel"], r["channel"])
        who = plan.get("contact") or (rem.get("name") if isinstance(rem, dict) else "") or plan["to"]
        note = "\n📒 Координаты сохранил в записную книжку." if saved else ""
        wait = f"Отправлю через {r['delay']} с — можно отменить в «Задачах» или сказать «отмена». " if r.get("delay") else ""
        return {"reply": f"✉️ {app_name}{(' (' + r['account'] + ')') if r.get('account') else ''} → {who}:\n«{r['text']}»\n\n{wait}Ответ пришлю сюда.{note}",
                "speak": say or f"Принял. Написал {who} в {app_name}, ответ пришлю."}

    if act == "suggestion":
        sugg = open_suggestions()
        nums = plan.get("numbers") or []
        picked = [sugg[n - 1] for n in nums if isinstance(n, int) and 0 < n <= len(sugg)] or sugg[:1]
        replies = [await do_suggestion(x["id"]) for x in picked]
        return {"reply": "\n\n".join(r["reply"] for r in replies) or "Подсказок нет.",
                "speak": " ".join(r["speak"] for r in replies) or "Подсказок нет."}

    if act == "calendar":
        LAST_REQ["text"] = ""
        try:
            return await calendar_agent(text)
        except Exception as e:
            return {"reply": f"Календарь: ошибка ({e})", "speak": "Не получилось записать в календарь."}

    if act == "status":
        t = tasks_text()
        act_n = len(active_tasks())
        sp = (f"Сейчас в работе {act_n} поручение. Подробности на экране." if act_n == 1 else
              f"Сейчас в работе поручений: {act_n}. Подробности на экране." if act_n else
              "Активных поручений нет. Последние результаты на экране.")
        return {"reply": t, "speak": say or sp}

    if act == "cancel":
        n = cancel_tasks()
        return {"reply": f"Отменил повторные звонки: {n}." if n else "Нечего отменять: повторных звонков не запланировано.",
                "speak": "Отменил." if n else "Нечего отменять."}

    if act == "call":
        to = norm(plan["to"])
        who = f"{plan['contact']} ({to})" if plan.get("contact") else to
        code = lang_in_text(plan.get("task", "")) or (plan.get("language") if plan.get("language") in LANGS
                                                      else lang_for(norm(plan["to"])))
        lang = LANG_NAMES.get(code, "английский")
        if st.get("confirm"):
            PENDING_CALLS.clear()
            PENDING_CALLS[secrets.token_hex(4)] = plan
            return {"reply": f"Позвонить: {who}, {lang}? Ответь «да».\n\nЗадача: {plan['task']}",
                    "speak": (say + " Скажи «да», и я позвоню.").strip()}
        try:
            await start_outbound(plan["to"], plan["task"], plan.get("language", "auto"), plan.get("contact", ""))
        except Exception as e:
            return {"reply": f"Не получилось позвонить {who}: {e}", "speak": "Не получилось позвонить. Подробности на экране."}
        n, m = retry_settings()
        return {"reply": f"📲 Звоню: {who}, {lang}. Итог пришлю. Если не дозвонюсь — повторю, всего до {n} попыток "
                         f"каждые {m} мин.\n\nЗадача: {plan['task']}", "speak": say or "Принял, звоню."}

    return {"reply": "Я умею звонить по поручению, запоминать заметку на сегодня и рассказывать, кто звонил.",
            "speak": "Я умею звонить, запоминать заметки и рассказывать, кто звонил."}


async def transcribe(audio: bytes, filename: str, mime: str) -> str:
    if cfg("DEEPGRAM_KEY"):
        try:
            async with httpx.AsyncClient(timeout=30) as h:
                r = await h.post("https://api.deepgram.com/v1/listen",
                                 params={"model": "nova-2", "language": "ru", "smart_format": "true", "punctuate": "true"},
                                 headers={"Authorization": f"Token {cfg('DEEPGRAM_KEY')}", "Content-Type": mime or "audio/webm"},
                                 content=audio)
            if r.status_code < 300:
                alt = r.json()["results"]["channels"][0]["alternatives"][0]
                return (alt.get("transcript") or "").strip()
            log.warning("deepgram %s %s", r.status_code, r.text[:200])
        except Exception as e:
            log.warning("deepgram: %s", e)
    async with httpx.AsyncClient(timeout=60) as h:
        r = await h.post(
            f"{TELNYX}/ai/audio/transcriptions",
            headers={"Authorization": f"Bearer {cfg('TELNYX_API_KEY')}"},
            data={"model": "openai/whisper-large-v3-turbo", "language": "ru"},
            files={"file": (filename, audio, mime)},
        )
    if r.status_code >= 300:
        raise RuntimeError(f"распознавание речи: {r.status_code} {r.text[:200]}")
    return (r.json().get("text") or "").strip()


async def tg_handle(u: dict):
    st = load_state()
    m = u.get("message") or {}
    text = (m.get("text") or "").strip()
    chat = (m.get("chat") or {}).get("id")
    if not chat:
        return
    code_typed = re.sub(r"[^A-Z0-9]", "", (text.split()[-1] if text else "").upper())
    if chat != st.get("tg_chat"):
        # not linked yet: accept "/start CODE" or just "CODE", otherwise explain what to send
        if SETUP_CODE and code_typed == SETUP_CODE:
            st["tg_chat"] = chat
            save_state(st)
            await tg_api("sendMessage", chat_id=chat, text="Готово, это твой секретарь. Сводки звонков будут приходить сюда.\n\n" + TG_HELP)
        elif not st.get("tg_chat"):
            await tg_api("sendMessage", chat_id=chat,
                         text="Пришли код из приложения (вкладка «Настройка»), например: /start KX7M4QPR")
        return
    if text.startswith("/start"):
        return await tg_api("sendMessage", chat_id=chat, text="Я на связи.\n\n" + TG_HELP)

    async def reply(t, **kw):
        await tg_api("sendMessage", chat_id=chat, text=t, **kw)

    photo = (m.get("photo") or [None])[-1]
    doc = m.get("document") if (m.get("document") or {}).get("mime_type", "").startswith("image/") else None
    if photo or doc:
        try:
            f = await tg_api("getFile", file_id=(photo or doc)["file_id"])
            async with httpx.AsyncClient(timeout=60) as h:
                img = (await h.get(f"https://api.telegram.org/file/bot{cfg('TELEGRAM_BOT_TOKEN')}/{f['result']['file_path']}")).content
            res = await read_screenshot(img, (doc or {}).get("mime_type", "image/jpeg"), m.get("caption") or "")
        except Exception as e:
            return await reply(f"Не смог прочитать скриншот: {e}")
        return await reply(res["reply"])
    photo = (m.get("photo") or [None])[-1] or (m.get("document") if (m.get("document") or {}).get("mime_type", "").startswith("image/") else None)
    if photo:
        try:
            f = await tg_api("getFile", file_id=photo["file_id"])
            path = f["result"]["file_path"]
            async with httpx.AsyncClient(timeout=60) as h:
                img = (await h.get(f"https://api.telegram.org/file/bot{cfg('TELEGRAM_BOT_TOKEN')}/{path}")).content
            mt = "image/png" if path.lower().endswith(".png") else "image/jpeg"
            if re.search(r"заметк|в архив|запиши", (m.get("caption") or "").lower()):
                n = await image_to_note(img, mt, m.get("caption") or "")
                return await reply(f"📝 Записал заметку «{n['title']}»" + (" (закрытая 🔒)." if n["secret"] else "."))
            r = await places_from_image(img, mt, (m.get("caption") or "").strip())
        except Exception as e:
            return await reply(f"Не смог прочитать картинку: {e}")
        lines = "\n".join("• " + place_line(p) for p in r["places"])
        await reply(f"📒 {r['what']}.\nЗаписал:\n{lines}" if r["places"] else f"На картинке ({r['what']}) не нашёл координат.")
        cap = (m.get("caption") or "").strip()
        if cap:
            res = await handle_command(cap)
            await reply(res["reply"])
        return
    voice = m.get("voice") or m.get("audio")
    if voice and not text:
        try:
            f = await tg_api("getFile", file_id=voice["file_id"])
            path = f["result"]["file_path"]
            async with httpx.AsyncClient(timeout=60) as h:
                audio = (await h.get(f"https://api.telegram.org/file/bot{cfg('TELEGRAM_BOT_TOKEN')}/{path}")).content
            text = await transcribe(audio, "voice.ogg", "audio/ogg")
        except Exception as e:
            return await reply(f"Не смог разобрать голосовое: {e}")
        if not text:
            return await reply("Не расслышал, повтори.")
        await reply(f"🎙 {text}")
    if not text:
        return

    if text.startswith("/help"):
        return await reply(TG_HELP)
    if text.startswith("/cancel"):
        LAST_REQ["text"] = ""
        PENDING_CALLS.clear()
        return await reply("Сброшено.")
    if text.startswith("/note"):
        r = load_rules()
        r["notes"] = text[5:].strip()
        save_rules(r)
        return await reply(f"Заметка на сегодня: {r['notes']}" if r["notes"] else "Заметка очищена.")
    if text.startswith("/calls"):
        return await reply(recent_calls_text(5))
    if text.startswith("/again"):
        row = db.execute("SELECT * FROM calls WHERE direction='out' AND task IS NOT NULL AND task!='' "
                         "ORDER BY started DESC LIMIT 1").fetchone()
        if not row:
            return await reply("Повторять нечего: исходящих поручений ещё не было.")
        try:
            await start_outbound(row["peer"], row["task"], row["lang"] or "auto")
            return await reply(f"📲 Повторяю: {row['peer']}\n\nЗадача: {row['task']}")
        except Exception as e:
            return await reply(f"Не получилось повторить: {e}")
    if text.startswith("/tasks"):
        return await reply(tasks_text())
    if text.startswith("/stop"):
        n = cancel_tasks()
        return await reply(f"Отменил повторные звонки: {n}." if n else "Повторных звонков не запланировано.")
    if text.startswith("/confirm"):
        st["confirm"] = text.split()[-1].lower() in ("on", "да", "1")
        save_state(st)
        return await reply("Перед звонком буду спрашивать подтверждение." if st["confirm"]
                           else "Буду звонить сразу, без подтверждения.")
    res = await handle_command(text)
    await reply(res["reply"])
    if cfg("ACK_TG") == "on":  # off by default: Den listens to Telegram through SB
        asyncio.create_task(tg_voice(chat, res.get("speak") or ""))


async def tg_loop():
    offset = 0
    while True:
        try:
            if not cfg("TELEGRAM_BOT_TOKEN"):
                await asyncio.sleep(10)
                continue
            res = await tg_api("getUpdates", offset=offset, timeout=50)
            for u in (res or {}).get("result", []):
                offset = u["update_id"] + 1
                try:
                    await tg_handle(u)
                except Exception as e:
                    log.exception("tg handle")
                    chat = ((u.get("message") or {}).get("chat") or {}).get("id")
                    if chat:
                        await tg_api("sendMessage", chat_id=chat, text=f"⚠️ Ошибка: {str(e)[:300]}")
            if res is None:
                await asyncio.sleep(5)
        except asyncio.CancelledError:
            raise
        except Exception:
            log.warning("tg loop error")
            await asyncio.sleep(5)


# ---------------------------------------------------------------- app


@asynccontextmanager
async def lifespan(_app):
    tg = asyncio.create_task(tg_loop())
    tl = asyncio.create_task(task_loop())
    cl = asyncio.create_task(cal_loop())
    yield
    tg.cancel()
    tl.cancel()
    cl.cancel()


app = FastAPI(lifespan=lifespan)


@app.get("/")
async def root():
    return {"ok": True, "version": VERSION, "live_calls": len(LIVE)}


@app.post("/h/{secret}/incoming")
async def h_incoming(secret: str, req: Request):
    check_hook(secret)
    f = await form_of(req)
    cid = uuid.uuid4().hex[:12]
    frm = f.get("From") or f.get("from") or f.get("Caller") or f.get("CallerId") or ""
    r = load_rules()
    owner = bool(cfg("OWNER_MOBILE")) and norm(frm) == norm(cfg("OWNER_MOBILE"))
    caller_lang = next((PREFIX_LANG[p] for p in sorted(PREFIX_LANG, key=len, reverse=True)
                        if norm(frm).startswith(p)), "")
    if owner:
        lang = "ru"
    elif caller_lang in r["greetings"]:
        lang = caller_lang  # +7 calls get a Russian greeting, +44 English, etc.
    else:
        lang = r.get("default_language") or "es"
    greeting = "Привет, Ден. Я на связи — спрашивай." if owner else r["greetings"].get(lang, "")
    GREETED[cid] = greeting
    first = [{"t": 0, "k": "← incoming", "d": str({"From": frm, "owner": owner, "lang": lang,
                                                   "fields": sorted(f.keys())})[:400]}]
    db_new(cid, sid=f.get("CallSid"), direction="owner" if owner else "in", peer=frm,
           started=time.time(), status="live", lang=lang, transcript="[]", journal=json.dumps(first, ensure_ascii=False))
    return twiml(relay_xml(cid, lang, greeting))


@app.post("/h/{secret}/sms")
async def h_sms(secret: str, req: Request):
    """Telnyx Messaging webhook: incoming SMS to the secretary's number → Telegram + app."""
    check_hook(secret)
    try:
        body = await req.json()
    except Exception:
        return Response(status_code=204)
    data = body.get("data") or {}
    if data.get("event_type") != "message.received":
        return Response(status_code=204)
    pl = data.get("payload") or {}
    frm = (pl.get("from") or {}).get("phone_number", "")
    text = (pl.get("text") or "").strip()
    media = [m.get("url") for m in (pl.get("media") or []) if m.get("url")]
    mid = pl.get("id") or uuid.uuid4().hex
    if db.execute("SELECT 1 FROM messages WHERE id=?", (mid,)).fetchone():
        return Response(status_code=204)  # Telnyx retries — don't forward twice
    db.execute("INSERT INTO messages(id, channel, peer, at, text) VALUES(?,?,?,?,?)",
               (mid, "sms", frm, time.time(), text + ("\n" + "\n".join(media) if media else "")))
    db.commit()
    await tg_send(f"✉️ SMS от {frm}:\n\n{text}" + ("\n\nВложения:\n" + "\n".join(media) if media else ""))
    return Response(status_code=204)


@app.post("/h/{secret}/outbound")
async def h_outbound(secret: str, req: Request, call_id: str):
    check_hook(secret)
    c = db_get(call_id)
    if not c:
        return twiml("<Hangup/>")
    db_set(call_id, status="live")
    t = task_get(c["task_id"]) if c.get("task_id") else {}
    opening = (t or {}).get("opening") or OPENING.get(c["lang"], OPENING["en"])
    GREETED[call_id] = opening
    return twiml(relay_xml(call_id, c["lang"], opening, greeting_interruptible=False))


@app.post("/h/{secret}/status")
async def h_status(secret: str, req: Request, call_id: str):
    check_hook(secret)
    f = await form_of(req)
    st = (f.get("CallStatus") or "").lower()
    names = {"busy": "занято", "no-answer": "не берут трубку", "failed": "звонок не прошёл", "canceled": "отменён"}
    c = db_get(call_id)
    if c and st == "completed" and c.get("status") in ("dialing", "live") and call_id not in LIVE:
        # answered but the conversation never started (line dropped)
        db_set(call_id, status="failed", outcome="связь оборвалась", ended=time.time())
        if c.get("task_id"):
            await task_result(c["task_id"], "retry", "связь оборвалась")
    if c and st in names and c.get("status") not in ("done", "failed"):
        db_set(call_id, status="failed", outcome=names[st], ended=time.time())
        if c.get("task_id"):
            await task_result(c["task_id"], "retry", names[st])
        else:
            await tg_send(f"📵 Не дозвонился на {c['peer']}: {names[st]}.\n\nЗадача: {c['task']}")
    return Response(status_code=204)


@app.post("/h/{secret}/after")
async def h_after(secret: str, req: Request, call_id: str):
    check_hook(secret)
    f = await form_of(req)
    act = NEXT_ACTION.pop(call_id, None)
    if not act:
        try:
            act = json.loads(f.get("HandoffData") or "{}")
        except Exception:
            act = {}
    owner = cfg("OWNER_MOBILE")
    if act.get("action") == "transfer" and owner:
        return twiml(
            f'<Dial timeout="15" callerId={quoteattr(cfg("TELNYX_NUMBER"))} action={quoteattr(hook("dial-done", call_id))}>'
            f"<Number>{escape(norm(owner))}</Number></Dial>"
        )
    return twiml("<Hangup/>")


@app.post("/h/{secret}/dial-done")
async def h_dial_done(secret: str, req: Request, call_id: str):
    check_hook(secret)
    f = await form_of(req)
    if (f.get("DialCallStatus") or "").lower() == "completed":
        return twiml("<Hangup/>")
    c = db_get(call_id)
    lang = c.get("lang") if c.get("lang") in ("es", "en", "ru") else "en"
    msg = {
        "es": "Den no puede atender ahora mismo. Le devolverá la llamada lo antes posible. Gracias, adiós.",
        "en": "Den can't take the call right now. He will call you back as soon as possible. Goodbye.",
        "ru": "Ден сейчас не может ответить. Он перезвонит вам как можно скорее. До свидания.",
    }[lang]
    await tg_send(f"☎️ Не смог соединить тебя. Перезвони: {c.get('peer')}")
    v = voice_of(lang)
    vattr = f" voice={quoteattr(v)}" if v else ""
    return twiml(f"<Say{vattr}>{escape(msg)}</Say><Hangup/>")


@app.websocket("/ws_listen")
async def ws_listen(ws: WebSocket):
    """Streams the mic to Deepgram and sends back text as it is spoken: {"t": text, "final": bool}."""
    tok = ws.query_params.get("token", "")
    if not PANEL_TOKEN or not secrets.compare_digest(tok, PANEL_TOKEN) or not cfg("DEEPGRAM_KEY"):
        await ws.close(code=1008)
        return
    await ws.accept()
    import websockets
    url = ("wss://api.deepgram.com/v1/listen?model=nova-2&language=ru&smart_format=true&punctuate=true"
           "&interim_results=true&endpointing=400")
    hdr = {"Authorization": f"Token {cfg('DEEPGRAM_KEY')}"}
    try:
        try:
            dg = await websockets.connect(url, additional_headers=hdr, max_size=None)
        except TypeError:  # older websockets
            dg = await websockets.connect(url, extra_headers=hdr, max_size=None)
    except Exception as e:
        await ws.send_json({"error": f"распознавание недоступно: {e}"})
        await ws.close()
        return

    async def up():
        try:
            while True:
                m = await ws.receive()
                if m.get("bytes"):
                    await dg.send(m["bytes"])
                elif m.get("text") == "stop" or m.get("type") == "websocket.disconnect":
                    break
        except Exception:
            pass
        try:
            await dg.send(json.dumps({"type": "CloseStream"}))
        except Exception:
            pass

    async def down():
        try:
            async for raw in dg:
                d = json.loads(raw)
                if d.get("type") != "Results":
                    continue
                t = (((d.get("channel") or {}).get("alternatives") or [{}])[0].get("transcript") or "").strip()
                if t:
                    await ws.send_json({"t": t, "final": bool(d.get("is_final"))})
        except Exception:
            pass

    await asyncio.gather(up(), down())
    try:
        await dg.close()
        await ws.close()
    except Exception:
        pass


@app.websocket("/ws/{secret}")
async def ws_endpoint(ws: WebSocket, secret: str):
    if not HOOK or not secrets.compare_digest(secret, HOOK):
        await ws.close(code=1008)
        return
    await ws.accept()
    await CallSession(ws).run()


# ---------------------------------------------------------------- panel API

CLAIM_TRIES = {"n": 0, "t": 0.0}


def auth(req: Request):
    if not PANEL_TOKEN or not secrets.compare_digest(req.headers.get("X-Token", ""), PANEL_TOKEN):
        raise HTTPException(401, "bad token")


@app.get("/panel")
async def panel():
    return HTMLResponse((BASE / "panel.html").read_text(encoding="utf-8"),
                        headers={"Cache-Control": "no-store, max-age=0"})


@app.post("/api/claim")
async def api_claim(req: Request):
    now = time.time()
    if now - CLAIM_TRIES["t"] > 60:
        CLAIM_TRIES.update(n=0, t=now)
    CLAIM_TRIES["n"] += 1
    if CLAIM_TRIES["n"] > 8:
        return JSONResponse({"error": "Слишком много попыток, подожди минуту."}, status_code=429)
    code = re.sub(r"[^A-Z0-9]", "", str((await req.json()).get("code", "")).upper())
    if not SETUP_CODE or not secrets.compare_digest(code, SETUP_CODE):
        return JSONResponse({"error": "Код не подходит. Он показан в конце установки на сервере."}, status_code=403)
    return {"token": PANEL_TOKEN}


@app.get("/api/calls")
async def api_calls(req: Request, limit: int = 60):
    auth(req)
    rows = db.execute("SELECT * FROM calls ORDER BY started DESC LIMIT ?", (limit,)).fetchall()
    out = []
    for r in rows:
        d = dict(r)
        s = LIVE.get(d["id"])
        d["live"] = bool(s)
        d["transcript"] = s.transcript if s else json.loads(d["transcript"] or "[]")
        d["journal"] = s.journal if s else json.loads(d.get("journal") or "[]")
        out.append(d)
    return out


@app.get("/api/rules")
async def api_rules_get(req: Request):
    auth(req)
    return load_rules()


@app.put("/api/rules")
async def api_rules_put(req: Request):
    auth(req)
    body = await req.json()
    r = load_rules()
    for k in DEFAULT_RULES:
        if k in body:
            r[k] = body[k]
    save_rules(r)
    return r


@app.get("/api/config")
async def api_config_get(req: Request):
    auth(req)
    c = cfg_all()
    out = {}
    for k in CONFIG_KEYS:
        v = c.get(k) or ""
        out[k] = ("••••" + v[-4:]) if (k in SECRET_KEYS and v) else v
    out["ALLOWED_PREFIXES"] = ", ".join(allowed_prefixes())
    out["RETRY_ATTEMPTS"], out["RETRY_MINUTES"] = (str(x) for x in retry_settings())
    out["CALL_MODEL"] = cfg("CALL_MODEL") or "haiku"
    out["STT_PROVIDER"] = stt_override() or "auto"
    out["MERGE_MS"] = cfg("MERGE_MS") or "700"
    out["AUTO_LANG"] = "on" if auto_lang() else "off"
    out["ACK_APP"] = "on" if ack_on("ACK_APP") else "off"
    out["ACK_TG"] = "on" if cfg("ACK_TG") == "on" else "off"
    out["REMIND_CHANNEL"] = default_channel()
    out["BRIEF_TIME"] = cfg("BRIEF_TIME")
    out["BRIEF_CHANNEL"] = cfg("BRIEF_CHANNEL") or default_channel()
    out["DUR_CALL"], out["DUR_MEETING"], out["DUR_MEAL"] = str(dur("CALL")), str(dur("MEETING")), str(dur("MEAL"))
    out["HOME_ADDRESS"] = cfg("HOME_ADDRESS")
    out["LEAVE_BUFFER"] = cfg("LEAVE_BUFFER") or "10"
    out["SUGGEST_TIME"] = cfg("SUGGEST_TIME") or "19:30"
    out["sb_url"] = f"https://{HOST}/api/ingest/email"
    out["sb_key"] = sb_key()
    out["bus_url"] = f"https://{HOST}/bus"
    out["bus_token"] = bus_token()
    out["INBOX_NAMES"] = cfg("INBOX_NAMES") or "on"
    out["INBOX_ALERT"] = cfg("INBOX_ALERT") or "on"
    out["INBOX_ALERT_MIN"] = cfg("INBOX_ALERT_MIN") or "60"
    out["QUICK_ACK"] = cfg("QUICK_ACK") or "on"
    out["DO_MODE"] = cfg("DO_MODE") or "off"
    out["DO_WORD"] = cfg("DO_WORD") or "делай"
    out["live_stt"] = bool(cfg("DEEPGRAM_KEY"))
    out["SEND_DELAY"] = str(send_delay())
    out["SB_URL"] = cfg("SB_URL")
    out["SB_DEFAULT_WHATSAPP"] = cfg("SB_DEFAULT_WHATSAPP")
    out["SB_DEFAULT_TELEGRAM"] = cfg("SB_DEFAULT_TELEGRAM")
    out["MSG_SIGNATURE"] = cfg("MSG_SIGNATURE")
    out["voice_url"] = hook("incoming")
    out["sms_url"] = hook("sms")
    out["version"] = VERSION
    return out


@app.put("/api/config")
async def api_config_put(req: Request):
    auth(req)
    body = await req.json()
    upd = {}
    for k in CONFIG_KEYS:
        v = str(body.get(k, "")).strip()
        if not v or v.startswith("••••"):
            continue  # empty or masked = unchanged
        if k in ("TELNYX_NUMBER", "OWNER_MOBILE"):
            v = norm(v)
        if k == "BRIEF_TIME" and v.lower() in ("off", "выкл", "-"):
            cfg_save({k: ""})
            continue
        if k == "ALLOWED_PREFIXES":
            cfg_save({k: v})
            continue
        upd[k] = v
    cfg_save(upd)
    return {"saved": list(upd)}


@app.get("/api/check")
async def api_check(req: Request):
    auth(req)
    return await run_checks(fix=True)


@app.post("/api/contacts")
async def api_contacts(req: Request):
    auth(req)
    body = await req.json()
    out = []
    for c in body.get("contacts", [])[:5000]:
        name = str(c.get("name", "")).strip()
        phones = []
        for p in c.get("phones", []):
            n = norm(str(p))
            if re.fullmatch(r"\+\d{8,15}", n) and n not in phones:
                phones.append(n)
        if name and phones:
            out.append({"name": name[:80], "phones": phones[:5]})
    CONTACTS_F.write_text(json.dumps(out, ensure_ascii=False), encoding="utf-8")
    return {"count": len(out)}


@app.get("/api/contacts")
async def api_contacts_count(req: Request):
    auth(req)
    return {"count": len(load_contacts())}


@app.post("/api/command")
async def api_command(req: Request):
    """Text command, e.g. from Den's own programs: {"text": "позвони маме ..."}."""
    auth(req)
    text = str((await req.json()).get("text", "")).strip()
    if not text:
        return JSONResponse({"error": "пустая команда"}, status_code=400)
    return {"heard": text, **(await handle_command(text))}


@app.post("/api/transcribe")
async def api_transcribe(req: Request):
    """Audio → text only (the app collects the command and sends it on «делай»)."""
    auth(req)
    audio = await req.body()
    if len(audio) < 1000:
        return {"text": ""}
    mime = (req.headers.get("content-type") or "audio/webm").split(";")[0]
    ext = {"audio/webm": "webm", "audio/ogg": "ogg", "audio/mp4": "m4a", "audio/aac": "aac"}.get(mime, "webm")
    try:
        return {"text": await transcribe(audio, f"voice.{ext}", mime)}
    except Exception as e:
        return JSONResponse({"error": str(e)}, status_code=502)


@app.post("/api/voice")
async def api_voice(req: Request):
    """Raw audio from the app's mic button → text → command."""
    auth(req)
    audio = await req.body()
    if len(audio) < 1000:
        return JSONResponse({"error": "Запись слишком короткая"}, status_code=400)
    mime = (req.headers.get("content-type") or "audio/webm").split(";")[0]
    ext = {"audio/webm": "webm", "audio/ogg": "ogg", "audio/mp4": "m4a", "audio/aac": "aac"}.get(mime, "webm")
    try:
        text = await transcribe(audio, f"voice.{ext}", mime)
    except Exception as e:
        return JSONResponse({"error": str(e)}, status_code=502)
    if not text:
        return {"heard": "", "reply": "Не расслышал.", "speak": "Не расслышал, повтори, пожалуйста."}
    res = await handle_command(text)
    asyncio.create_task(tg_send(f"🎙 {text}\n\n{res['reply']}"))
    if not ack_on("ACK_APP"):
        res["speak"] = ""
    return {"heard": text, **res}


@app.post("/api/update")
async def api_update(req: Request):
    """Downloads the latest secretary.zip from GitHub and reinstalls (settings are kept)."""
    auth(req)
    script = (
        "set -e; rm -rf /tmp/sec_upd && mkdir -p /tmp/sec_upd && cd /tmp/sec_upd && "
        f"curl -fsSL -H 'Accept: application/vnd.github.raw' -o s.zip '{UPDATE_URL}' && python3 -m zipfile -e s.zip . && "
        "bash secretary/install.sh > /root/update.log 2>&1"
    )
    proc = await asyncio.create_subprocess_exec(
        "systemd-run", "--unit", f"secretary-update-{int(time.time())}", "--collect", "bash", "-c", script,
        stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.STDOUT)
    out, _ = await proc.communicate()
    if proc.returncode != 0:
        return JSONResponse({"error": f"Не удалось запустить обновление: {out.decode()[:200]}"}, status_code=500)
    return {"ok": True}


@app.get("/api/tasks")
async def api_tasks(req: Request):
    auth(req)
    rows = db.execute("SELECT * FROM tasks ORDER BY created DESC LIMIT 20").fetchall()
    return [dict(r) for r in rows]


@app.post("/api/tasks/{tid}/cancel")
async def api_task_cancel(req: Request, tid: str):
    auth(req)
    return {"cancelled": cancel_tasks(tid)}


@app.post("/api/test_voice")
async def api_test_voice(req: Request):
    """Calls Den's own mobile in the chosen language to check that the voice is heard."""
    auth(req)
    lang = str((await req.json()).get("lang", "ru"))
    if not cfg("OWNER_MOBILE"):
        return JSONResponse({"error": "укажи свой мобильный во вкладке «Настройка»"}, status_code=400)
    try:
        tid = await start_outbound(cfg("OWNER_MOBILE"), "Тестовый звонок для проверки голоса: после приветствия скажи одну "
                                   "короткую фразу о том, что голос работает, и попрощайся. Перезванивать не нужно.", lang)
        task_set(tid, max_attempts=1)
    except Exception as e:
        return JSONResponse({"error": str(e)}, status_code=400)
    return {"ok": True}


@app.post("/api/repeat/{call_id}")
async def api_repeat(req: Request, call_id: str):
    """Repeats the task of an earlier outbound call (same number, task and language)."""
    auth(req)
    c = db_get(call_id)
    if not c or c.get("direction") != "out" or not c.get("task"):
        return JSONResponse({"error": "повторить можно только исходящий звонок с заданием"}, status_code=400)
    contact = (task_get(c["task_id"]) or {}).get("contact", "") if c.get("task_id") else ""
    try:
        tid = await start_outbound(c["peer"], c["task"], c.get("lang") or "auto", contact)
    except Exception as e:
        return JSONResponse({"error": str(e)}, status_code=400)
    return {"id": tid}


@app.get("/api/calendar")
async def api_calendar(req: Request, days: int = 14):
    auth(req)
    now = time.time()
    day0 = datetime.now(TZ).replace(hour=0, minute=0, second=0).timestamp()
    ev = [{"id": e["id"], "title": e["title"], "at": e["occ"], "end": e["occ_end"], "all_day": bool(e["all_day"]),
           "location": e["location"], "repeat": bool(e["rrule"]), "remind": json.loads(e["remind"] or "[]"),
           "phone": is_phone(e), "calendar": e.get("calendar", ""), "from_call": e.get("source") == "call",
           "channel": e.get("channel") or ""}
          for e in agenda(day0, now + days * 86400)]
    rems = [dict(r) for r in db.execute("SELECT * FROM cal_reminders WHERE status='active' ORDER BY at").fetchall()]
    done = [dict(r) for r in db.execute("SELECT * FROM cal_todos WHERE status='done' ORDER BY done_at DESC LIMIT 10").fetchall()]
    return {"events": ev, "todos": open_todos(), "done": done, "reminders": rems,
            "brief": cfg("BRIEF_TIME"), "channel": default_channel(),
            "phone_sync": {"at": float(cfg("PHONE_SYNC_AT") or 0), "n": int(cfg("PHONE_SYNC_N") or 0)}}


@app.get("/api/calendar/range")
async def api_calendar_range(req: Request, start: str, end: str):
    """Everything between two local dates (inclusive): events (incl. phone), reminder occurrences, to-dos due."""
    auth(req)
    a, b = to_ts(start[:10]), to_ts(end[:10] + "T23:59")
    ev = [{"id": e["id"], "title": e["title"], "at": e["occ"], "end": e["occ_end"], "all_day": bool(e["all_day"]),
           "location": e["location"], "notes": e.get("notes") or "", "repeat": bool(e["rrule"]),
           "remind": json.loads(e["remind"] or "[]"), "channel": e.get("channel") or "", "phone": is_phone(e),
           "calendar": e.get("calendar", ""), "from_call": e.get("source") == "call",
           "done": is_done(f"{e['id']}:{int(e['occ'])}")} for e in agenda(a, b)]
    rem = []
    for r in db.execute("SELECT * FROM cal_reminders WHERE status='active'").fetchall():
        for ts in occurrences(r["at"], r["rrule"] or "", a, b, 100):
            rem.append({"id": r["id"], "text": r["text"], "at": ts, "repeat": bool(r["rrule"]), "channel": r["channel"] or ""})
    todos = [t for t in open_todos() if t["due"] and a <= t["due"] <= b]
    dl = []
    for d in db.execute("SELECT * FROM deliveries WHERE status NOT IN ('cancelled','returned')").fetchall():
        d = dict(d)
        at = d["delivered_at"] if d["status"] == "delivered" else d["exp_to"] or d["exp_from"]
        if at and a <= at <= b:
            dl.append({"id": d["id"], "at": at, "text": f"{d['store']}: {d['items'] or 'заказ'}", "status": d["status"],
                       "status_ru": DELIV_STATUS.get(d["status"], ""), "carrier": d["carrier"],
                       "late": d["status"] != "delivered" and bool(d["exp_to"]) and d["exp_to"] < time.time()})
    return {"events": ev, "reminders": sorted(rem, key=lambda x: x["at"]), "todos": todos, "deliveries": dl,
            "channel": default_channel(),
            "durations": {"call": dur("CALL"), "meeting": dur("MEETING"), "meal": dur("MEAL")}}


@app.post("/api/calendar/{kind}/{item_id}/{action}")
async def api_calendar_action(req: Request, kind: str, item_id: str, action: str):
    auth(req)
    if kind == "event" and action == "delete":
        return {"r": await cal_tool("delete_event", {"id": item_id})}
    if kind == "todo" and action in ("done", "delete"):
        return {"r": await cal_tool("complete_todo", {"id": item_id, "delete": action == "delete"})}
    if kind == "todo" and action == "reopen":
        db.execute("UPDATE cal_todos SET status='open', done_at=NULL WHERE id=?", (item_id,))
        db.commit()
        return {"r": "ok"}
    if kind == "reminder" and action == "delete":
        return {"r": await cal_tool("delete_reminder", {"id": item_id})}
    if kind in ("event", "reminder") and action == "done":
        occ = req.query_params.get("occ")
        return {"r": mark_done(kind, item_id, float(occ) if occ else None)}
    if kind == "event" and action == "undone":
        db.execute("DELETE FROM cal_done WHERE key LIKE ?", (f"{item_id}:%",))
        db.commit()
        return {"r": "ok"}
    if kind == "watch" and action == "delete":
        db.execute("UPDATE mail_watch SET status='off' WHERE id=?", (item_id,))
        db.commit()
        return {"r": "ok"}
    return JSONResponse({"error": "unknown action"}, status_code=400)


@app.get("/api/sync/export")
async def api_sync_export(req: Request, days: int = 60):
    """Events and reminders for the phone's «Секретарь» calendar (expanded, with alarms)."""
    auth(req)
    now = time.time()
    out = []
    for e in agenda(now - 86400, now + days * 86400, with_phone=False):
        out.append({"id": f"{e['id']}:{int(e['occ'])}", "title": e["title"], "start": int(e["occ"] * 1000),
                    "end": int(e["occ_end"] * 1000), "all_day": bool(e["all_day"]), "location": e["location"] or "",
                    "notes": e["notes"] or "", "alarms": [int(x) for x in json.loads(e["remind"] or "[]")]})
    for r in db.execute("SELECT * FROM cal_reminders WHERE status='active'").fetchall():
        for ts in occurrences(r["at"], r["rrule"] or "", now - 3600, now + days * 86400, 60):
            out.append({"id": f"r{r['id']}:{int(ts)}", "title": "⏰ " + r["text"], "start": int(ts * 1000),
                        "end": int((ts + 900) * 1000), "all_day": False, "location": "", "notes": "", "alarms": [0]})
    return {"events": out}


@app.post("/api/sync/phone")
async def api_sync_phone(req: Request):
    """Den's own phone calendars (read-only for the secretary): replaces the previous snapshot."""
    auth(req)
    body = await req.json()
    db.execute("DELETE FROM phone_events")
    n = 0
    for e in body.get("events", [])[:3000]:
        try:
            db.execute("INSERT OR REPLACE INTO phone_events VALUES(?,?,?,?,?,?,?)",
                       (str(e["id"]), str(e.get("title") or "(без названия)")[:200], float(e["start"]) / 1000,
                        float(e.get("end") or e["start"]) / 1000, 1 if e.get("all_day") else 0,
                        str(e.get("location") or "")[:200], str(e.get("calendar") or "")[:80]))
            n += 1
        except Exception:
            continue
    db.commit()
    cfg_save({"PHONE_SYNC_AT": str(int(time.time())), "PHONE_SYNC_N": str(n)})
    return {"imported": n}


@app.post("/api/tts")
async def api_tts(req: Request):
    auth(req)
    text = str((await req.json()).get("text", ""))[:600]
    if not text.strip():
        return Response(status_code=204)
    try:
        return Response(await tts_mp3(text), media_type="audio/mpeg")
    except Exception as e:
        return JSONResponse({"error": str(e)}, status_code=502)


@app.get("/api/ingest/watchlist")
async def api_watchlist(req: Request):
    """Senders Den asked to watch — SB forwards their e-mails (and only these, besides bookings)."""
    if not secrets.compare_digest(req.headers.get("X-SB-Key", ""), sb_key()):
        raise HTTPException(401, "bad key")
    return {"patterns": [r["pattern"] for r in db.execute("SELECT pattern FROM mail_watch WHERE status='active'").fetchall()]}


@app.get("/api/deliveries")
async def api_deliveries(req: Request):
    auth(req)
    rows = db.execute("SELECT * FROM deliveries ORDER BY updated DESC LIMIT 60").fetchall()
    out = []
    for r in rows:
        d = dict(r)
        d["late"] = d["status"] not in ("delivered", "cancelled", "returned") and bool(d["exp_to"]) and d["exp_to"] < time.time()
        d["status_ru"] = DELIV_STATUS.get(d["status"], d["status"])
        d["history"] = json.loads(d["history"] or "[]")
        out.append(d)
    return out


@app.post("/api/deliveries/{did}/{action}")
async def api_delivery_action(req: Request, did: str, action: str):
    auth(req)
    if action == "received":
        db.execute("UPDATE deliveries SET status='delivered', delivered_at=?, updated=? WHERE id=?", (time.time(), time.time(), did))
    elif action == "delete":
        db.execute("DELETE FROM deliveries WHERE id=?", (did,))
    db.commit()
    return {"ok": True}


@app.post("/api/screenshot")
async def api_screenshot(req: Request, note: str = ""):
    """Raw image from the app → contacts into the secretary's address book."""
    auth(req)
    img = await req.body()
    if len(img) < 2000:
        return JSONResponse({"error": "картинка не дошла"}, status_code=400)
    if len(img) > 4_800_000:
        return JSONResponse({"error": "картинка слишком большая — пришли скриншот, а не фото"}, status_code=400)
    try:
        return await read_screenshot(img, (req.headers.get("content-type") or "image/jpeg").split(";")[0], note)
    except Exception as e:
        return JSONResponse({"error": f"не смог прочитать: {e}"}, status_code=502)


@app.post("/api/jobs/{jid}/cancel")
async def api_job_cancel(req: Request, jid: str):
    auth(req)
    return {"result": await cancel_job(jid)}


@app.get("/api/jobs")
async def api_jobs(req: Request, limit: int = 15):
    auth(req)
    rows = db.execute("SELECT * FROM jobs ORDER BY created DESC LIMIT ?", (max(1, min(limit, 50)),)).fetchall()
    return [{**dict(r), "steps": json.loads(r["steps"] or "[]")} for r in rows]


@app.get("/api/archive")
async def api_archive(req: Request, q: str = "", tag: str = ""):
    auth(req)
    rows = db.execute("SELECT * FROM archive WHERE status='active' ORDER BY pinned DESC, updated DESC LIMIT 2000").fetchall()
    out = []
    ql = q.lower().strip()
    for r in rows:
        n = note_row(r)
        if tag and tag not in n["tags"]:
            continue
        if ql and ql not in (n["title"] + " " + (n["body"] if not n["secret"] else "") + " " + " ".join(n["tags"])).lower():
            continue
        out.append(n)
    tags = {}
    for r in rows:
        for t in json.loads(r["tags"] or "[]"):
            tags[t] = tags.get(t, 0) + 1
    return {"notes": out, "tags": sorted(tags, key=lambda t: -tags[t])[:30]}


@app.post("/api/archive_search")
async def api_archive_search(req: Request):
    auth(req)
    return await notes_search((await req.json()).get("q", ""))


@app.post("/api/archive_image")
async def api_archive_image(req: Request, text: str = ""):
    auth(req)
    img = await req.body()
    if len(img) < 500:
        return JSONResponse({"error": "пустая картинка"}, status_code=400)
    try:
        n = await image_to_note(img, (req.headers.get("content-type") or "image/jpeg").split(";")[0], text)
    except Exception as e:
        return JSONResponse({"error": str(e)}, status_code=502)
    return n


@app.get("/api/archive/{nid}")
async def api_archive_item(req: Request, nid: str, reveal: int = 0):
    auth(req)
    r = db.execute("SELECT * FROM archive WHERE id=?", (nid,)).fetchone()
    if not r:
        raise HTTPException(404, "no such note")
    return note_row(r, bool(reveal))


@app.post("/api/archive")
async def api_archive_add(req: Request):
    auth(req)
    b = await req.json()
    items = b.get("items") or [b]
    res = []
    for it in items[:300]:
        try:
            created = None
            if it.get("date"):
                try:
                    created = to_ts(str(it["date"])[:16])
                except Exception:
                    created = None
            res.append(await note_add(it.get("text") or "", it.get("title") or "", it.get("tags"), it.get("source") or "app",
                                      it.get("secret"), created))
        except Exception as e:
            res.append({"error": str(e)})
    return {"saved": [x for x in res if "id" in x], "errors": [x for x in res if "error" in x]}


@app.post("/api/archive/{nid}/{action}")
async def api_archive_action(req: Request, nid: str, action: str):
    auth(req)
    r = db.execute("SELECT * FROM archive WHERE id=?", (nid,)).fetchone()
    if not r:
        raise HTTPException(404, "no such note")
    if action == "edit":
        b = await req.json()
        text, title = (b.get("text") or "").strip(), (b.get("title") or r["title"]).strip()
        sec = bool(b["secret"]) if "secret" in b else (bool(r["secret"]) or looks_secret(title + "\n" + text))
        db.execute("UPDATE archive SET title=?, body=?, secret=?, tags=?, updated=? WHERE id=?",
                   (title, enc(text) if sec else text, 1 if sec else 0,
                    json.dumps(b.get("tags") if b.get("tags") is not None else json.loads(r["tags"] or "[]"), ensure_ascii=False),
                    time.time(), nid))
    elif action == "pin":
        db.execute("UPDATE archive SET pinned=1-pinned WHERE id=?", (nid,))
    elif action == "delete":
        db.execute("UPDATE archive SET status='deleted', updated=? WHERE id=?", (time.time(), nid))
    db.commit()
    return {"ok": True}


@app.post("/api/places")
async def api_place_save(req: Request):
    auth(req)
    b = await req.json()
    if b.get("id"):
        r = db.execute("SELECT id FROM places WHERE id=?", (b["id"],)).fetchone()
        if not r:
            raise HTTPException(404, "no such contact")
        cols = ("name", "kind", "phone", "email", "whatsapp", "telegram", "aliases", "address", "website", "notes")
        vals = [(norm(b[k]) if k in ("phone", "whatsapp") and b.get(k) else (b.get(k) or "")) for k in cols]
        db.execute(f"UPDATE places SET {', '.join(f'{k}=?' for k in cols)}, updated=? WHERE id=?", (*vals, time.time(), b["id"]))
        db.commit()
        return {"id": b["id"]}
    pid = save_place(b)
    if not pid:
        return JSONResponse({"error": "нужно имя и хотя бы телефон, почта или Telegram"}, status_code=400)
    return {"id": pid}


@app.get("/api/accounts")
async def api_accounts(req: Request):
    auth(req)
    return {"accounts": await sb_accounts(), "names": account_names()}


@app.post("/api/accounts")
async def api_accounts_save(req: Request):
    auth(req)
    names = (await req.json()).get("names") or {}
    cfg_save({"ACCOUNT_NAMES": json.dumps({k: str(v).strip() for k, v in names.items() if str(v).strip()}, ensure_ascii=False)})
    return {"ok": True}


@app.get("/api/places")
async def api_places(req: Request):
    auth(req)
    return [dict(r) for r in db.execute("SELECT * FROM places ORDER BY name").fetchall()]


@app.post("/api/places/from_image")
async def api_places_from_image(req: Request, text: str = ""):
    """Raw image body. Saves the contacts found; if Den also typed a command, runs it afterwards."""
    auth(req)
    img = await req.body()
    if len(img) < 500:
        return JSONResponse({"error": "пустая картинка"}, status_code=400)
    media = (req.headers.get("content-type") or "image/jpeg").split(";")[0]
    try:
        r = await places_from_image(img, media if media.startswith("image/") else "image/jpeg", text)
    except Exception as e:
        return JSONResponse({"error": f"не удалось прочитать картинку: {e}"}, status_code=502)
    lines = "\n".join("• " + place_line(p) for p in r["places"])
    reply = (f"📒 {r['what']}.\nЗаписал:\n{lines}" if r["places"] else f"На картинке ({r['what']}) не нашёл координат.")
    speak = (f"Записал в записную книжку: {', '.join(p.get('name') or '' for p in r['places'])}." if r["places"]
             else "Не нашёл на картинке координат.")
    if text.strip():
        res = await handle_command(text)
        reply, speak = reply + "\n\n" + res["reply"], speak + " " + res["speak"]
    return {"reply": reply, "speak": speak, "places": r["places"]}


@app.post("/api/places/{pid}/delete")
async def api_place_delete(req: Request, pid: str):
    auth(req)
    db.execute("DELETE FROM places WHERE id=?", (pid,))
    db.commit()
    return {"ok": True}


@app.get("/api/watches")
async def api_watches(req: Request):
    auth(req)
    return [dict(r) for r in db.execute("SELECT * FROM mail_watch WHERE status='active' ORDER BY created DESC").fetchall()]


@app.post("/api/ingest/email")
async def api_ingest_email(req: Request):
    """Smart Bubbles forwards booking/ticket/appointment e-mails here (header X-SB-Key)."""
    if not secrets.compare_digest(req.headers.get("X-SB-Key", ""), sb_key()):
        raise HTTPException(401, "bad key")
    mail = await req.json()
    mid = str(mail.get("id") or hash((mail.get("subject"), mail.get("date"))))
    if db.execute("SELECT 1 FROM ingested WHERE id=?", (mid,)).fetchone():
        return {"result": "already processed"}
    watched = await check_mail_watch(mail)
    try:
        res = await email_to_calendar(mail)
    except Exception as e:
        res = f"error: {e}"
    if watched:
        res = f"watched: {watched}; " + res
    db.execute("INSERT OR REPLACE INTO ingested VALUES(?,?,?)", (mid, time.time(), res))
    db.commit()
    return {"result": res}


def _bus_auth(req: Request):
    if not secrets.compare_digest(req.headers.get("X-Bus-Token", ""), bus_token()):
        raise HTTPException(401, "bad bus token")


@app.get("/bus/inbox")
async def bus_inbox(req: Request, app_: str = Query("", alias="app"), since: int = 0):
    _bus_auth(req)
    if since > (db.execute("SELECT MAX(id) FROM bus_msgs").fetchone()[0] or 0):
        since = 0  # Prisma remembers a position from another bus server — start over here
    rows = db.execute("SELECT * FROM bus_msgs WHERE too=? AND id>? ORDER BY id LIMIT 100", (app_, since)).fetchall()
    for r in rows:  # Prisma picked up a shopping task → live status
        if r["type"] == "shop":
            db.execute("UPDATE shop_jobs SET status='taken' WHERE ref=? AND status='sent'", (r["id"],))
            job_step("Призма приняла задачу и работает: ищет и сравнивает", "active", job_by_link(f"shop:{r['id']}"))
    return {"messages": [{"id": r["id"], "from": r["frm"], "to": r["too"], "type": r["type"],
                          "payload": json.loads(r["payload"] or "{}"), "ts": r["ts"]} for r in rows]}


@app.post("/bus/send")
async def bus_send(req: Request):
    _bus_auth(req)
    b = await req.json()
    mid = bus_put(str(b.get("from") or ""), str(b.get("to") or ""), str(b.get("type") or ""), b.get("payload") or {})
    if b.get("to") == "caller":
        asyncio.create_task(bus_to_caller({"id": mid, "frm": b.get("from"), "type": b.get("type"), "payload": b.get("payload") or {}}))
    return {"id": mid}


@app.get("/bus/kv")
async def bus_kv_get(req: Request, key: str = "", prefix: str = ""):
    _bus_auth(req)
    if key:
        r = db.execute("SELECT * FROM bus_kv WHERE key=?", (key,)).fetchone()
        if not r:
            raise HTTPException(404, "no such key")
        return {"key": r["key"], "value": json.loads(r["value"]), "ts": r["ts"]}
    rows = db.execute("SELECT * FROM bus_kv WHERE key LIKE ?", (prefix.replace("%", "") + "%",)).fetchall()
    return {"items": [{"key": r["key"], "value": json.loads(r["value"]), "ts": r["ts"]} for r in rows]}


@app.post("/bus/kv")
async def bus_kv_put(req: Request):
    _bus_auth(req)
    b = await req.json()
    db.execute("INSERT OR REPLACE INTO bus_kv VALUES(?,?,?)", (str(b.get("key")), json.dumps(b.get("value"), ensure_ascii=False), time.time()))
    db.commit()
    return {"ok": True}


@app.get("/api/shop_jobs")
async def api_shop_jobs(req: Request):
    auth(req)
    return [dict(r) for r in db.execute("SELECT * FROM shop_jobs ORDER BY created DESC LIMIT 30").fetchall()]


@app.post("/api/ingest/message")
async def api_ingest_message(req: Request):
    """SB forwards replies from chats where the secretary wrote (header X-SB-Key)."""
    if not secrets.compare_digest(req.headers.get("X-SB-Key", ""), sb_key()):
        raise HTTPException(401, "bad key")
    try:
        return {"result": await on_incoming_message(await req.json())}
    except Exception as e:
        log.exception("incoming message")
        return {"result": f"error: {e}"}


@app.get("/api/sb/accounts")
async def api_sb_accounts(req: Request):
    auth(req)
    return {"accounts": await sb_accounts()}


@app.get("/api/messages/tasks")
async def api_msg_tasks(req: Request):
    auth(req)
    rows = db.execute("SELECT * FROM msg_tasks ORDER BY created DESC LIMIT 30").fetchall()
    return [{**dict(r), "history": json.loads(r["history"] or "[]")} for r in rows]


@app.post("/api/location")
async def api_location(req: Request):
    auth(req)
    b = await req.json()
    st = load_state()
    st["loc"] = {"lat": float(b["lat"]), "lon": float(b["lon"]), "at": time.time()}
    save_state(st)
    return {"ok": True}


@app.get("/api/suggestions")
async def api_suggestions(req: Request):
    auth(req)
    return open_suggestions()


@app.post("/api/suggestions/refresh")
async def api_suggestions_refresh(req: Request):
    auth(req)
    return await make_suggestions("Ден попросил посмотреть сейчас.")


@app.post("/api/suggestions/{sid}/{action}")
async def api_suggestion_action(req: Request, sid: str, action: str):
    auth(req)
    if action == "do":
        return await do_suggestion(sid)
    db.execute("UPDATE suggestions SET status='dismissed' WHERE id=?", (sid,))
    db.commit()
    return {"ok": True}


@app.get("/api/notes")
async def api_notes(req: Request, since: float = 0):
    auth(req)
    rows = db.execute("SELECT * FROM app_notes WHERE at>? ORDER BY at", (since,)).fetchall()
    return [dict(r) for r in rows]


@app.get("/api/messages")
async def api_messages(req: Request):
    auth(req)
    rows = db.execute("SELECT * FROM messages ORDER BY at DESC LIMIT 50").fetchall()
    return [dict(r) for r in rows]


@app.post("/api/call")
async def api_call(req: Request):
    auth(req)
    b = await req.json()
    try:
        cid = await start_outbound(b.get("to", ""), b.get("task", ""), b.get("language", "auto"))  # task id
    except Exception as e:
        return JSONResponse({"error": str(e)}, status_code=400)
    return {"id": cid}
