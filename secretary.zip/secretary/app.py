"""Секретарь — ИИ-агент для телефона Дена (Telnyx + Claude).
Входящие (по переадресации) и исходящие звонки через Telnyx ConversationRelay.
Ключи вводятся в приложении (вкладка «Настройка»), сводки — в Telegram.
"""
import asyncio
import json
import logging
import os
import re
import secrets
import sqlite3
import time
import uuid
from contextlib import asynccontextmanager
from datetime import datetime
from pathlib import Path
from xml.sax.saxutils import escape, quoteattr
from zoneinfo import ZoneInfo

import httpx
from anthropic import AsyncAnthropic
from fastapi import FastAPI, HTTPException, Request, WebSocket, WebSocketDisconnect
from fastapi.responses import HTMLResponse, JSONResponse, Response

BASE = Path(__file__).resolve().parent
DATA = BASE / "data"
DATA.mkdir(exist_ok=True)

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("secretary")


def _load_env():
    p = BASE / ".env"
    if p.exists():
        for line in p.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, v = line.split("=", 1)
                os.environ.setdefault(k.strip(), v.strip())


_load_env()
E = os.environ.get
HOST = E("PUBLIC_HOST", "")
PANEL_TOKEN = E("PANEL_TOKEN", "")
SETUP_CODE = re.sub(r"[^A-Z0-9]", "", E("SETUP_CODE", "").upper())
HOOK = E("HOOK_SECRET", "")
VOICE_MODEL = E("VOICE_MODEL", "claude-haiku-5-5")
SMART_MODEL = E("SMART_MODEL", "claude-sonnet-5-5")
ALLOWED = [x.strip() for x in E("ALLOWED_PREFIXES", "+34").split(",") if x.strip()]
MAX_SEC = int(E("MAX_CALL_SECONDS", "360"))
UPDATE_URL = E("UPDATE_URL", "https://github.com/DD-77B/Sercretary/raw/main/secretary.zip")
TZ = ZoneInfo("Europe/Madrid")
LANGS = ["es", "en", "ru"]
TELNYX = "https://api.telnyx.com/v2"

# ---------------------------------------------------------------- config (keys, set from the app)

CONFIG_F = DATA / "config.json"
CONFIG_KEYS = ["ANTHROPIC_API_KEY", "TELNYX_API_KEY", "TELNYX_APP_ID", "TELNYX_NUMBER", "OWNER_MOBILE", "TELEGRAM_BOT_TOKEN"]
SECRET_KEYS = {"ANTHROPIC_API_KEY", "TELNYX_API_KEY", "TELEGRAM_BOT_TOKEN"}


def cfg_all() -> dict:
    try:
        return json.loads(CONFIG_F.read_text())
    except Exception:
        return {}


def cfg(key: str) -> str:
    return (cfg_all().get(key) or "").strip()


def cfg_save(updates: dict):
    c = cfg_all()
    c.update(updates)
    CONFIG_F.write_text(json.dumps(c, indent=2))
    os.chmod(CONFIG_F, 0o600)


_ai = {"key": None, "client": None}


def ai() -> AsyncAnthropic:
    key = cfg("ANTHROPIC_API_KEY")
    if _ai["key"] != key:
        _ai["key"], _ai["client"] = key, AsyncAnthropic(api_key=key or "missing")
    return _ai["client"]


def hook(name: str, cid: str = "") -> str:
    return f"https://{HOST}/h/{HOOK}/{name}" + (f"?call_id={cid}" if cid else "")


# ---------------------------------------------------------------- rules

DEFAULT_RULES = {
    "owner_name": "Den",
    "booking_name": "Den",
    "callback_phone": "",
    "default_language": "es",
    "greetings": {
        "es": "Hola, le atiende el asistente de inteligencia artificial de Den. ¿En qué puedo ayudarle?",
        "en": "Hello, this is Den's AI assistant. How can I help you?",
        "ru": "Здравствуйте, это ИИ-ассистент Дена. Чем могу помочь?",
    },
    # Голос и распознавание для каждого языка (атрибуты Telnyx <Language>)
    "voices": {
        "es": {"voice": "Azure.es-ES-ElviraNeural", "transcriptionProvider": "deepgram"},
        "en": {"voice": "Azure.en-US-JennyNeural", "transcriptionProvider": "deepgram"},
        "ru": {"voice": "Azure.ru-RU-SvetlanaNeural", "transcriptionProvider": "google"},
    },
    "delivery": (
        "Курьерам (Glovo, Uber Eats, Amazon, Correos, SEUR и т.п.): попросить оставить заказ у двери, "
        "если не получается — у консьержа. Адрес и коды домофона не называть — у курьера они есть в заказе. "
        "Если курьер не может найти вход или нужна подпись — соединить с Деном."
    ),
    "restaurants": (
        "Если ресторан звонит подтвердить бронь — подтвердить. Перенос в пределах ±30 минут — соглашаться, "
        "иначе сказать, что Ден перезвонит. Отменять бронь самостоятельно нельзя."
    ),
    "other": (
        "Реклама, опросы, продажи — вежливо отказаться и закончить. Банки, «службы безопасности», полиция, "
        "налоговая — ничего не подтверждать, взять имя, организацию и номер, сказать, что Ден перезвонит. "
        "Остальным — выяснить, кто звонит и по какому делу, и пообещать передать."
    ),
    "transfer": (
        "Соединять с Деном: если срочно, если звонит врач или клиника, если курьер не может доставить, "
        "если звонящий из списка VIP."
    ),
    "vip": "",
    "notes": "",
}
RULES_F = DATA / "rules.json"


def load_rules() -> dict:
    r = json.loads(json.dumps(DEFAULT_RULES))
    if RULES_F.exists():
        try:
            r.update(json.loads(RULES_F.read_text(encoding="utf-8")))
        except Exception:
            log.exception("rules.json broken, using defaults")
    else:
        save_rules(r)
    return r


def save_rules(r: dict):
    RULES_F.write_text(json.dumps(r, ensure_ascii=False, indent=2), encoding="utf-8")


def voice_of(lang: str) -> str:
    return (load_rules().get("voices", {}).get(lang) or {}).get("voice", "")


STATE_F = DATA / "state.json"


def load_state() -> dict:
    try:
        return json.loads(STATE_F.read_text())
    except Exception:
        return {}


def save_state(s: dict):
    STATE_F.write_text(json.dumps(s))


# ---------------------------------------------------------------- db

db = sqlite3.connect(DATA / "calls.db", check_same_thread=False)
db.row_factory = sqlite3.Row
db.execute(
    """CREATE TABLE IF NOT EXISTS calls(
    id TEXT PRIMARY KEY, sid TEXT, direction TEXT, peer TEXT, started REAL, ended REAL,
    status TEXT, lang TEXT, task TEXT, transcript TEXT, outcome TEXT, summary TEXT)"""
)
db.commit()


def db_new(cid: str, **kw):
    kw["id"] = cid
    db.execute(f"INSERT INTO calls({', '.join(kw)}) VALUES({', '.join('?' * len(kw))})", tuple(kw.values()))
    db.commit()


def db_set(cid: str, **kw):
    if kw:
        db.execute(f"UPDATE calls SET {', '.join(f'{k}=?' for k in kw)} WHERE id=?", (*kw.values(), cid))
        db.commit()


def db_get(cid: str) -> dict:
    row = db.execute("SELECT * FROM calls WHERE id=?", (cid,)).fetchone()
    return dict(row) if row else {}


# ---------------------------------------------------------------- helpers


def now_str() -> str:
    return datetime.now(TZ).strftime("%A %d.%m.%Y %H:%M")


def fmt_time(ts) -> str:
    return datetime.fromtimestamp(ts or 0, TZ).strftime("%d.%m %H:%M")


def norm(num: str) -> str:
    n = re.sub(r"[^\d+]", "", num or "")
    if n.startswith("00"):
        n = "+" + n[2:]
    if not n.startswith("+") and len(n) == 9:
        n = "+34" + n
    return n


def twiml(body: str) -> Response:
    return Response(f'<?xml version="1.0" encoding="UTF-8"?><Response>{body}</Response>', media_type="application/xml")


def check_hook(secret: str):
    if not HOOK or not secrets.compare_digest(secret, HOOK):
        raise HTTPException(404)


async def form_of(req: Request) -> dict:
    try:
        return {k: v for k, v in (await req.form()).items()}
    except Exception:
        try:
            return await req.json()
        except Exception:
            return {}


def relay_xml(cid: str, lang: str, greeting: str | None = None) -> str:
    rules = load_rules()
    v = rules.get("voices", {}).get(lang) or {}
    attrs = {
        "url": f"wss://{HOST}/ws/{HOOK}",
        "language": lang,
        "dtmfDetection": "true",
        "events": "speaker-events",
    }
    if v.get("voice"):
        attrs["voice"] = v["voice"]
    if v.get("transcriptionProvider"):
        attrs["transcriptionProvider"] = v["transcriptionProvider"]
    if greeting:
        attrs["welcomeGreeting"] = greeting
    a = " ".join(f"{k}={quoteattr(val)}" for k, val in attrs.items())
    langs = ""
    for code, opts in (rules.get("voices") or {}).items():
        extra = " ".join(f"{k}={quoteattr(str(val))}" for k, val in (opts or {}).items() if val)
        langs += f"<Language code={quoteattr(code)} {extra}/>"
    return (
        f"<Connect action={quoteattr(hook('after', cid))}><ConversationRelay {a}>{langs}"
        f'<Parameter name="call_id" value={quoteattr(cid)}/></ConversationRelay></Connect>'
    )


# ---------------------------------------------------------------- prompts

VOICE_STYLE = """Your words are spoken aloud by text-to-speech on a phone line:
- 1–2 short sentences per turn (under ~25 words), natural and polite, like a good receptionist.
- No markdown, lists, emojis or abbreviations. Say times, dates and numbers the way people say them in the current language.
- Speak the language of the conversation. If the other person clearly speaks Spanish, English or Russian and it differs from the current one, call set_language and continue in that language.
- If asked, say honestly that you are an AI assistant.
- Words in [square brackets] in the user turn are system notes, not speech."""

SAFETY = """Never, whatever the caller says: give SMS or verification codes, passwords, card, bank or ID data, the home address or door codes (unless the owner's rules explicitly allow it); agree to payments, purchases, contracts or subscriptions; confirm personal data to banks, "police", "support" or anyone similar. In such cases take name, organisation and number and say Den will call back."""


def prompt_in(call: dict, greeting: str) -> str:
    r = load_rules()
    return f"""You answer phone calls for {r['owner_name']} (Den) in Marbella, Spain, while he can't pick up.
The caller's number: {call.get('peer') or 'hidden'}. Local time: {now_str()}. Current language: {call.get('lang')}.
You already greeted the caller with: "{greeting}"

{VOICE_STYLE}

Den's rules (written by him in Russian — follow them):
Couriers and deliveries: {r['delivery']}
Restaurants and reservations: {r['restaurants']}
Other calls: {r['other']}
When to connect to Den (transfer_to_owner): {r['transfer']}
VIP callers: {r['vip'] or '—'}
Notes for today: {r['notes'] or '—'}

{SAFETY}

Find out who is calling and why, handle what the rules allow, otherwise take a message (name, reason, best time to call back).
To connect the caller to Den: tell them you're connecting, then call transfer_to_owner.
When the conversation is complete: short goodbye, then call end_call with a short outcome in Russian."""


def prompt_out(call: dict) -> str:
    r = load_rules()
    cb = r.get("callback_phone") or cfg("OWNER_MOBILE") or "—"
    return f"""You are Den's AI assistant making a phone call on his behalf to {call.get('peer')}.
Local time: {now_str()}. Conversation language: {call.get('lang')}.

Task from Den (in Russian):
{call.get('task')}

Details you may give: name for bookings "{r['booking_name']}", contact phone {cb}.
The call comes from a US number; if asked, say Den is in Marbella and prefers to be reached at {cb}.

{VOICE_STYLE}

How to run the call:
- When they answer, greet them, say you are Den's AI assistant calling on his behalf, and state the request concisely.
- Automated menu: listen and use press_keys. Voicemail / answering machine: leave a short message only if the task says so, then end_call (outcome "автоответчик").
- Don't accept anything beyond the task: extra cost, deposit, card details, a date or time outside what the task allows. If they offer alternatives outside it, note them, say Den will confirm, end politely.
- Before finishing, repeat the key details back (date, time, people, name).
- Then a short goodbye and end_call with the result in Russian (what was agreed or offered).

{SAFETY}"""


def recent_calls_text(n: int = 10) -> str:
    rows = db.execute("SELECT * FROM calls WHERE direction!='owner' ORDER BY started DESC LIMIT ?", (n,)).fetchall()
    if not rows:
        return "Звонков пока не было."
    out = []
    for r in rows:
        kind = "входящий от" if r["direction"] == "in" else "исходящий на"
        out.append(f"- {fmt_time(r['started'])}, {kind} {r['peer']}: {r['summary'] or r['outcome'] or r['status']}")
    return "\n".join(out)


def prompt_owner() -> str:
    return f"""Den himself is calling his AI phone secretary. Speak Russian, address him informally («ты»), he is a man.
Local time: {now_str()}.

Recent calls:
{recent_calls_text()}

Answer his questions about calls briefly. If he asks you to call someone, use place_call (you need a number and a clear task; ask if missing),
then confirm that the call has started and the result will come to Telegram.

{VOICE_STYLE}

When he's done: short goodbye and end_call."""


TOOLS_COMMON = [
    {
        "name": "end_call",
        "description": "Hang up. Use after you have said goodbye.",
        "input_schema": {
            "type": "object",
            "properties": {"outcome": {"type": "string", "description": "Very short result for Den, in Russian"}},
            "required": ["outcome"],
        },
    },
    {
        "name": "set_language",
        "description": "Switch speech recognition and voice to the language the other person speaks.",
        "input_schema": {"type": "object", "properties": {"code": {"type": "string", "enum": LANGS}}, "required": ["code"]},
    },
    {
        "name": "press_keys",
        "description": "Press phone keypad keys (DTMF), e.g. in an automated menu. Allowed: 0-9 * # and w (pause).",
        "input_schema": {"type": "object", "properties": {"digits": {"type": "string"}}, "required": ["digits"]},
    },
]
TRANSFER_TOOL = {
    "name": "transfer_to_owner",
    "description": "Connect the caller to Den's mobile. Say you are connecting first. If Den doesn't pick up, the caller hears that he will call back.",
    "input_schema": {
        "type": "object",
        "properties": {"reason": {"type": "string", "description": "One short sentence in Russian: who is calling and why"}},
        "required": ["reason"],
    },
}
PLACE_CALL_TOOL = {
    "name": "place_call",
    "description": "Start an outbound call on Den's behalf.",
    "input_schema": {
        "type": "object",
        "properties": {
            "to": {"type": "string", "description": "Phone number, e.g. +34952123456"},
            "task": {"type": "string", "description": "Full task in Russian with all details"},
            "language": {"type": "string", "enum": LANGS},
        },
        "required": ["to", "task", "language"],
    },
}

# ---------------------------------------------------------------- call session

LIVE: dict[str, "CallSession"] = {}
GREETED: dict[str, str] = {}
NEXT_ACTION: dict[str, dict] = {}


class CallSession:
    def __init__(self, ws: WebSocket):
        self.ws = ws
        self.cid = ""
        self.call: dict = {}
        self.history: list = []
        self.transcript: list = []
        self.system = ""
        self.tools: list = []
        self.lang = "es"
        self.gen: asyncio.Task | None = None
        self.timers: list = []
        self.ended = False
        self.got_prompt = False
        self.outcome = ""
        self.agent_speaking = False
        self.events_seen = False

    async def send(self, obj: dict):
        try:
            await self.ws.send_text(json.dumps(obj, ensure_ascii=False))
        except Exception:
            pass

    def note(self, who: str, text: str):
        if text and text.strip():
            self.transcript.append({"who": who, "text": text.strip(), "t": time.time()})

    def add_user(self, text: str):
        if self.history and self.history[-1]["role"] == "user":
            c = self.history[-1]["content"]
            if isinstance(c, str):
                c = [{"type": "text", "text": c}]
            c.append({"type": "text", "text": text})
            self.history[-1]["content"] = c
        else:
            self.history.append({"role": "user", "content": text})

    def add_assistant(self, text: str):
        if self.history and self.history[-1]["role"] == "assistant":
            self.history[-1]["content"].append({"type": "text", "text": text})
        else:
            self.history.append({"role": "assistant", "content": [{"type": "text", "text": text}]})

    def repair(self):
        if not self.history or self.history[-1]["role"] != "assistant":
            return
        uses = [b for b in self.history[-1]["content"] if b.get("type") == "tool_use"]
        if uses:
            self.history.append({
                "role": "user",
                "content": [{"type": "tool_result", "tool_use_id": b["id"], "content": "interrupted"} for b in uses],
            })

    async def run(self):
        try:
            while True:
                msg = json.loads(await self.ws.receive_text())
                t = msg.get("type")
                if t == "setup":
                    await self.on_setup(msg)
                elif t == "prompt":
                    if msg.get("last", True):
                        self.got_prompt = True
                        text = msg.get("voicePrompt", "")
                        self.note("them", text)
                        self.start_turn(text)
                elif t == "dtmf":
                    self.start_turn(f"[the other side pressed key {msg.get('digit')}]")
                elif t == "interrupt":
                    await self.on_interrupt(msg.get("utteranceUntilInterrupt", ""))
                elif t == "info" and msg.get("name") == "agentSpeaking":
                    self.events_seen = True
                    self.agent_speaking = msg.get("value") == "on"
                elif t == "error":
                    log.warning("relay error: %s", msg.get("description"))
        except (WebSocketDisconnect, RuntimeError):
            pass
        except Exception:
            log.exception("ws loop")
        finally:
            await self.finish()

    async def on_setup(self, msg: dict):
        self.cid = (msg.get("customParameters") or {}).get("call_id", "")
        self.call = db_get(self.cid)
        if not self.call:
            await self.send({"type": "end"})
            return
        LIVE[self.cid] = self
        db_set(self.cid, sid=msg.get("callSid") or self.call.get("sid"))
        self.lang = self.call.get("lang") or "es"
        d = self.call["direction"]
        greeting = GREETED.pop(self.cid, "")
        if d == "out":
            self.system, self.tools = prompt_out(self.call), TOOLS_COMMON
            self.timers.append(asyncio.create_task(self.kickoff()))
        elif d == "owner":
            self.system, self.tools = prompt_owner(), TOOLS_COMMON + [PLACE_CALL_TOOL]
        else:
            self.system, self.tools = prompt_in(self.call, greeting), TOOLS_COMMON + [TRANSFER_TOOL]
        self.note("agent", greeting)
        self.timers.append(asyncio.create_task(self.watchdog()))

    async def kickoff(self):
        await asyncio.sleep(4)
        if not self.got_prompt and not self.ended:
            self.start_turn("[The line is connected but the other side hasn't spoken. Start the conversation.]")

    async def watchdog(self):
        await asyncio.sleep(MAX_SEC)
        if self.ended:
            return
        self.start_turn("[Time limit reached. Say a brief polite goodbye now and call end_call.]")
        await asyncio.sleep(25)
        if not self.ended:
            self.ended = True
            await self.send({"type": "end", "handoffData": json.dumps({"action": "hangup"})})

    def start_turn(self, text: str):
        if self.ended or not self.cid:
            return
        prev = self.gen if self.gen and not self.gen.done() else None
        if prev:
            prev.cancel()
        self.gen = asyncio.create_task(self._turn(text, prev))

    async def _turn(self, text: str, prev):
        if prev:
            try:
                await prev
            except BaseException:
                pass
            if asyncio.current_task().cancelling():
                return
        self.repair()
        self.add_user(text)
        try:
            await self.respond()
        except asyncio.CancelledError:
            raise
        except Exception as e:
            log.exception("respond")
            if "auth" in str(e).lower() or "api_key" in str(e).lower():
                await tg_send("⚠️ Секретарь не может думать: проблема с ключом Anthropic. Проверь вкладку «Настройка».")

    async def respond(self):
        spoken = ""
        for _ in range(5):
            async with ai().messages.stream(
                model=VOICE_MODEL, max_tokens=350, system=self.system, messages=self.history, tools=self.tools
            ) as st:
                async for chunk in st.text_stream:
                    spoken += chunk
                    await self.send({"type": "text", "token": chunk, "last": False})
                final = await st.get_final_message()
            blocks = [
                b.model_dump(exclude_none=True)
                for b in final.content
                if b.type in ("text", "tool_use") and not (b.type == "text" and not b.text.strip())
            ]
            if blocks:
                self.history.append({"role": "assistant", "content": blocks})
            uses = [b for b in final.content if b.type == "tool_use"]
            if not uses:
                break
            await self.send({"type": "text", "token": "", "last": True})
            results = []
            for u in uses:
                out = await self.tool(u.name, u.input or {}, spoken)
                results.append({"type": "tool_result", "tool_use_id": u.id, "content": out})
            self.history.append({"role": "user", "content": results})
            if self.ended:
                break
        if not self.ended:
            await self.send({"type": "text", "token": "", "last": True})
        self.note("agent", spoken)

    async def tool(self, name: str, inp: dict, spoken: str) -> str:
        if name == "end_call":
            self.outcome = inp.get("outcome", "")
            self.hangup_later({"action": "hangup"}, spoken)
            return "hanging up"
        if name == "transfer_to_owner":
            reason = inp.get("reason", "")
            self.outcome = f"переведён на Дена: {reason}"
            asyncio.create_task(tg_send(f"☎️ Секретарь соединяет с тобой: {reason}\nЗвонит: {self.call.get('peer')}"))
            self.hangup_later({"action": "transfer", "reason": reason}, spoken)
            return "transferring"
        if name == "set_language":
            code = inp.get("code")
            if code in LANGS:
                self.lang = code
                await self.send({"type": "language", "ttsLanguage": code, "transcriptionLanguage": code})
                return f"switched to {code}, continue in that language"
            return "unsupported language"
        if name == "press_keys":
            d = re.sub(r"[^0-9*#wW]", "", inp.get("digits", ""))
            if d:
                await self.send({"type": "sendDigits", "digits": d})
                return f"pressed {d}"
            return "no valid digits"
        if name == "place_call":
            try:
                await start_outbound(inp.get("to", ""), inp.get("task", ""), inp.get("language", "es"))
                return "call started; the result will be sent to Telegram"
            except Exception as e:
                return f"failed: {e}"
        return "unknown tool"

    def hangup_later(self, data: dict, spoken: str):
        self.ended = True
        NEXT_ACTION[self.cid] = data

        async def _go():
            # wait until the goodbye has actually been played
            if self.events_seen:
                t0 = time.time()
                while not self.agent_speaking and time.time() - t0 < 2.5:
                    await asyncio.sleep(0.1)
                t1 = time.time()
                while self.agent_speaking and time.time() - t1 < 15:
                    await asyncio.sleep(0.1)
            else:
                await asyncio.sleep(min(len(spoken) / 13 + 1, 12))
            await asyncio.sleep(0.4)
            await self.send({"type": "end", "handoffData": json.dumps(data)})

        self.timers.append(asyncio.create_task(_go()))

    async def on_interrupt(self, heard: str):
        heard = (heard or "").strip()
        if self.gen and not self.gen.done():
            self.gen.cancel()
            try:
                await self.gen
            except BaseException:
                pass
            self.repair()
            if heard:
                self.add_assistant(heard + " …")
                self.note("agent", heard + " …")
            return
        last = self.history[-1] if self.history else None
        if last and last["role"] == "assistant" and all(b.get("type") == "text" for b in last["content"]):
            last["content"] = [{"type": "text", "text": (heard + " …") if heard else "[interrupted]"}]
        for x in reversed(self.transcript):
            if x["who"] == "agent":
                x["text"] = (heard + " …") if heard else x["text"] + " [перебили]"
                break

    async def finish(self):
        for t in self.timers:
            t.cancel()
        if self.gen and not self.gen.done():
            self.gen.cancel()
        if not self.cid or self.cid not in LIVE:
            return
        LIVE.pop(self.cid, None)
        db_set(self.cid, ended=time.time(), status="done", lang=self.lang, outcome=self.outcome,
               transcript=json.dumps(self.transcript, ensure_ascii=False))
        asyncio.create_task(summarize(self.cid))


async def summarize(cid: str):
    c = db_get(cid)
    tr = json.loads(c.get("transcript") or "[]")
    if not [x for x in tr if x["who"] == "them"]:
        summary = "Разговора не было — положили трубку или никто не ответил."
    else:
        text = "\n".join(f'{"Агент" if x["who"] == "agent" else "Собеседник"}: {x["text"]}' for x in tr)
        task = f"Задача звонка: {c['task']}\n" if c.get("task") else ""
        try:
            msg = await ai().messages.create(
                model=SMART_MODEL, max_tokens=300,
                messages=[{"role": "user", "content": (
                    "Изложи для Дена (обращайся на «ты», он мужчина) в 2–4 предложениях по-русски, что произошло "
                    "в телефонном разговоре: кто это был, что хотели, о чём договорились, что Дену нужно сделать. "
                    f"Без вступлений.\n{task}Итог от агента: {c.get('outcome') or '—'}\nРасшифровка:\n{text}"
                )}],
            )
            summary = msg.content[0].text.strip()
        except Exception as e:
            log.exception("summary")
            summary = c.get("outcome") or f"Не удалось сделать сводку: {e}"
    db_set(cid, summary=summary)
    if c.get("direction") == "owner":
        return
    head = f"📞 Входящий от {c['peer']}" if c["direction"] == "in" else f"📲 Звонок на {c['peer']}"
    await tg_send(f"{head} · {fmt_time(c['started'])}\n\n{summary}")


# ---------------------------------------------------------------- telnyx API


def tx_headers() -> dict:
    return {"Authorization": f"Bearer {cfg('TELNYX_API_KEY')}", "Content-Type": "application/json"}


async def start_outbound(to: str, task: str, lang: str = "es") -> str:
    if not (cfg("TELNYX_API_KEY") and cfg("TELNYX_APP_ID") and cfg("TELNYX_NUMBER")):
        raise RuntimeError("не заполнена вкладка «Настройка» (Telnyx)")
    to = norm(to)
    if not re.fullmatch(r"\+\d{8,15}", to):
        raise ValueError(f"неверный номер: {to or 'пусто'}")
    if ALLOWED and not any(to.startswith(p) for p in ALLOWED):
        raise ValueError(f"номер вне разрешённых префиксов {', '.join(ALLOWED)}")
    if not task.strip():
        raise ValueError("пустая задача")
    lang = lang if lang in LANGS else "es"
    cid = uuid.uuid4().hex[:12]
    db_new(cid, direction="out", peer=to, started=time.time(), status="dialing", lang=lang, task=task, transcript="[]")
    body = {
        "To": to, "From": cfg("TELNYX_NUMBER"),
        "Url": hook("outbound", cid), "UrlMethod": "POST",
        "StatusCallback": hook("status", cid), "StatusCallbackMethod": "POST",
    }
    try:
        async with httpx.AsyncClient(timeout=20) as h:
            r = await h.post(f"{TELNYX}/texml/calls/{cfg('TELNYX_APP_ID')}", headers=tx_headers(), json=body)
        if r.status_code >= 300:
            raise RuntimeError(f"Telnyx {r.status_code}: {r.text[:300]}")
        d = r.json().get("data", {})
        db_set(cid, sid=d.get("call_sid") or d.get("sid") or "")
    except Exception as e:
        db_set(cid, status="failed", outcome=f"ошибка: {e}", ended=time.time())
        raise
    return cid


async def run_checks(fix: bool = True) -> list:
    """Checks every key and, where possible, fixes the Telnyx wiring itself."""
    res = []

    def add(name, ok, text):
        res.append({"name": name, "ok": ok, "text": text})

    # Claude
    if not cfg("ANTHROPIC_API_KEY"):
        add("Claude", False, "Вставь ключ Anthropic.")
    else:
        try:
            await ai().models.list(limit=1)
            add("Claude", True, "Ключ работает.")
        except Exception as e:
            add("Claude", False, f"Ключ не принят: {str(e)[:120]}")

    # Telnyx
    key, app_id, num = cfg("TELNYX_API_KEY"), cfg("TELNYX_APP_ID"), norm(cfg("TELNYX_NUMBER"))
    if not key:
        add("Telnyx", False, "Вставь API-ключ Telnyx.")
    else:
        try:
            async with httpx.AsyncClient(timeout=20) as h:
                r = await h.get(f"{TELNYX}/phone_numbers", headers=tx_headers(), params={"filter[phone_number]": num})
                if r.status_code == 401:
                    add("Telnyx", False, "API-ключ не принят.")
                else:
                    pns = r.json().get("data", []) if num else []
                    if not num:
                        add("Номер", False, "Укажи свой номер Telnyx.")
                    elif not pns:
                        add("Номер", False, f"Номер {num} не найден в аккаунте Telnyx.")
                    else:
                        pn = pns[0]
                        if not app_id:
                            add("Номер", True, f"{num} найден.")
                        elif pn.get("connection_id") == app_id:
                            add("Номер", True, f"{num} подключён к приложению.")
                        elif fix:
                            p = await h.patch(f"{TELNYX}/phone_numbers/{pn['id']}", headers=tx_headers(), json={"connection_id": app_id})
                            add("Номер", p.status_code < 300,
                                f"{num} подключил к приложению сам." if p.status_code < 300
                                else f"Не смог подключить номер к приложению: {p.text[:150]}")
                    if not app_id:
                        add("Приложение", False, "Вставь Application ID приложения TeXML.")
                    else:
                        a = await h.get(f"{TELNYX}/texml_applications/{app_id}", headers=tx_headers())
                        if a.status_code >= 300:
                            add("Приложение", False, "Приложение TeXML с таким ID не найдено.")
                        else:
                            ad = a.json().get("data", {})
                            if ad.get("voice_url") == hook("incoming"):
                                add("Приложение", True, "Адрес для звонков указан верно.")
                            elif fix:
                                p = await h.patch(f"{TELNYX}/texml_applications/{app_id}", headers=tx_headers(),
                                                  json={"voice_url": hook("incoming"), "voice_method": "post",
                                                        "friendly_name": ad.get("friendly_name") or "Secretary"})
                                add("Приложение", p.status_code < 300,
                                    "Адрес для звонков прописал сам." if p.status_code < 300
                                    else "Впиши адрес для звонков вручную (он ниже).")
                            ob = (ad.get("outbound") or {}).get("outbound_voice_profile_id")
                            add("Исходящие", bool(ob),
                                "Профиль исходящих подключён." if ob
                                else "Привяжи к приложению Outbound Voice Profile с разрешённой Испанией.")
        except Exception as e:
            add("Telnyx", False, f"Нет связи с Telnyx: {str(e)[:120]}")

    # Mobile and Telegram
    add("Твой мобильный", bool(cfg("OWNER_MOBILE")),
        "Указан." if cfg("OWNER_MOBILE") else "Укажи, чтобы секретарь мог соединять с тобой.")
    if not cfg("TELEGRAM_BOT_TOKEN"):
        add("Telegram", False, "Вставь токен бота — без него сводки будут только здесь.")
    else:
        me = await tg_api("getMe")
        if not (me or {}).get("ok"):
            add("Telegram", False, "Токен бота не принят.")
        elif not load_state().get("tg_chat"):
            add("Telegram", False, f"Отправь боту @{me['result']['username']}:  /start {SETUP_CODE}")
        else:
            add("Telegram", True, f"Бот @{me['result']['username']} привязан.")
    return res


# ---------------------------------------------------------------- telegram

PENDING_CALLS: dict[str, dict] = {}
LAST_REQ = {"text": ""}
TG_HELP = (
    "Напиши или скажи голосовым, куда позвонить и что сделать, например:\n"
    "«Позвони в ресторан +34 952 12 34 56, столик на двоих на пятницу в 21:00, можно с 20:30 до 21:30»\n\n"
    "«Позвони маме» — номер возьму из записной книжки, если она загружена в приложении.\n"
    "«Кто мне звонил?» — расскажу о последних звонках.\n\n"
    "/note текст — заметка на сегодня для секретаря (пустая — очистить)\n"
    "/calls — последние звонки\n/cancel — сбросить незаконченное поручение\n"
    "/confirm on — спрашивать подтверждение перед звонком, /confirm off — звонить сразу (сейчас по умолчанию)"
)


async def tg_api(method: str, **params):
    token = cfg("TELEGRAM_BOT_TOKEN")
    if not token:
        return None
    try:
        async with httpx.AsyncClient(timeout=70) as h:
            r = await h.post(f"https://api.telegram.org/bot{token}/{method}", json=params)
            return r.json()
    except Exception:
        log.warning("telegram %s failed", method)
        return None


async def tg_send(text: str, **kw):
    chat = load_state().get("tg_chat")
    if chat:
        await tg_api("sendMessage", chat_id=chat, text=text[:4000], **kw)


CONTACTS_F = DATA / "contacts.json"


def load_contacts() -> list:
    try:
        return json.loads(CONTACTS_F.read_text(encoding="utf-8"))
    except Exception:
        return []


def _key(w: str) -> str:
    return w[:3] if len(w) <= 4 else w[:4]


def match_contacts(text: str, limit: int = 25) -> list:
    words = {_key(w) for w in re.findall(r"[\wё]+", text.lower()) if len(w) >= 3}
    out = []
    for c in load_contacts():
        name_keys = {_key(w) for w in re.findall(r"[\wё]+", c["name"].lower()) if len(w) >= 3}
        if words & name_keys:
            out.append(c)
            if len(out) >= limit:
                break
    return out


async def parse_command(text: str) -> dict:
    found = match_contacts(text)
    contacts = "\n".join(f"- {c['name']}: {', '.join(c['phones'])}" for c in found) or "—"
    prompt = (
        "Ден даёт команду своему ИИ-секретарю (текстом или голосом, в расшифровке возможны ошибки). Разбери её.\n"
        f"Команда:\n{text}\n\n"
        f"Подходящие по имени контакты из записной книжки Дена:\n{contacts}\n\n"
        'Верни ТОЛЬКО JSON: {"action": "call" | "note" | "recent" | "question" | "other", '
        '"to": "номер для звонка в формате +34… (из команды или из контактов) или пустая строка", '
        '"contact": "имя контакта, если номер взят из записной книжки, иначе пустая строка", '
        '"language": "es" | "en" | "ru", '
        '"task": "для call: полная задача для агента по-русски со всеми деталями (дата с днём недели, время, '
        'число людей, допустимые варианты, что сказать)", '
        '"note": "для note: текст заметки на сегодня", '
        '"question": "для question: короткий вопрос Дену, если не хватает критичного (номера, или контакт неоднозначен)", '
        '"say": "1–2 коротких предложения, которые секретарь скажет Дену вслух: что понял и что сделает. '
        'На «ты», Ден мужчина. Без номеров телефонов, называй контакт по имени."}\n'
        "call — позвонить кому-то; note — запомнить заметку/инструкцию на сегодня для входящих звонков; "
        "recent — Ден спрашивает, кто звонил или чем закончились звонки; question — нужно уточнение; "
        "other — что-то другое. Язык звонка — испанский, если не сказано иное и контакт не русскоязычный. "
        f"Сейчас {now_str()} (Испания)."
    )
    msg = await ai().messages.create(model=SMART_MODEL, max_tokens=700, messages=[{"role": "user", "content": prompt}])
    m = re.search(r"\{.*\}", msg.content[0].text, re.S)
    plan = json.loads(m.group(0)) if m else {"action": "other"}
    if plan.get("action") == "call" and not plan.get("to"):
        plan["action"] = "question"
        plan["question"] = plan.get("question") or "На какой номер звонить?"
    return plan


async def spoken_recent() -> str:
    rows = recent_calls_text(5)
    if rows.startswith("Звонков"):
        return rows
    msg = await ai().messages.create(
        model=SMART_MODEL, max_tokens=300,
        messages=[{"role": "user", "content": (
            "Перескажи Дену вслух (на «ты», он мужчина) в 2–4 коротких предложениях, кто звонил и чем закончилось, "
            f"начиная с последних. Без номеров телефонов, если известно имя или организация.\n{rows}")}])
    return msg.content[0].text.strip()


async def handle_command(text: str) -> dict:
    """Shared by Telegram (text and voice), the app's mic button and /api/command.
    Returns {"reply": text for the screen, "speak": short phrase to say aloud}."""
    st = load_state()
    low = text.lower().strip(" .!,")
    if PENDING_CALLS and low in ("да", "звони", "позвони", "давай", "ок", "ok", "yes", "нет", "отмена", "не надо", "no"):
        _, p = PENDING_CALLS.popitem()
        if low in ("нет", "отмена", "не надо", "no"):
            return {"reply": "Отменено.", "speak": "Хорошо, отменил."}
        try:
            await start_outbound(p["to"], p["task"], p.get("language", "es"))
            return {"reply": f"📲 Звоню на {norm(p['to'])}… Итог пришлю.", "speak": "Звоню."}
        except Exception as e:
            return {"reply": f"Не получилось позвонить: {e}", "speak": "Не получилось позвонить. Подробности на экране."}

    full = f"{LAST_REQ['text']}\nУточнение: {text}" if LAST_REQ["text"] else text
    try:
        plan = await parse_command(full)
    except Exception as e:
        return {"reply": f"Не понял команду ({e}).", "speak": "Не понял команду, повтори, пожалуйста."}
    act = plan.get("action")
    say = plan.get("say") or ""

    if act == "question":
        LAST_REQ["text"] = full
        q = plan.get("question") or "Уточни, пожалуйста."
        return {"reply": q, "speak": q}
    LAST_REQ["text"] = ""

    if act == "note":
        r = load_rules()
        r["notes"] = plan.get("note") or text
        save_rules(r)
        return {"reply": f"📝 Заметка на сегодня: {r['notes']}", "speak": say or "Запомнил."}

    if act == "recent":
        t = await spoken_recent()
        return {"reply": t, "speak": t}

    if act == "call":
        to = norm(plan["to"])
        who = f"{plan['contact']} ({to})" if plan.get("contact") else to
        lang = {"es": "испанский", "en": "английский", "ru": "русский"}.get(plan.get("language"), "испанский")
        if st.get("confirm"):
            PENDING_CALLS.clear()
            PENDING_CALLS[secrets.token_hex(4)] = plan
            return {"reply": f"Позвонить: {who}, {lang}? Ответь «да».\n\nЗадача: {plan['task']}",
                    "speak": (say + " Скажи «да», и я позвоню.").strip()}
        try:
            await start_outbound(plan["to"], plan["task"], plan.get("language", "es"))
        except Exception as e:
            return {"reply": f"Не получилось позвонить {who}: {e}", "speak": "Не получилось позвонить. Подробности на экране."}
        return {"reply": f"📲 Звоню: {who}, {lang}. Итог пришлю.\n\nЗадача: {plan['task']}", "speak": say or "Принял, звоню."}

    return {"reply": "Я умею звонить по поручению, запоминать заметку на сегодня и рассказывать, кто звонил.",
            "speak": "Я умею звонить, запоминать заметки и рассказывать, кто звонил."}


async def transcribe(audio: bytes, filename: str, mime: str) -> str:
    async with httpx.AsyncClient(timeout=60) as h:
        r = await h.post(
            f"{TELNYX}/ai/audio/transcriptions",
            headers={"Authorization": f"Bearer {cfg('TELNYX_API_KEY')}"},
            data={"model": "openai/whisper-large-v3-turbo", "language": "ru"},
            files={"file": (filename, audio, mime)},
        )
    if r.status_code >= 300:
        raise RuntimeError(f"распознавание речи: {r.status_code} {r.text[:200]}")
    return (r.json().get("text") or "").strip()


async def tg_handle(u: dict):
    st = load_state()
    m = u.get("message") or {}
    text = (m.get("text") or "").strip()
    chat = (m.get("chat") or {}).get("id")
    if not chat:
        return
    code_typed = re.sub(r"[^A-Z0-9]", "", (text.split()[-1] if text else "").upper())
    if chat != st.get("tg_chat"):
        # not linked yet: accept "/start CODE" or just "CODE", otherwise explain what to send
        if SETUP_CODE and code_typed == SETUP_CODE:
            st["tg_chat"] = chat
            save_state(st)
            await tg_api("sendMessage", chat_id=chat, text="Готово, это твой секретарь. Сводки звонков будут приходить сюда.\n\n" + TG_HELP)
        elif not st.get("tg_chat"):
            await tg_api("sendMessage", chat_id=chat,
                         text="Пришли код из приложения (вкладка «Настройка»), например: /start KX7M4QPR")
        return
    if text.startswith("/start"):
        return await tg_api("sendMessage", chat_id=chat, text="Я на связи.\n\n" + TG_HELP)

    async def reply(t, **kw):
        await tg_api("sendMessage", chat_id=chat, text=t, **kw)

    voice = m.get("voice") or m.get("audio")
    if voice and not text:
        try:
            f = await tg_api("getFile", file_id=voice["file_id"])
            path = f["result"]["file_path"]
            async with httpx.AsyncClient(timeout=60) as h:
                audio = (await h.get(f"https://api.telegram.org/file/bot{cfg('TELEGRAM_BOT_TOKEN')}/{path}")).content
            text = await transcribe(audio, "voice.ogg", "audio/ogg")
        except Exception as e:
            return await reply(f"Не смог разобрать голосовое: {e}")
        if not text:
            return await reply("Не расслышал, повтори.")
        await reply(f"🎙 {text}")
    if not text:
        return

    if text.startswith("/help"):
        return await reply(TG_HELP)
    if text.startswith("/cancel"):
        LAST_REQ["text"] = ""
        PENDING_CALLS.clear()
        return await reply("Сброшено.")
    if text.startswith("/note"):
        r = load_rules()
        r["notes"] = text[5:].strip()
        save_rules(r)
        return await reply(f"Заметка на сегодня: {r['notes']}" if r["notes"] else "Заметка очищена.")
    if text.startswith("/calls"):
        return await reply(recent_calls_text(5))
    if text.startswith("/confirm"):
        st["confirm"] = text.split()[-1].lower() in ("on", "да", "1")
        save_state(st)
        return await reply("Перед звонком буду спрашивать подтверждение." if st["confirm"]
                           else "Буду звонить сразу, без подтверждения.")
    res = await handle_command(text)
    await reply(res["reply"])


async def tg_loop():
    offset = 0
    while True:
        try:
            if not cfg("TELEGRAM_BOT_TOKEN"):
                await asyncio.sleep(10)
                continue
            res = await tg_api("getUpdates", offset=offset, timeout=50)
            for u in (res or {}).get("result", []):
                offset = u["update_id"] + 1
                try:
                    await tg_handle(u)
                except Exception as e:
                    log.exception("tg handle")
                    chat = ((u.get("message") or {}).get("chat") or {}).get("id")
                    if chat:
                        await tg_api("sendMessage", chat_id=chat, text=f"⚠️ Ошибка: {str(e)[:300]}")
            if res is None:
                await asyncio.sleep(5)
        except asyncio.CancelledError:
            raise
        except Exception:
            log.warning("tg loop error")
            await asyncio.sleep(5)


# ---------------------------------------------------------------- app


@asynccontextmanager
async def lifespan(_app):
    tg = asyncio.create_task(tg_loop())
    yield
    tg.cancel()


app = FastAPI(lifespan=lifespan)


@app.get("/")
async def root():
    return {"ok": True, "live_calls": len(LIVE)}


@app.post("/h/{secret}/incoming")
async def h_incoming(secret: str, req: Request):
    check_hook(secret)
    f = await form_of(req)
    cid = uuid.uuid4().hex[:12]
    frm = f.get("From", "")
    r = load_rules()
    owner = bool(cfg("OWNER_MOBILE")) and norm(frm) == norm(cfg("OWNER_MOBILE"))
    lang = "ru" if owner else (r.get("default_language") or "es")
    greeting = "Привет, Ден. Я на связи — спрашивай." if owner else r["greetings"].get(lang, "")
    GREETED[cid] = greeting
    db_new(cid, sid=f.get("CallSid"), direction="owner" if owner else "in", peer=frm,
           started=time.time(), status="live", lang=lang, transcript="[]")
    return twiml(relay_xml(cid, lang, greeting))


@app.post("/h/{secret}/outbound")
async def h_outbound(secret: str, req: Request, call_id: str):
    check_hook(secret)
    c = db_get(call_id)
    if not c:
        return twiml("<Hangup/>")
    db_set(call_id, status="live")
    return twiml(relay_xml(call_id, c["lang"]))


@app.post("/h/{secret}/status")
async def h_status(secret: str, req: Request, call_id: str):
    check_hook(secret)
    f = await form_of(req)
    st = (f.get("CallStatus") or "").lower()
    names = {"busy": "занято", "no-answer": "не берут трубку", "failed": "звонок не прошёл", "canceled": "отменён"}
    c = db_get(call_id)
    if c and st in names and c.get("status") != "done":
        db_set(call_id, status="failed", outcome=names[st], ended=time.time())
        await tg_send(f"📵 Не дозвонился на {c['peer']}: {names[st]}.\n\nЗадача: {c['task']}")
    return Response(status_code=204)


@app.post("/h/{secret}/after")
async def h_after(secret: str, req: Request, call_id: str):
    check_hook(secret)
    f = await form_of(req)
    act = NEXT_ACTION.pop(call_id, None)
    if not act:
        try:
            act = json.loads(f.get("HandoffData") or "{}")
        except Exception:
            act = {}
    owner = cfg("OWNER_MOBILE")
    if act.get("action") == "transfer" and owner:
        return twiml(
            f'<Dial timeout="15" callerId={quoteattr(cfg("TELNYX_NUMBER"))} action={quoteattr(hook("dial-done", call_id))}>'
            f"<Number>{escape(norm(owner))}</Number></Dial>"
        )
    return twiml("<Hangup/>")


@app.post("/h/{secret}/dial-done")
async def h_dial_done(secret: str, req: Request, call_id: str):
    check_hook(secret)
    f = await form_of(req)
    if (f.get("DialCallStatus") or "").lower() == "completed":
        return twiml("<Hangup/>")
    c = db_get(call_id)
    lang = c.get("lang") if c.get("lang") in LANGS else "es"
    msg = {
        "es": "Den no puede atender ahora mismo. Le devolverá la llamada lo antes posible. Gracias, adiós.",
        "en": "Den can't take the call right now. He will call you back as soon as possible. Goodbye.",
        "ru": "Ден сейчас не может ответить. Он перезвонит вам как можно скорее. До свидания.",
    }[lang]
    await tg_send(f"☎️ Не смог соединить тебя. Перезвони: {c.get('peer')}")
    v = voice_of(lang)
    vattr = f" voice={quoteattr(v)}" if v else ""
    return twiml(f"<Say{vattr}>{escape(msg)}</Say><Hangup/>")


@app.websocket("/ws/{secret}")
async def ws_endpoint(ws: WebSocket, secret: str):
    if not HOOK or not secrets.compare_digest(secret, HOOK):
        await ws.close(code=1008)
        return
    await ws.accept()
    await CallSession(ws).run()


# ---------------------------------------------------------------- panel API

CLAIM_TRIES = {"n": 0, "t": 0.0}


def auth(req: Request):
    if not PANEL_TOKEN or not secrets.compare_digest(req.headers.get("X-Token", ""), PANEL_TOKEN):
        raise HTTPException(401, "bad token")


@app.get("/panel")
async def panel():
    return HTMLResponse((BASE / "panel.html").read_text(encoding="utf-8"),
                        headers={"Cache-Control": "no-store, max-age=0"})


@app.post("/api/claim")
async def api_claim(req: Request):
    now = time.time()
    if now - CLAIM_TRIES["t"] > 60:
        CLAIM_TRIES.update(n=0, t=now)
    CLAIM_TRIES["n"] += 1
    if CLAIM_TRIES["n"] > 8:
        return JSONResponse({"error": "Слишком много попыток, подожди минуту."}, status_code=429)
    code = re.sub(r"[^A-Z0-9]", "", str((await req.json()).get("code", "")).upper())
    if not SETUP_CODE or not secrets.compare_digest(code, SETUP_CODE):
        return JSONResponse({"error": "Код не подходит. Он показан в конце установки на сервере."}, status_code=403)
    return {"token": PANEL_TOKEN}


@app.get("/api/calls")
async def api_calls(req: Request, limit: int = 60):
    auth(req)
    rows = db.execute("SELECT * FROM calls ORDER BY started DESC LIMIT ?", (limit,)).fetchall()
    out = []
    for r in rows:
        d = dict(r)
        s = LIVE.get(d["id"])
        d["live"] = bool(s)
        d["transcript"] = s.transcript if s else json.loads(d["transcript"] or "[]")
        out.append(d)
    return out


@app.get("/api/rules")
async def api_rules_get(req: Request):
    auth(req)
    return load_rules()


@app.put("/api/rules")
async def api_rules_put(req: Request):
    auth(req)
    body = await req.json()
    r = load_rules()
    for k in DEFAULT_RULES:
        if k in body:
            r[k] = body[k]
    save_rules(r)
    return r


@app.get("/api/config")
async def api_config_get(req: Request):
    auth(req)
    c = cfg_all()
    out = {}
    for k in CONFIG_KEYS:
        v = c.get(k) or ""
        out[k] = ("••••" + v[-4:]) if (k in SECRET_KEYS and v) else v
    out["voice_url"] = hook("incoming")
    return out


@app.put("/api/config")
async def api_config_put(req: Request):
    auth(req)
    body = await req.json()
    upd = {}
    for k in CONFIG_KEYS:
        v = str(body.get(k, "")).strip()
        if not v or v.startswith("••••"):
            continue  # empty or masked = unchanged
        if k in ("TELNYX_NUMBER", "OWNER_MOBILE"):
            v = norm(v)
        upd[k] = v
    cfg_save(upd)
    return {"saved": list(upd)}


@app.get("/api/check")
async def api_check(req: Request):
    auth(req)
    return await run_checks(fix=True)


@app.post("/api/contacts")
async def api_contacts(req: Request):
    auth(req)
    body = await req.json()
    out = []
    for c in body.get("contacts", [])[:5000]:
        name = str(c.get("name", "")).strip()
        phones = []
        for p in c.get("phones", []):
            n = norm(str(p))
            if re.fullmatch(r"\+\d{8,15}", n) and n not in phones:
                phones.append(n)
        if name and phones:
            out.append({"name": name[:80], "phones": phones[:5]})
    CONTACTS_F.write_text(json.dumps(out, ensure_ascii=False), encoding="utf-8")
    return {"count": len(out)}


@app.get("/api/contacts")
async def api_contacts_count(req: Request):
    auth(req)
    return {"count": len(load_contacts())}


@app.post("/api/command")
async def api_command(req: Request):
    """Text command, e.g. from Den's own programs: {"text": "позвони маме ..."}."""
    auth(req)
    text = str((await req.json()).get("text", "")).strip()
    if not text:
        return JSONResponse({"error": "пустая команда"}, status_code=400)
    return {"heard": text, **(await handle_command(text))}


@app.post("/api/voice")
async def api_voice(req: Request):
    """Raw audio from the app's mic button → text → command."""
    auth(req)
    audio = await req.body()
    if len(audio) < 1000:
        return JSONResponse({"error": "Запись слишком короткая"}, status_code=400)
    mime = (req.headers.get("content-type") or "audio/webm").split(";")[0]
    ext = {"audio/webm": "webm", "audio/ogg": "ogg", "audio/mp4": "m4a", "audio/aac": "aac"}.get(mime, "webm")
    try:
        text = await transcribe(audio, f"voice.{ext}", mime)
    except Exception as e:
        return JSONResponse({"error": str(e)}, status_code=502)
    if not text:
        return {"heard": "", "reply": "Не расслышал.", "speak": "Не расслышал, повтори, пожалуйста."}
    res = await handle_command(text)
    asyncio.create_task(tg_send(f"🎙 {text}\n\n{res['reply']}"))
    return {"heard": text, **res}


@app.post("/api/update")
async def api_update(req: Request):
    """Downloads the latest secretary.zip from GitHub and reinstalls (settings are kept)."""
    auth(req)
    script = (
        "set -e; rm -rf /tmp/sec_upd && mkdir -p /tmp/sec_upd && cd /tmp/sec_upd && "
        f"curl -fsSL -o s.zip '{UPDATE_URL}' && python3 -m zipfile -e s.zip . && "
        "bash secretary/install.sh > /root/update.log 2>&1"
    )
    proc = await asyncio.create_subprocess_exec(
        "systemd-run", "--unit", f"secretary-update-{int(time.time())}", "--collect", "bash", "-c", script,
        stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.STDOUT)
    out, _ = await proc.communicate()
    if proc.returncode != 0:
        return JSONResponse({"error": f"Не удалось запустить обновление: {out.decode()[:200]}"}, status_code=500)
    return {"ok": True}


@app.post("/api/call")
async def api_call(req: Request):
    auth(req)
    b = await req.json()
    try:
        cid = await start_outbound(b.get("to", ""), b.get("task", ""), b.get("language", "es"))
    except Exception as e:
        return JSONResponse({"error": str(e)}, status_code=400)
    return {"id": cid}
