#!/usr/bin/env bash
# Секретарь — установка/обновление на Ubuntu (Hetzner). Запуск от root:  bash secretary/install.sh
set -e
DIR=/opt/secretary
PORT=8095
SRC="$(cd "$(dirname "$0")" && pwd)"

echo "== Пакеты"
apt-get update -qq
apt-get install -y -qq python3-venv python3-pip curl openssl >/dev/null

echo "== Файлы"
mkdir -p "$DIR/data"
cp "$SRC/app.py" "$SRC/panel.html" "$SRC/requirements.txt" "$DIR/"
[ -d "$DIR/venv" ] || python3 -m venv "$DIR/venv"
"$DIR/venv/bin/pip" install -q --upgrade pip
"$DIR/venv/bin/pip" install -q -r "$DIR/requirements.txt"

if [ ! -f "$DIR/.env" ]; then
  IP=$(curl -4 -s https://ifconfig.me || hostname -I | awk '{print $1}')
  CODE=$(tr -dc 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789' </dev/urandom | head -c 8)
  cat > "$DIR/.env" <<ENV
PUBLIC_HOST=$(echo "$IP" | tr . -).sslip.io
PANEL_TOKEN=$(openssl rand -hex 16)
HOOK_SECRET=$(openssl rand -hex 12)
SETUP_CODE=$CODE
VOICE_MODEL=claude-haiku-5-5
SMART_MODEL=claude-sonnet-5-5
ALLOWED_PREFIXES=+34
MAX_CALL_SECONDS=360
ENV
  chmod 600 "$DIR/.env"
fi
set -a; . "$DIR/.env"; set +a

echo "== HTTPS"
PROXY_OK=1
if ! command -v caddy >/dev/null; then
  if ss -ltnH | awk '{print $4}' | grep -qE ':(80|443)$'; then PROXY_OK=0; else apt-get install -y -qq caddy >/dev/null; fi
fi
if [ "$PROXY_OK" = 1 ]; then
  CF=/etc/caddy/Caddyfile
  grep -q "/usr/share/caddy" "$CF" 2>/dev/null && : > "$CF"
  grep -q "^$PUBLIC_HOST " "$CF" 2>/dev/null || printf '\n%s {\n\treverse_proxy 127.0.0.1:%s\n}\n' "$PUBLIC_HOST" "$PORT" >> "$CF"
  systemctl enable -q --now caddy
  systemctl reload caddy || systemctl restart caddy
fi
if command -v ufw >/dev/null && ufw status | grep -q "Status: active"; then ufw allow 80/tcp >/dev/null; ufw allow 443/tcp >/dev/null; fi

echo "== Служба"
cat > /etc/systemd/system/secretary.service <<UNIT
[Unit]
Description=Secretary call agent
After=network-online.target

[Service]
WorkingDirectory=$DIR
ExecStart=$DIR/venv/bin/uvicorn app:app --host 127.0.0.1 --port $PORT --proxy-headers
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
UNIT
systemctl daemon-reload
systemctl enable -q secretary
systemctl restart secretary
sleep 3

echo
[ "$PROXY_OK" = 0 ] && echo "!! Порты 80/443 заняты другим веб-сервером — напиши Claude «порты заняты»."
if curl -fs "http://127.0.0.1:$PORT/" >/dev/null; then echo "OK: сервер запущен"; else echo "ОШИБКА: journalctl -u secretary -n 50"; fi
echo
echo "   АДРЕС:  $(echo "$PUBLIC_HOST" | sed 's/.sslip.io//; s/-/./g')"
echo "   КОД:    $SETUP_CODE"
echo
